//

/*
===============================================================================
   Implementation of TM-align in C/C++

   This program is written by Jianyi Yang at
   Yang Zhang lab
   And it is updated by Jianjie Wu at
   Yang Zhang lab
   Department of Computational Medicine and Bioinformatics
   University of Michigan
   100 Washtenaw Avenue, Ann Arbor, MI 48109-2218

   Please report bugs and questions to jianjiew@umich.edu or zhng@umich.edu
===============================================================================
*/

#ifndef TMALIGNC_H
#define TMALIGNC_H

#include "basic_define.h"

#include <iostream>
#include <string>
#include <vector>
#include <fstream>

#include "../svd/svdMatrix.h"

class MString;

using std::cout;
using std::endl;
using std::vector;
using std::string;
using std::ifstream;
using std::ios;
using std::fstream;

namespace sciloop
{
class TMalignc
{

public:

	enum class structureType_e
	{
		kInvalid,
		kProtein,
		kOther,
		kLast
	};
	structureType_e structureType_;

	TMalignc() {};
	~TMalignc() {};


	bool PrintErrorAndQuit( char* sErrorString );
	template <class A> void NewArray( A *** arr, int Narray1, int Narray2 );
	template <class A> void DeleteArray( A *** array, int Narray );
	char AAmap( string AA );
	void AAmap3( char A, char AA[3] );

	string Trim( string inputString );

	int get_PDB_len( char *filename );

	int read_PDB( const svdMatrix<float> & sourcePoints,
				  const svdMatrix<float> & targetPoints );

	int get_ligand_len( char *filename );
	double dist( double x[3], double y[3] );
	double dot( double *a, double *b );
	void transform( double t[3], double u[3][3], double *x, double *x1 );
	void do_rotation( double **x, double **x1, int len, double t[3], double u[3][3] );
	void output_align1( int *invmap0, int len );
	int output_align( int *invmap0, int len );
	string output_align_to_string( int *invmap, int len );
	string output_coord_to_string( double **x, double **y, int len );

	void NWDP_TM( int len1,
				int len2,
				double gap_open,
				int j2i[] );

	void NWDP_TM(	double ** x,
					double ** y,
					int len1,
					int len2,
					double t[3],
					double u[3][3],
					double d02,
					double gap_open,
					int j2i[] );

	void NWDP_TM(	int * secSource,
					int * targetResNo,
					int len1,
					int len2,
					double gap_open,
					int j2i[] );

	bool load_PDB_allocate_memory( const svdMatrix<float> & sourcePoints,
								   const svdMatrix<float> & targetPoints );

	void free_memory();

	int score_fun8( double **coordsSource,
					double **coordsTarget,
					int n_ali,
					double d,
					int i_ali[],
					double * score1,
					int score_sum_method );

	int score_fun8( double ** coordsSource,
					double ** coordsTarget,
					int n_ali,
					double d,
					vector<int> & i_ali,
					double *score1,
					int score_sum_method );

	int score_fun8_standard(	double ** coordsSource,
								double ** coordsTarget,
								int n_ali,
								double d,
								int i_ali[],
								double * score1,
								int score_sum_method );

	int score_fun8_standard(	double ** coordsSource,
								double ** coordsTarget,
								int n_ali,
								double d,
								vector<int> & i_ali,
								double *score1,
								int score_sum_method );

	double TMscore8_search( double ** sourceTm,
							double ** targetTm,
							int Lali,
							double t0[3],
							double u0[3][3],
							int simplify_step,
							int score_sum_method,
							double * Rcomm,
							double local_d0_search );

	double TMscore8_search_standard(	double ** sourceTm,
										double ** targetTm,
										int Lali,
										double t0[3],
										double u0[3][3],
										int simplify_step,
										int score_sum_method,
										double *Rcomm,
										double local_d0_search );

	double detailed_search(	double ** x,
							double ** y,
							int x_len,
							int y_len,
							int invmap0[],
							double t[3],
							double u[3][3],
							int simplify_step,
							int score_sum_method,
							double local_d0_search );

	double detailed_search_standard(	double ** x,
										double ** y,
										int x_len,
										int y_len,
										int invmap0[],
										double t[3],
										double u[3][3],
										int simplify_step,
										int score_sum_method,
										double local_d0_search,
										const bool& bNormalize );

	double get_score_fast(	double ** x,
							double ** y,
							int x_len,
							int y_len,
							int invmap[] );

	double get_initial( double ** x,
						double ** y,
						int x_len,
						int y_len,
						int *y2x );

	void smooth( int *sec, int len );

	int sec_str(	double dis13,
					double dis14,
					double dis15,
					double dis24,
					double dis25,
					double dis35 );

	void make_sec(	double ** x,
					int len,
					int * sec );

	void get_initial_ss(	double ** x,
							double ** y,
							int x_len,
							int y_len,
							int *y2x );

	bool get_initial5(	double ** x,
						double ** y,
						int x_len,
						int y_len,
						int *y2x );

	void score_matrix_rmsd( double ** x,
							double ** y,
							int x_len,
							int y_len,
							int * y2x );

	void score_matrix_rmsd_sec( double ** x,
								double ** y,
								int x_len,
								int y_len,
								int * y2x );

	void get_initial_ssplus(	double ** x,
								double ** y,
								int x_len,
								int y_len,
								int *y2x0,
								int *y2x );

	void find_max_frag( double ** x,
						int * resno,
						int len,
						int * start_max,
						int * end_max );

	double get_initial_fgt( double ** x,
							double ** y,
							int x_len,
							int y_len,
							int * sourceResNo,
							int * targetResNo,
							int * y2x );

	double DP_iter( double ** x,
					double ** y,
					int x_len,
					int y_len,
					double t[3],
					double u[3][3],
					int invmap0[],
					int g1,
					int g2,
					int iteration_max,
					double local_d0_search );

	void output_results(	char * xname,
							char * yname,
							int x_len,
							int y_len,
							double t[3],
							double u[3][3],
							double TM1,
							double TM2,
							double rmsd,
							double d0_out,
							int m1[],
							int m2[],
							int n_ali8,
							int n_ali,
							double TM_0,
							double Lnorm_0,
							double d0_0,
							char * matrix_name,
							svdMatrix<float> & rotMat,
							svdVector<float> & transVec );

	double standard_TMscore(	double ** x,
								double ** y,
								int x_len,
								int y_len,
								int invmap[],
								int & L_ali_,
								double & RMSD );

	bool Kabsch(	double ** x,
					double ** y,
					const int n,
					int mode,
					double * rms,
					double t[3],
					double u[3][3] );


	void print_help( char *arg );
	void parameter_set4search( int sourceResLen_, int targetResLen_ );
	void parameter_set4final( double len );
	void parameter_set4scale( int len, double d_s );

	bool main_TMalignc(	bool outputStructure,
						bool TMscoreAveragedByBothLength,
						MString TorF,
						bool scaleTMscoreByD0,
						float d0scale,
						svdMatrix<float> & sourcePoints,
						svdMatrix<float> & targetPoints,
						svdMatrix<float> & rotMat,
						svdVector<float> & transVec,
						int structureT );

	bool checkArrLen( svdMatrix<float> & sourcePoints,
					   svdMatrix<float> & targetPoints );

	char	version_[20];						// version_
	double	D0_MIN_;							// for d0_
	double	Lnorm_;								// normalization length
	double	score_d8_, d0_, d0_search_, dcu0_;	// for TMscore search
	double	**score_;							// Input score_ table for dynamic programming
	bool	**path_;							// for dynamic programming
	double	**val_;								// for dynamic programming
	int		sourceResLen_, targetResLen_, minResLen_;	// length of proteins
	int		tempSourceLen_, tempTargetLen_, tempMinlen_;
	double	**coordsSource_, **coordsTarget_;	// for input vectors coordsSource_[0...sourceResLen_-1][0..2], coordsTarget_[0...targetResLen_-1][0..2]
												// in general, coordsTarget_ is regarded as native structure --> superpose coordsSource_ onto coordsTarget_
	int		*sourceResNo_,	*targetResNo_;		// residue numbers, used in fragment gapless threading
	double	**sourceTm_,	**targetTm_;		// for TMscore search engine
	double	**source_t_;						// for saving the superposed version_ of r_1 or sourceTm_
	char	*seqSource_,	*seqTarget_;		// for the protein sequence_
	int		*secSource_,	*secTarget_;		// for the secondary structure
	double	**r1_,			**r2_;				// for Kabsch rotation
	double	t_[3],			u_[3][3];			// Kabsch translation vector and rotation matrix

	int		atomSourceLen_,	atomTargetLen_;		// length of atoms

	double TM_ali_, rmsd_ali_;					// TMscore and rmsd from standard_TMscore func,
	int L_ali_;									// Aligned length from standard_TMscore func,

	// argument variables
	char out_reg_[MAXLEN];
	double Lnorm_ass_, Lnorm_d0_;
	double d0_scale_, d0A_, d0B_, d0u_, d0a_;
	bool o_opt_, a_opt_, u_opt_, d_opt_;
	bool m_opt_;								// flags for -m, output rotation matrix

	double TM3_, TM4_, TM5_;

	string ** atom2_;							// atom name, atom1_(i,j): the name of jth atom for ith residue
	string ** atom1_;							// atom name, atom1_(i,j): the name of jth atom for ith residue

};

//________________________________________________________________
//
//
template <class A> void TMalignc::NewArray(	A *** arr,
											int Narray1,
											int Narray2 )
{
	*arr = new A*[Narray1];

	for( int i=0; i<Narray1; i++ )
	{ *(*arr+i) = new A[Narray2]; }
};

//________________________________________________________________
//
//
template <class A> void TMalignc::DeleteArray( A *** arr, int Narray )
{
	for( int i=0; i<Narray; i++ )
	{
		if( *(*arr+i) )
		{ delete[] *(*arr+i); }
	}

	if( Narray )
	{ delete[]( *arr ); }

	(*arr) = nullptr;
};

//________________________________________________________________
//
//

}

#endif