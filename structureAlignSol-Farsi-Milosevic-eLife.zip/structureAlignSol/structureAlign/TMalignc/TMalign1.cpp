//
/*
===============================================================================
   Implementation of TM-align in C/C++

   This program is written by Jianyi Yang at
   Yang Zhang lab
   And it is updated by Jianjie Wu at
   Yang Zhang lab
   Department of Computational Medicine and Bioinformatics
   University of Michigan
   100 Washtenaw Avenue, Ann Arbor, MI 48109-2218

   Please report bugs and questions to jianjiew@umich.edu or zhng@umich.edu
===============================================================================
*/

#include "TMalign.h"

#include <algorithm>

namespace sciloop
{
//_____________________________________________________________
//
//
bool TMalignc::load_PDB_allocate_memory( const svdMatrix<float> & sourcePoints,
										 const svdMatrix<float> & targetPoints )
{

	// We want the Ca count.
	// What we have is all main chain atoms.
	//
	tempSourceLen_ = sourcePoints.GetRows()/3;
	tempTargetLen_ = sourcePoints.GetRows()/3;


	//------allocate memory for source and target------>
	//
	NewArray( &coordsSource_, tempSourceLen_, 3 );
	seqSource_   = new char[tempSourceLen_ + 1];
	secSource_   = new int[tempSourceLen_];
	sourceResNo_ = new int[tempSourceLen_];

	NewArray( &coordsTarget_, tempTargetLen_, 3 );
	seqTarget_   = new char[tempTargetLen_ + 1];
	targetResNo_ = new int[tempTargetLen_];
	secTarget_   = new int[tempTargetLen_];

	// Get exact length
	//
	read_PDB( sourcePoints, targetPoints );
	sourceResLen_ = tempSourceLen_;
	targetResLen_ = tempTargetLen_;
	minResLen_    = std::min(sourceResLen_, targetResLen_);


	//------allocate memory for other temporary variables------>
	//
	NewArray( &r1_, minResLen_, 3 );
	NewArray( &r2_, minResLen_, 3 );
	NewArray( &sourceTm_, minResLen_, 3 );
	NewArray( &targetTm_, minResLen_, 3 );
	NewArray( &source_t_, sourceResLen_, 3 );

	NewArray( &score_, sourceResLen_+1, targetResLen_+1 );
	NewArray( &path_, sourceResLen_+1, targetResLen_+1 );
	NewArray( &val_, sourceResLen_+1, targetResLen_+1 );

	return true;
}

//_____________________________________________________________
//
//
bool TMalignc::checkArrLen( svdMatrix<float> & sourcePoints,
							svdMatrix<float> & targetPoints )
{
	unsigned sourceRowLen = sourcePoints.GetRows();
	unsigned sourceColumsLen = sourcePoints.GetCols();
	unsigned sourceRowLen_3 = sourceRowLen/3;

	if( structureType_==structureType_e::kProtein )
	{
		if( sourceRowLen_3%3!=0 )
		{
			svdMatrix<float> tmpS, tmpT;
			tmpS = sourcePoints;
			tmpT = targetPoints;

			sourcePoints.setRowAndCol( sourceRowLen_3*3, sourceColumsLen );
			targetPoints.setRowAndCol( sourceRowLen_3*3, sourceColumsLen );

			for( unsigned i=0, l=sourceRowLen_3*3; i<l; i++ )
			{
				for( unsigned k=0; k<sourceColumsLen; k++ )
				{
					sourcePoints[i][k] = tmpS[i][k];
					targetPoints[i][k] = tmpT[i][k];
				}
			}

			cout << " WARNING : sourceType is set to protein,"
				"but row arr len is not a multiple of 3: " << sourcePoints.GetRows() <<
				" reduced to : " << sourceRowLen_3*3 <<endl;
		}
	}

	return true;
}

//_____________________________________________________________
//
//
void TMalignc::free_memory()
{
	DeleteArray( &path_, sourceResLen_+1);
	DeleteArray( &val_, sourceResLen_+1);
	DeleteArray( &score_, sourceResLen_+1);
	DeleteArray( &coordsSource_, tempSourceLen_);
	DeleteArray( &source_t_, sourceResLen_);
	DeleteArray( &coordsTarget_, tempTargetLen_);
	DeleteArray( &r1_, minResLen_);
	DeleteArray( &r2_, minResLen_);
	DeleteArray( &sourceTm_, minResLen_);
	DeleteArray( &targetTm_, minResLen_);

	delete [] seqSource_;
	delete [] seqTarget_;
	delete [] secSource_;
	delete [] secTarget_;
	delete [] sourceResNo_;
	delete [] targetResNo_;
}

//_____________________________________________________________
//
//
// 1, collect those residues with dis<d;
// 2, calculate TMscore
//
int TMalignc::score_fun8(	double **coordsSource_,
							double **coordsTarget_,
							int n_ali,
							double d,
							int i_ali[],
							double *score1,
							int score_sum_method  )
{
	double score_sum = 0, di;
	double d_tmp = d*d;
	double d02 = d0_*d0_;
	double score_d8_cut = score_d8_*score_d8_;

	int i, n_cut, inc = 0;

	while( 1 )
	{
		n_cut = 0;
		score_sum = 0;

		for( i=0; i<n_ali; i++ )
		{
			di = dist(coordsSource_[i], coordsTarget_[i]);

			if(di<d_tmp)
			{
				i_ali[n_cut]=i;
				n_cut++;
			}

			if( score_sum_method==8 )
			{
				if(di<=score_d8_cut)
				{score_sum += 1/(1+di/d02);}
			}
			else
			{score_sum += 1/(1+di/d02);}
		}

		//there are not enough feasible pairs, reliefe the threshold
		//
		if(n_cut<3 && n_ali>3)
		{
			inc++;
			double dinc=(d+inc*0.5);
			d_tmp = dinc * dinc;
		}
		else
		{break;}

	}

	*score1 = score_sum/Lnorm_;

	return n_cut;
}

//_____________________________________________________________
//
//
//     1, collect those residues with dis<d;
//     2, calculate TMscore
int TMalignc::score_fun8(	double **coordsSource_,
							double **coordsTarget_,
							int n_ali,
							double d,
							vector<int> & i_ali,
							double *score1,
							int score_sum_method )
{
	double score_sum = 0, di;
	double d_tmp = d*d;
	double d02 = d0_*d0_;
	double score_d8_cut = score_d8_*score_d8_;

	int i, n_cut, inc = 0;

	while( 1 )
	{
		n_cut = 0;
		score_sum = 0;

		for( i=0; i<n_ali; i++ )
		{
			di = dist( coordsSource_[i], coordsTarget_[i] );

			if( di<d_tmp )
			{
				i_ali[n_cut]=i;
				n_cut++;
			}

			if( score_sum_method==8 )
			{
				if( di<=score_d8_cut )
				{ score_sum += 1/(1+di/d02); }
			}
			else
			{ score_sum += 1/(1+di/d02); }
		}

		//there are not enough feasible pairs, reliefe the threshold
		//
		if( n_cut<3 && n_ali>3 )
		{
			inc++;
			double dinc = (d+inc*0.5);
			d_tmp = dinc * dinc;
		}
		else
		{ break; }

	}

	*score1 = score_sum/Lnorm_;

	return n_cut;
}


//_____________________________________________________________
//
//
int TMalignc::score_fun8_standard(	double **coordsSource_,
									double **coordsTarget_,
									int n_ali,
									double d,
									int i_ali[],
									double *score1,
									int score_sum_method )
{
	double score_sum = 0, di;
	double d_tmp = d*d;
	double d02 = d0_*d0_;
	double score_d8_cut = score_d8_*score_d8_;

	int i, n_cut, inc = 0;

	while (1)
	{
		n_cut = 0;
		score_sum = 0;

		for (i = 0; i<n_ali; i++)
		{
			di = dist(coordsSource_[i], coordsTarget_[i]);

			if (di<d_tmp)
			{
				i_ali[n_cut] = i;
				n_cut++;
			}

			if (score_sum_method == 8)
			{
				if (di <= score_d8_cut)
				{score_sum += 1 / (1 + di / d02);}
			}
			else
			{score_sum += 1 / (1 + di / d02);}
		}

		//there are not enough feasible pairs, reliefe the threshold
		//
		if (n_cut<3 && n_ali>3)
		{
			inc++;
			double dinc = (d + inc*0.5);
			d_tmp = dinc * dinc;
		}
		else
		{break;}

	}

	*score1 = score_sum / n_ali;
	return n_cut;
}

//_____________________________________________________________
//
//
int TMalignc::score_fun8_standard(	double **coordsSource_,
									double **coordsTarget_,
									int n_ali,
									double d,
									vector<int> & i_ali,
									double *score1,
									int score_sum_method )
{
	double score_sum = 0, di;
	double d_tmp = d*d;
	double d02 = d0_*d0_;
	double score_d8_cut = score_d8_*score_d8_;

	int i, n_cut, inc = 0;

	while( 1 )
	{
		n_cut = 0;
		score_sum = 0;

		for( i=0; i<n_ali; i++ )
		{
			di = dist( coordsSource_[i], coordsTarget_[i] );

			if( di<d_tmp )
			{
				i_ali[n_cut] = i;
				n_cut++;
			}

			if( score_sum_method == 8 )
			{
				if( di<=score_d8_cut )
				{ score_sum += 1 / (1 + di / d02); }
			}
			else
			{ score_sum += 1 / (1 + di / d02); }
		}

		//there are not enough feasible pairs, reliefe the threshold
		//
		if( n_cut<3 && n_ali>3 )
		{
			inc++;
			double dinc = (d + inc*0.5);
			d_tmp = dinc * dinc;
		}
		else
		{ break; }

	}

	*score1 = score_sum / n_ali;
	return n_cut;
}

//_____________________________________________________________
//
//
double TMalignc::TMscore8_search(	double	** sourceTm_global,
									double	** targetTm_global,
									int		   Lali,
									double	   t0[3],
									double	   u0[3][3],
									int		   simplify_step,
									int		   score_sum_method,
									double	*  Rcomm,
									double	   local_d0_search )
{
	int i, m;
	double score_max, score, rmsd;
	const int kmax = Lali;
	vector<int> k_ali( kmax );
	int ka, k;
	//int k_ali[kmax], ka, k;
	double t_local[3];
	double u_local[3][3];
	double d;

	//iterative parameters
	//
	int n_it = 20;            //maximum number of iterations
	const int n_init_max = 6; //maximum number of different fragment length
	int L_ini[n_init_max];  //fragment lengths, Lali, Lali/2, Lali/4 ... 4
	int L_ini_min = 4;

	if( Lali<4 )
	{ L_ini_min = Lali; }

	int n_init = 0, i_init;

	for( i=0; i<n_init_max-1; i++ )
	{
		n_init++;
		L_ini[i]=(int) (Lali/pow(2.0, (double) i));

		if( L_ini[i]<=L_ini_min )
		{
			L_ini[i] = L_ini_min;
			break;
		}
	}

	if( i==n_init_max-1 )
	{
		n_init++;
		L_ini[i] = L_ini_min;
	}

	score_max = -1;

	// find the maximum score starting from local structures superposition
	//
	vector<int> i_ali( kmax );
	int n_cut;
	int L_frag; //fragment length
	int iL_max; //maximum starting postion for the fragment

	for( i_init=0; i_init<n_init; i_init++ )
	{
		L_frag = L_ini[i_init];
		iL_max = Lali-L_frag;

		i=0;

		while( 1 )
		{
			// extract the fragment starting from position i
			//
			ka = 0;

			for( k=0; k<L_frag; k++ )
			{
				int kk = k+i;
				r1_[k][0] = sourceTm_global[kk][0];
				r1_[k][1] = sourceTm_global[kk][1];
				r1_[k][2] = sourceTm_global[kk][2];

				r2_[k][0] = targetTm_global[kk][0];
				r2_[k][1] = targetTm_global[kk][1];
				r2_[k][2] = targetTm_global[kk][2];

				k_ali[ka] = kk;
				ka++;
			}

			// extract rotation matrix based on the fragment
			//
			Kabsch(	r1_,
					r2_,
					L_frag,
					1,
					&rmsd,
					t_local,
					u_local );

			if( simplify_step!=1 )
			{ *Rcomm = 0; }

			do_rotation( sourceTm_global, source_t_, Lali, t_local, u_local );

			// get subsegment of this fragment
			//
			d = local_d0_search - 1;

			n_cut = score_fun8(	source_t_,
								targetTm_global,
								Lali,
								d,
								i_ali,
								&score,
								score_sum_method );

			if( score>score_max )
			{
				score_max = score;

				// save the rotation matrix
				//
				for( k=0; k<3; k++ )
				{
					t0[k] = t_local[k];
					u0[k][0] = u_local[k][0];
					u0[k][1] = u_local[k][1];
					u0[k][2] = u_local[k][2];
				}
			}

			// try to extend the alignment iteratively
			//
			d = local_d0_search + 1;

			for( int it=0; it<n_it; it++ )
			{
				ka=0;

				for( k=0; k<n_cut; k++ )
				{
					m = i_ali[k];
					r1_[k][0] = sourceTm_global[m][0];
					r1_[k][1] = sourceTm_global[m][1];
					r1_[k][2] = sourceTm_global[m][2];

					r2_[k][0] = targetTm_global[m][0];
					r2_[k][1] = targetTm_global[m][1];
					r2_[k][2] = targetTm_global[m][2];

					k_ali[ka] = m;
					ka++;
				}

				// extract rotation matrix based on the fragment
				//
				Kabsch( r1_, r2_, n_cut, 1, &rmsd, t_local, u_local );

				do_rotation( sourceTm_global, source_t_, Lali, t_local, u_local );

				n_cut = score_fun8(	source_t_,
									targetTm_global,
									Lali,
									d,
									i_ali,
									&score,
									score_sum_method);

				if( score>score_max )
				{
					score_max = score;

					// save the rotation matrix
					//
					for( k=0; k<3; k++ )
					{
						t0[k] = t_local[k];
						u0[k][0] = u_local[k][0];
						u0[k][1] = u_local[k][1];
						u0[k][2] = u_local[k][2];
					}
				}

				// check if it converges
				//
				if( n_cut==ka )
				{
					for( k=0; k<n_cut; k++ )
					{
						if( i_ali[k]!=k_ali[k] )
						{break;}
					}

					// stop iteration
					//
					if( k==n_cut )
					{break;}

				}
			}

			if( i<iL_max )
			{
				// shift the fragment
				//
				i = i + simplify_step;

				// do this to use the last missed fragment
				//
				if( i>iL_max )
				{ i=iL_max; }
			}
			else if( i>=iL_max )
			{break;}
		}
	}

	return score_max;
}

//_____________________________________________________________
//
//
double TMalignc::TMscore8_search_standard(	double **sourceTm_global,
											double **targetTm_global,
											int Lali,
											double t0[3],
											double u0[3][3],
											int simplify_step,
											int score_sum_method,
											double *Rcomm,
											double local_d0_search )
{
	int i, m;
	double score_max, score, rmsd;
	const int kmax = Lali;
	vector<int> k_ali( kmax );
	int ka, k;
	double t_local[3];
	double u_local[3][3];
	double d;


	//iterative parameters
	//
	int n_it = 20;            //maximum number of iterations
	const int n_init_max = 6; //maximum number of different fragment length
	int L_ini[n_init_max];  //fragment lengths, Lali, Lali/2, Lali/4 ... 4
	int L_ini_min = 4;

	if( Lali<4 )
	{ L_ini_min = Lali; }

	int n_init = 0, i_init;

	for (i = 0; i<n_init_max - 1; i++)
	{
		n_init++;
		L_ini[i] = (int)(Lali / pow(2.0, (double)i));

		if (L_ini[i] <= L_ini_min)
		{
			L_ini[i] = L_ini_min;
			break;
		}
	}

	if (i == n_init_max - 1)
	{
		n_init++;
		L_ini[i] = L_ini_min;
	}

	score_max = -1;

	//find the maximum score_ starting from local structures superposition
	//
	vector<int> i_ali( kmax );
	int n_cut;
	int L_frag; //fragment length
	int iL_max; //maximum starting postion for the fragment

	for (i_init = 0; i_init<n_init; i_init++)
	{
		L_frag = L_ini[i_init];
		iL_max = Lali - L_frag;

		i = 0;

		while (1)
		{
			//extract the fragment starting from position i
			ka = 0;

			for (k = 0; k<L_frag; k++)
			{
				int kk = k + i;
				r1_[k][0] = sourceTm_global[kk][0];
				r1_[k][1] = sourceTm_global[kk][1];
				r1_[k][2] = sourceTm_global[kk][2];

				r2_[k][0] = targetTm_global[kk][0];
				r2_[k][1] = targetTm_global[kk][1];
				r2_[k][2] = targetTm_global[kk][2];

				k_ali[ka] = kk;
				ka++;
			}

			// extract rotation matrix based on the fragment
			//
			Kabsch( r1_, r2_, L_frag, 1, &rmsd, t_local, u_local );

			if(simplify_step != 1)
				*Rcomm = 0;

			do_rotation( sourceTm_global, source_t_, Lali, t_local, u_local );

			// get subsegment of this fragment
			//
			d = local_d0_search - 1;
			n_cut = score_fun8_standard(	source_t_,
											targetTm_global,
											Lali,
											d,
											i_ali,
											&score,
											score_sum_method);

			if (score>score_max)
			{
				score_max = score;

				//save the rotation matrix
				for (k = 0; k<3; k++)
				{
					t0[k] = t_local[k];
					u0[k][0] = u_local[k][0];
					u0[k][1] = u_local[k][1];
					u0[k][2] = u_local[k][2];
				}
			}

			//try to extend the alignment iteratively
			d = local_d0_search + 1;

			for (int it = 0; it<n_it; it++)
			{
				ka = 0;

				for (k = 0; k<n_cut; k++)
				{
					m = i_ali[k];
					r1_[k][0] = sourceTm_global[m][0];
					r1_[k][1] = sourceTm_global[m][1];
					r1_[k][2] = sourceTm_global[m][2];

					r2_[k][0] = targetTm_global[m][0];
					r2_[k][1] = targetTm_global[m][1];
					r2_[k][2] = targetTm_global[m][2];

					k_ali[ka] = m;
					ka++;
				}

				// extract rotation matrix based on the fragment
				//
				Kabsch( r1_, r2_, n_cut, 1, &rmsd, t_local, u_local );

				do_rotation( sourceTm_global, source_t_, Lali, t_local, u_local );

				n_cut = score_fun8_standard(	source_t_,
											 targetTm_global,
												Lali,
												d,
												i_ali,
												&score,
												score_sum_method);

				if (score>score_max)
				{
					score_max = score;

					// save the rotation matrix
					//
					for (k = 0; k<3; k++)
					{
						t0[k] = t_local[k];
						u0[k][0] = u_local[k][0];
						u0[k][1] = u_local[k][1];
						u0[k][2] = u_local[k][2];
					}
				}

				// check if it converges
				//
				if (n_cut == ka)
				{
					for (k = 0; k<n_cut; k++)
					{
						if (i_ali[k] != k_ali[k])
						{break;}
					}

					if (k == n_cut)
					{break;} //stop iteration

				}
			} //for iteration

			if (i<iL_max)
			{
				i = i + simplify_step; //shift the fragment

				if (i>iL_max)
					i = iL_max;  //do this to use the last missed fragment
			}
			else if (i >= iL_max)
			{break;}
		}
	}
	return score_max;
}

//_____________________________________________________________
//
double TMalignc::detailed_search(	double **x,
									double **y,
									int x_len,
									int y_len,
									int invmap0[],
									double t_global[3],
									double u_global[3][3],
									int simplify_step,
									int score_sum_method,
									double local_d0_search )
{
	//x is model, y is template, try to superpose onto y
	int i, j, k;
	double tmscore;
	double rmsd;

	k=0;

	for( i=0; i<y_len; i++ )
	{
		j = invmap0[i];

		// aligned
		//
		if( j>=0 )
		{
			sourceTm_[k][0] = x[j][0];
			sourceTm_[k][1] = x[j][1];
			sourceTm_[k][2] = x[j][2];

			targetTm_[k][0] = y[i][0];
			targetTm_[k][1] = y[i][1];
			targetTm_[k][2] = y[i][2];
			k++;
		}
	}

	// detailed search 40-->1
	//
	tmscore = TMscore8_search(	sourceTm_,
								targetTm_,
								k,
								t_global,
								u_global,
								simplify_step,
								score_sum_method,
								&rmsd,
								local_d0_search );
	return tmscore;
}

//_____________________________________________________________
//
//
double TMalignc::detailed_search_standard(	double **x,
											double **y,
											int x_len,
											int y_len,
											int invmap0[],
											double t_global[3],
											double u_global[3][3],
											int simplify_step,
											int score_sum_method,
											double local_d0_search,
											const bool& bNormalize )
{
	//x is model, y is template, try to superpose onto y
	//
	int i, j, k;
	double tmscore;
	double rmsd;

	k=0;

	for( i=0; i<y_len; i++ )
	{
		j=invmap0[i];

		if( j>=0 ) //aligned
		{
			sourceTm_[k][0] = x[j][0];
			sourceTm_[k][1] = x[j][1];
			sourceTm_[k][2] = x[j][2];

			targetTm_[k][0] = y[i][0];
			targetTm_[k][1] = y[i][1];
			targetTm_[k][2] = y[i][2];
			k++;
		}
	}

	//detailed search 40-->1
	//
	tmscore = TMscore8_search_standard(	sourceTm_,
										targetTm_,
										k,
										t_global,
										u_global,
										simplify_step,
										score_sum_method,
										&rmsd,
										local_d0_search);

	// "-i", to use standard_TMscore, then bNormalize=true, else bNormalize=false;
	//
	if (bNormalize)
		tmscore = tmscore * k / Lnorm_;

	return tmscore;
}

//_____________________________________________________________
//
//
//compute the score_ quickly in three iterations
//
double TMalignc::get_score_fast(	double **coordsSource,
									double **coordsTarget,
									int sourceLen,
									int targetLen,
									int invmap[])
{
	double rms, tmscore, tmscore1, tmscore2;
	int i, j, k;

	k=0;

	for( j=0; j<targetLen; j++ )
	{
		i = invmap[j];

		if( i>=0 )
		{
			r1_[k][0] = coordsSource[i][0];
			r1_[k][1] = coordsSource[i][1];
			r1_[k][2] = coordsSource[i][2];

			r2_[k][0] = coordsTarget[j][0];
			r2_[k][1] = coordsTarget[j][1];
			r2_[k][2] = coordsTarget[j][2];

			sourceTm_[k][0] = coordsSource[i][0];
			sourceTm_[k][1] = coordsSource[i][1];
			sourceTm_[k][2] = coordsSource[i][2];

			targetTm_[k][0] = coordsTarget[j][0];
			targetTm_[k][1] = coordsTarget[j][1];
			targetTm_[k][2] = coordsTarget[j][2];

			k++;
		}
		else if( i!=-1 )
		{
			if(!PrintErrorAndQuit("Wrong map!\n") )
			{ return -9999.0; }
		}
	}

	Kabsch( r1_, r2_, k, 1, &rms, t_, u_ );

	// evaluate score
	//
	double di;
	const int len = k;
	vector<double> dis( len );

	double d00 = d0_search_;
	double d002 = d00*d00;
	double d02 = d0_*d0_;

	int n_ali = k;
	double xrot[3];
	tmscore = 0;

	for( k=0; k<n_ali; k++ )
	{
		transform( t_, u_, &sourceTm_[k][0], xrot );
		di = dist( xrot, &targetTm_[k][0] );
		dis[k] = di;
		tmscore += 1/(1+di/d02);
	}

	// second iteration
	//
	double d002t = d002;

	while( 1 )
	{
		j = 0;

		for( k=0; k<n_ali; k++ )
		{
			if( dis[k]<=d002t )
			{
				r1_[j][0] = sourceTm_[k][0];
				r1_[j][1] = sourceTm_[k][1];
				r1_[j][2] = sourceTm_[k][2];

				r2_[j][0] = targetTm_[k][0];
				r2_[j][1] = targetTm_[k][1];
				r2_[j][2] = targetTm_[k][2];

				j++;
			}
		}

		// there are not enough feasible pairs, relieve the threshold
		//
		if( j<3 && n_ali>3 )
		{d002t += 0.5;}
		else
		{break;}
	}

	if( n_ali!=j )
	{
		Kabsch( r1_, r2_, j, 1, &rms, t_, u_ );
		tmscore1 = 0;

		for( k=0; k<n_ali; k++ )
		{
			transform( t_, u_, &sourceTm_[k][0], xrot );
			di = dist( xrot, &targetTm_[k][0] );
			dis[k] = di;
			tmscore1 += 1/(1+di/d02);
		}

		// third iteration
		//
		d002t = d002+1;

		while( 1 )
		{
			j=0;

			for( k=0; k<n_ali; k++ )
			{
				if( dis[k]<=d002t )
				{
					r1_[j][0] = sourceTm_[k][0];
					r1_[j][1] = sourceTm_[k][1];
					r1_[j][2] = sourceTm_[k][2];

					r2_[j][0] = targetTm_[k][0];
					r2_[j][1] = targetTm_[k][1];
					r2_[j][2] = targetTm_[k][2];

					j++;
				}
			}

			// there are not enough feasible pairs, relieve the threshold
			//
			if( j<3 && n_ali>3 )
			{d002t += 0.5;}
			else
			{break;}
		}

		// evaluate the score
		//
		Kabsch( r1_, r2_, j, 1, &rms, t_, u_ );
		tmscore2 = 0;

		for( k=0; k<n_ali; k++ )
		{
			transform( t_, u_, &sourceTm_[k][0], xrot );
			di = dist( xrot, &targetTm_[k][0] );
			tmscore2 += 1/(1+di/d02);
		}
	}
	else
	{
		tmscore1 = tmscore;
		tmscore2 = tmscore;
	}


	if( tmscore1>=tmscore )
		tmscore = tmscore1;

	if( tmscore2>=tmscore )
		tmscore = tmscore2;

	// no need to normalize this score
	// because it will not be used for latter scoring
	//
	return tmscore;
}

//_____________________________________________________________
//
double TMalignc::get_initial(	double	** coordsSource,
								double	** coordsTarget,
								int		   sourceLen,
								int		   targetLen,
								int		*  y2x )
{
	int min_len = getmin( sourceLen, targetLen );

	if( min_len<=5 )
	{
		cout << "Sequence is too short <=5!\n";
		return -9999.0;
	}

	// minimum size of considered fragment
	//
	int min_ali = min_len/2;

	if( min_ali<=5 )
	{ min_ali = 5; }

	int n1, n2;
	n1 = -targetLen + min_ali;
	n2 = sourceLen - min_ali;

	int i, j, k, k_best;
	double tmscore, tmscore_max = -1;

	k_best = n1;

	for( k=n1; k<=n2; k++ )
	{
		// get the map
		//
		for( j=0; j<targetLen; j++ )
		{
			i = j+k;

			if( i>=0 && i<sourceLen )
			{y2x[j] = i;}
			else
			{y2x[j] = -1;}
		}

		// evaluate the map quickly in three iterations
		// this is not real tmscore, it is used to evaluate
		// the goodness of the initial alignment
		//
		tmscore = get_score_fast(	coordsSource,
									coordsTarget,
									sourceLen,
									targetLen,
									y2x );

		if( tmscore>=tmscore_max )
		{
			tmscore_max = tmscore;
			k_best = k;
		}
	}

	// extract the best map
	//
	k = k_best;

	for( j=0; j<targetLen; j++ )
	{
		i = j+k;

		if( i>=0 && i<sourceLen )
		{y2x[j] = i;}
		else
		{y2x[j] = -1;}
	}

	return tmscore_max;
}

//_____________________________________________________________
//
//
void TMalignc::smooth( int *sec, int len )
{
	int i, j;

	//smooth single  --x-- => -----
	//
	for( i=2; i<len-2; i++ )
	{
		if( sec[i]==2 || sec[i]==4 )
		{
			j = sec[i];

			if( sec[i-2]!=j )
			{
				if( sec[i-1]!=j )
				{
					if( sec[i+1]!=j )
					{
						if( sec[i+2]!=j )
						{sec[i] = 1;}
					}
				}
			}
		}
	}

	//   smooth double
	//   --xx-- => ------

	for( i=0; i<len-5; i++ )
	{
		//helix
		if(sec[i] != 2)
		{
			if(sec[i+1] != 2)
			{
				if(sec[i+2] == 2)
				{
					if(sec[i+3] == 2)
					{
						if(sec[i+4] != 2)
						{
							if(sec[i+5] != 2)
							{
								sec[i+2]=1;
								sec[i+3]=1;
							}
						}
					}
				}
			}
		}

		//beta
		if( sec[i] != 4 )
		{
			if(sec[i+1] != 4)
			{
				if(sec[i+2] ==4)
				{
					if(sec[i+3] == 4)
					{
						if(sec[i+4] != 4)
						{
							if(sec[i+5] != 4)
							{
								sec[i+2]=1;
								sec[i+3]=1;
							}
						}
					}
				}
			}
		}
	}

	//smooth connect
	for( i=0; i<len-2; i++ )
	{
		if(sec[i] == 2)
		{
			if(sec[i+1] != 2)
			{
				if(sec[i+2] == 2)
				{sec[i+1]=2;}
			}
		}
		else if(sec[i] == 4)
		{
			if(sec[i+1] != 4)
			{
				if(sec[i+2] == 4)
				{sec[i+1]=4;}
			}
		}
	}

}

//_____________________________________________________________
//
//
int TMalignc::sec_str(	double dis13,
						double dis14,
						double dis15,
						double dis24,
						double dis25,
						double dis35 )
{
	int s=1;

	double delta=2.1;

	if(fabs(dis15-6.37)<delta)
	{
		if(fabs(dis14-5.18)<delta)
		{
			if(fabs(dis25-5.18)<delta)
			{
				if(fabs(dis13-5.45)<delta)
				{
					if(fabs(dis24-5.45)<delta)
					{
						if(fabs(dis35-5.45)<delta)
						{
							s=2; //helix
							return s;
						}
					}
				}
			}
		}
	}

	delta=1.42;

	if(fabs(dis15-13)<delta)
	{
		if(fabs(dis14-10.4)<delta)
		{
			if(fabs(dis25-10.4)<delta)
			{
				if(fabs(dis13-6.1)<delta)
				{
					if(fabs(dis24-6.1)<delta)
					{
						if(fabs(dis35-6.1)<delta)
						{
							s=4; //strand
							return s;
						}
					}
				}
			}
		}
	}

	if(dis15 < 8)
	{s=3;} //turn

	return s;
}

//_____________________________________________________________
//
//
// 1->coil, 2->helix, 3->turn, 4->strand
//
void TMalignc::make_sec( double **x, int len, int *sec )
{
	int j1, j2, j3, j4, j5;
	double d13, d14, d15, d24, d25, d35;

	for( int i=0; i<len; i++ )
	{
		sec[i]=1;
		j1=i-2;
		j2=i-1;
		j3=i;
		j4=i+1;
		j5=i+2;

		if( j1>=0 && j5<len )
		{
			d13 = sqrt( dist(x[j1], x[j3]) );
			d14 = sqrt( dist(x[j1], x[j4]) );
			d15 = sqrt( dist(x[j1], x[j5]) );
			d24 = sqrt( dist(x[j2], x[j4]) );
			d25 = sqrt( dist(x[j2], x[j5]) );
			d35 = sqrt( dist(x[j3], x[j5]) );

			sec[i] = sec_str( d13, d14, d15, d24, d25, d35 );
		}
	}
}

//_____________________________________________________________
//
void TMalignc::get_initial_ss(	double **x,
								double **y,
								int x_len,
								int y_len,
								int *y2x )
{
	// assign secondary structures
	//
	make_sec( x, x_len, secSource_ );
	make_sec( y, y_len, secTarget_ );

	double gap_open = -1.0;
	NWDP_TM( secSource_, secTarget_, x_len, y_len, gap_open, y2x );
}

//_____________________________________________________________
//
bool TMalignc::get_initial5(	double **x,
								double **y,
								int x_len,
								int y_len,
								int *y2x )
{
	double GL, rmsd;
	double t[3];
	double u[3][3];

	double d01 = d0_ + 1.5;

	if (d01 < D0_MIN_)
		d01 = D0_MIN_;

	double d02 = d01*d01;

	double GLmax = 0;
	int aL = getmin(x_len, y_len);
	int *invmap = new int[y_len + 1];

	// jump on sequence1-------------->
	int n_jump1 = 0;

	if (x_len > 250)
		n_jump1 = 45;
	else if (x_len > 200)
		n_jump1 = 35;
	else if (x_len > 150)
		n_jump1 = 25;
	else
		n_jump1 = 15;

	if (n_jump1 > (x_len / 3))
		n_jump1 = x_len / 3;

	// jump on sequence2-------------->
	int n_jump2 = 0;

	if (y_len > 250)
		n_jump2 = 45;
	else if (y_len > 200)
		n_jump2 = 35;
	else if (y_len > 150)
		n_jump2 = 25;
	else
		n_jump2 = 15;

	if (n_jump2 > (y_len / 3))
		n_jump2 = y_len / 3;

	// fragment to superimpose-------------->
	int n_frag[2] = { 20, 100 };

	if (n_frag[0] > (aL / 3))
		n_frag[0] = aL / 3;

	if (n_frag[1] > (aL / 2))
		n_frag[1] = aL / 2;

	// start superimpose search-------------->
	bool flag = false;

	for (int i_frag = 0; i_frag < 2; i_frag++)
	{
		int m1 = x_len - n_frag[i_frag] + 1;
		int m2 = y_len - n_frag[i_frag] + 1;

		// for debug
		for (int i = 0; i<m1; i = i + n_jump1) //index starts from 0, different from FORTRAN
		{
			//for (int j = 1; j<m2; j = j + n_jump2)
			for (int j = 0; j<m2; j = j + n_jump2)
			{
				for (int k = 0; k<n_frag[i_frag]; k++) //fragment in y
				{
					r1_[k][0] = x[k + i][0];
					r1_[k][1] = x[k + i][1];
					r1_[k][2] = x[k + i][2];

					r2_[k][0] = y[k + j][0];
					r2_[k][1] = y[k + j][1];
					r2_[k][2] = y[k + j][2];
				}

				// superpose the two structures and rotate it
				Kabsch( r1_, r2_, n_frag[i_frag], 1, &rmsd, t, u );

				double gap_open = 0.0;

				NWDP_TM(x, y, x_len, y_len, t, u, d02, gap_open, invmap);
				GL = get_score_fast(x, y, x_len, y_len, invmap);

				if (GL>GLmax)
				{
					GLmax = GL;

					for (int ii = 0; ii<y_len; ii++)
					{y2x[ii] = invmap[ii];}

					flag = true;
				}
			}
		}
	}
	delete[] invmap;
	return flag;
}

//_____________________________________________________________
//
//
//with invmap(i) calculate score_(i,j) using RMSD rotation
void TMalignc::score_matrix_rmsd(	double **x,
									double **y,
									int x_len,
									int y_len,
									int *y2x )
{
	double t[3], u[3][3];
	double rmsd, dij;
	double d01=d0_+1.5;

	if(d01 < D0_MIN_)
		d01=D0_MIN_;

	double d02=d01*d01;

	double xx[3];
	int i, k=0;

	for(int j=0; j<y_len; j++)
	{
		i=y2x[j];

		if(i>=0)
		{
			r1_[k][0]=x[i][0];
			r1_[k][1]=x[i][1];
			r1_[k][2]=x[i][2];

			r2_[k][0]=y[j][0];
			r2_[k][1]=y[j][1];
			r2_[k][2]=y[j][2];

			k++;
		}
	}

	Kabsch( r1_, r2_, k, 1, &rmsd, t, u );

	for(int ii=0; ii<x_len; ii++)
	{
		transform(t, u, &x[ii][0], xx);

		for( int jj=0; jj<y_len; jj++ )
		{
			dij=dist(xx, &y[jj][0]);
			score_[ii+1][jj+1] = 1.0/(1+dij/d02);
		}
	}
}

//_____________________________________________________________
//
//
void TMalignc::score_matrix_rmsd_sec(	double **x,
										double **y,
										int x_len,
										int y_len,
										int *y2x )
{
	double t[3], u[3][3];
	double rmsd, dij;
	double d01=d0_+1.5;

	if(d01 < D0_MIN_)
		d01=D0_MIN_;

	double d02=d01*d01;

	double xx[3];
	int i, k=0;

	for( int j=0; j<y_len; j++ )
	{
		i=y2x[j];

		if(i>=0)
		{
			r1_[k][0]=x[i][0];
			r1_[k][1]=x[i][1];
			r1_[k][2]=x[i][2];

			r2_[k][0]=y[j][0];
			r2_[k][1]=y[j][1];
			r2_[k][2]=y[j][2];

			k++;
		}
	}

	Kabsch( r1_, r2_, k, 1, &rmsd, t, u );


	for( int ii=0; ii<x_len; ii++ )
	{
		transform(t, u, &x[ii][0], xx);

		for( int jj=0; jj<y_len; jj++ )
		{
			dij=dist(xx, &y[jj][0]);

			if( secSource_[ii]==secTarget_[jj] )
			{score_[ii+1][jj+1] = 1.0/(1+dij/d02) + 0.5;}
			else
			{score_[ii+1][jj+1] = 1.0/(1+dij/d02);}
		}
	}
}

//_____________________________________________________________
//
//
void TMalignc::get_initial_ssplus(	double **x,
									 double **y,
									 int x_len,
									 int y_len,
									 int *y2x0,
									 int *y2x )
{

	//create score_ matrix for DP
	score_matrix_rmsd_sec(x, y, x_len, y_len, y2x0);

	double gap_open=-1.0;
	NWDP_TM(x_len, y_len, gap_open, y2x);
}

//_____________________________________________________________
//
//
void TMalignc::find_max_frag(	double **x,
								int *resno,
								int len,
								int *start_max,
								int *end_max)
{
	int r_min, fra_min=4;           //minimum fragment for search
	double d;
	int start;
	int Lfr_max=0, flag;

	r_min= (int) (len*1.0/3.0); //minimum fragment, in case too small protein
	if(r_min > fra_min) r_min=fra_min;

	int inc=0;
	double dcu0_cut=dcu0_*dcu0_;;
	double dcu_cut=dcu0_cut;

	while(Lfr_max < r_min)
	{
		Lfr_max=0;
		int j=1;    //number of residues at nf-fragment
		start=0;
		for(int i=1; i<len; i++)
		{
			d = dist(x[i-1], x[i]);
			flag=0;

			if(dcu_cut>dcu0_cut)
			{
				if(d<dcu_cut)
				{flag=1;}
			}
			else if(resno[i] == (resno[i-1]+1)) //necessary??
			{
				if(d<dcu_cut)
				{flag=1;}
			}

			if(flag==1)
			{
				j++;

				if(i==(len-1))
				{
					if(j > Lfr_max)
					{
						Lfr_max=j;
						*start_max=start;
						*end_max=i;
					}
					j=1;
				}
			}
			else
			{
				if(j>Lfr_max)
				{
					Lfr_max=j;
					*start_max=start;
					*end_max=i-1;
				}

				j=1;
				start=i;
			}
		}// for i;

		if(Lfr_max < r_min)
		{
			inc++;
			double dinc=pow(1.1, (double) inc) * dcu0_;
			dcu_cut= dinc*dinc;
		}
	}//while <;
}

//_____________________________________________________________
//
//
//perform fragment gapless threading to find the best initial alignment
//input: x, y, x_len, y_len
//output: y2x0 stores the best alignment: e.g.,
//y2x0[j]=i means:
//the jth element in y is aligned to the ith element in x if i>=0
//the jth element in y is aligned to a gap in x if i==-1
double TMalignc::get_initial_fgt(	double **x,
									double **y,
									int x_len,
									int y_len,
									int *sourceResNo_,
									int *targetResNo_,
									int *y2x )
{
	int fra_min=4;           //minimum fragment for search
	int fra_min1=fra_min-1;  //cutoff for shift, save time

	int xstart=0, ystart=0, xend=0, yend=0;

	find_max_frag(x, sourceResNo_, x_len,  &xstart, &xend);
	find_max_frag(y, targetResNo_, y_len, &ystart, &yend);


	int Lx = xend-xstart+1;
	int Ly = yend-ystart+1;
	int *ifr, *y2x_;
	int L_fr=getmin(Lx, Ly);
	ifr= new int[L_fr];
	y2x_= new int[y_len+1];

	//select what piece will be used (this may araise ansysmetry, but
	//only when L1=L2 and Lfr1=Lfr2 and L1 ne Lfr1
	//if L1=Lfr1 and L2=Lfr2 (normal proteins), it will be the same as initial1

	if(Lx<Ly || (Lx==Ly && x_len<=y_len))
	{
		for(int i=0; i<L_fr; i++)
		{ifr[i]=xstart+i;}
	}
	else if(Lx>Ly || (Lx==Ly && x_len>y_len))
	{
		for(int i=0; i<L_fr; i++)
		{ifr[i]=ystart+i;}
	}


	int L0=getmin(x_len, y_len); //non-redundant to get_initial1

	if(L_fr==L0)
	{
		int n1= (int)(L0*0.1); //my index starts from 0
		int n2= (int)(L0*0.89);

		int j=0;

		for(int i=n1; i<= n2; i++)
		{
			ifr[j]=ifr[i];
			j++;
		}
		L_fr=j;
	}


	//gapless threading for the extracted fragment
	double tmscore, tmscore_max=-1;

	if(Lx<Ly || (Lx==Ly && x_len<=y_len))
	{
		int L1=L_fr;
		int min_len=getmin(L1, y_len);
		int min_ali= (int) (min_len/2.5);  //minimum size of considered fragment

		if(min_ali<=fra_min1)
			min_ali=fra_min1;

		int n1, n2;
		n1 = -y_len+min_ali;
		n2 = L1-min_ali;

		int i, j, k;

		for(k=n1; k<=n2; k++)
		{
			//get the map
			for(j=0; j<y_len; j++)
			{
				i=j+k;

				if(i>=0 && i<L1)
				{y2x_[j]=ifr[i];}
				else
				{y2x_[j]=-1;}
			}

			//evaluate the map quickly in three iterations
			tmscore=get_score_fast(x, y, x_len, y_len, y2x_);

			if(tmscore>=tmscore_max)
			{
				tmscore_max=tmscore;

				for(j=0; j<y_len; j++)
				{y2x[j]=y2x_[j];}
			}
		}
	}
	else
	{
		int L2=L_fr;
		int min_len=getmin(x_len, L2);
		int min_ali= (int) (min_len/2.5);              //minimum size of considered fragment

		if(min_ali<=fra_min1)
		 min_ali=fra_min1;

		int n1, n2;
		n1 = -L2+min_ali;
		n2 = x_len-min_ali;

		int i, j, k;

		for(k=n1; k<=n2; k++)
		{
			//get the map
			for(j=0; j<y_len; j++)
			{y2x_[j]=-1;}

			for(j=0; j<L2; j++)
			{
				i=j+k;

				if(i>=0 && i<x_len)
				{y2x_[ifr[j]]=i;}
			}

			//evaluate the map quickly in three iterations
			tmscore=get_score_fast(x, y, x_len, y_len, y2x_);

			if(tmscore>=tmscore_max)
			{
				tmscore_max=tmscore;

				for(j=0; j<y_len; j++)
				{y2x[j]=y2x_[j];}
			}
		}
	}

	delete [] ifr;
	delete [] y2x_;
	return tmscore_max;
}

//_____________________________________________________________
//
//
//heuristic run of dynamic programing iteratively to find the best alignment
//input: initial rotation matrix t, u
//       vectors x and y, d0_
//output: best alignment that maximizes the TMscore, will be stored in invmap
double TMalignc::DP_iter(	double **x,
							double **y,
							int x_len,
							int y_len,
							double t_global[3],
							double u_global[3][3],
							int invmap0[],
							int g1,
							int g2,
							int iteration_max,
							double local_d0_search )
{
	double gap_open[2] = {-0.6, 0};
	double rmsd;
	int *invmap = new int[y_len+1];

	int iteration, i, j, k;
	double tmscore, tmscore_max, tmscore_old = 0;
	int score_sum_method = 8, simplify_step = 40;
	tmscore_max = -1;

	double d02 = d0_*d0_;

	for( int g=g1; g<g2; g++ )
	{
		for( iteration=0; iteration<iteration_max; iteration++ )
		{
			NWDP_TM(	x,
						y,
						x_len,
						y_len,
						t_global,
						u_global,
						d02,
						gap_open[g],
						invmap );

			k = 0;

			for(j=0; j<y_len; j++)
			{
				i=invmap[j];

				//aligned
				//
				if( i>=0 )
				{
					sourceTm_[k][0] = x[i][0];
					sourceTm_[k][1] = x[i][1];
					sourceTm_[k][2] = x[i][2];

					targetTm_[k][0] = y[j][0];
					targetTm_[k][1] = y[j][1];
					targetTm_[k][2] = y[j][2];
					k++;
				}
			}

			tmscore = TMscore8_search(	sourceTm_,
										targetTm_,
										k,
										t_global,
										u_global,
										simplify_step,
										score_sum_method,
										&rmsd,
										local_d0_search);


			if( tmscore>tmscore_max )
			{
				tmscore_max = tmscore;

				for(i=0; i<y_len; i++)
				{invmap0[i]=invmap[i];}
			}

			if( iteration>0 )
			{
				if(fabs(tmscore_old-tmscore)<0.000001)
				{break;}
			}

			tmscore_old=tmscore;
		}// for iteration

	}//for gapopen


	delete []invmap;
	return tmscore_max;
}

//_____________________________________________________________
//
// output the final results
//
void TMalignc::output_results(	char *xname,
								 char *yname,
								 int x_len,
								 int y_len,
								 double t[3],
								 double u[3][3],
								 double TM1,
								 double TM2,
								 double rmsd,
								 double d0_out,
								 int m1[],
								 int m2[],
								 int n_ali8,
								 int n_ali,
								 double TM_0,
								 double Lnorm_0,
								 double d0_0,
								 char* matrix_name,
								svdMatrix<float> & rotMat,
								svdVector<float> & transVec )
{
	double seq_id;
	int i, j, k;

	int ali_len=x_len+y_len; //maximum length of alignment

	do_rotation( coordsSource_, source_t_, x_len, t, u );

	seq_id=0;
	seq_id = seq_id/( n_ali8+0.00000001); //what did by TMalign, but not reasonable, it should be n_ali8

	printf( " Length of Chain_1: %d residues\n", x_len );
	printf( " Length of Chain_2: %d residues\n\n", y_len );

	printf( "Aligned length = %d, RMSD= %6.2f, Seq_ID=n_identical/n_aligned= %4.3f\n", n_ali8, rmsd, seq_id);
	printf( "TM-score_ = %6.5f (if normalized by length of Chain_1, i.e., LN=%d, d0_=%.2f)\n", TM2, x_len, d0B_);
	printf( "TM-score_ = %6.5f (if normalized by length of Chain_2, i.e., LN=%d, d0_=%.2f)\n", TM1, y_len, d0A_);

	if( a_opt_ )
	{
	  double L_ave = (x_len+y_len)*0.5;

	  printf(	"TM-score_ = %6.5f (if normalized by average length of two structures, i.e., LN= %.2f, d0_= %.2f)\n",
				TM3_, L_ave, d0a_);
	}

	if( u_opt_ )
	{
	  printf(	"TM-score_ = %6.5f (if normalized by user-specified LN=%.2f and d0_=%.2f)\n",
				TM4_, Lnorm_ass_, d0u_);
	}

	if( d_opt_ )
	{
		printf(	"TM-score_ = %6.5f (if scaled by user-specified d0_= %.2f, and LN= %.2f)\n",
				TM5_, d0_scale_, Lnorm_0);
	}

	printf( "(You should use TM-score normalized by length of the reference protein)\n" );

	// ********* extract rotation matrix based on TMscore8 ------------>
	if( m_opt_ )
	{
		for( k=0; k<3; k++ )
		{
			rotMat[k][0] = u[k][0];
			rotMat[k][1] = u[k][1];
			rotMat[k][2] = u[k][2];
			transVec[k]  = t[k];
		}
	}
}

//_____________________________________________________________
//
//
double TMalignc::standard_TMscore(	double **x,
									double **y,
									int x_len,
									int y_len,
									int invmap[],
									int& L_ali_,
									double& RMSD )
{
	D0_MIN_ = 0.5;
	Lnorm_ = y_len;

	if( Lnorm_ > 21 )
	{ d0_ = (1.24*pow( (Lnorm_*1.0 - 15), 1.0 / 3 ) - 1.8); }
	else
	{ d0_ = D0_MIN_; }

	if( d0_ < D0_MIN_ )
	{ d0_ = D0_MIN_; }

	double d0_input = d0_;// Scaled by seq_min

	double tmscore;// collected alined residues from invmap
	int n_al = 0;
	int i;

	for (int j = 0; j<y_len; j++)
	{
		i = invmap[j];

		if (i >= 0)
		{
			sourceTm_[n_al][0] = x[i][0];
			sourceTm_[n_al][1] = x[i][1];
			sourceTm_[n_al][2] = x[i][2];

			targetTm_[n_al][0] = y[j][0];
			targetTm_[n_al][1] = y[j][1];
			targetTm_[n_al][2] = y[j][2];

			r1_[n_al][0] = x[i][0];
			r1_[n_al][1] = x[i][1];
			r1_[n_al][2] = x[i][2];

			r2_[n_al][0] = y[j][0];
			r2_[n_al][1] = y[j][1];
			r2_[n_al][2] = y[j][2];

			n_al++;
		}
		else if (i != -1)
		{PrintErrorAndQuit("Wrong map!\n");	}
	}

	L_ali_ = n_al;

	Kabsch(r1_, r2_, n_al, 0, &RMSD, t_, u_);
	RMSD = sqrt( RMSD/(1.0*n_al) );

	int temp_simplify_step = 1;
	int temp_score_sum_method = 0;
	d0_search_ = d0_input;
	double rms = 0.0;

	tmscore = TMscore8_search_standard(	sourceTm_,
										targetTm_,
										n_al,
										t_,
										u_,
										temp_simplify_step,
										temp_score_sum_method,
										&rms,
										d0_input);

	tmscore = tmscore * n_al / (1.0*Lnorm_);

	return tmscore;
}

//_____________________________________________________________
//
//

}

