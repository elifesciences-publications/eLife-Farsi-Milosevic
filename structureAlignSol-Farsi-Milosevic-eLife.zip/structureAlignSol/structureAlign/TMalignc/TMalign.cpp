//
/*
===============================================================================
   This is a re-implementation of TM-align algorithm in C/C++. The code was
   is written by Jianyi Yang and later updated by Jianjie Wu at The Yang Zhang
   lab, Department of Computational Medicine and Bioinformatics, University of
   Michigan, 100 Washtenaw Avenue, Ann Arbor, MI 48109-2218. Please report bugs
   and questions to jianjiew@umich.edu or zhng@umich.edu

   DISCLAIMER:
	 Permission to use, copy, modify, and distribute this program for
	 any purpose, with or without fee, is hereby granted, provided that
	 the notices on the head, the reference information, and this
	 copyright notice appear in all copies or substantial portions of
	 the Software. It is provided "as is" without express or implied
	 warranty.
   *************** updating history ********************************
   2012/01/24: A C/C++ code of TM-align was constructed by Jianyi Yang
   2016/05/21: Several updates of this program were made by Jianjie Wu, including
			  (1) fixed several compiling bugs
		  (2) made I/O of C/C++ version_ consistent with the Fortran version_
		  (3) added outputs including full-atom and ligand structures
		  (4) added options of '-i', '-I' and '-m'
   2016/05/25: fixed a bug on PDB file reading
===============================================================================
*/

#include <maya/MString.h>

#include "TMalign.h"

namespace sciloop
{
#define TMPrint

//________________________________________________________________
//
//
void TMalignc::print_help( char *arg )
{

	cout <<endl;
	cout << " ***************************************************************************************************" << endl
		<< " * TM-align (Version "<< version_ <<"): An algorithm for protein structure alignment and comparison        *" << endl
		<< " * Based on statistics:                                                                            *" << endl
		<< " *          0.0 < TM-score_ < 0.30, random structural similarity                                    *" << endl
		<< " *          0.5 < TM-score_ < 1.00, in about the same fold                                          *" << endl
		<< " * Reference: Y Zhang and J Skolnick, Nucl Acids Res 33, 2302-9 (2005)                             *" << endl
		<< " * Please email your comments and suggestions to Yang Zhang (zhng@umich.edu)                       *" << endl
		<< " ***************************************************************************************************" << endl;
	cout << endl
		<< " Usage: " << arg << " PDB1.pdb PDB2.pdb [Options]" << endl << endl
		<< " Options:" << endl
		<< "       -u    TM-score normalized by user assigned length" << endl
		<< "             warning: it should be >= minimum length of the two structures" << endl
		<< "             otherwise, TM-score_ may be >1" << endl << endl
		<< "       -a    TM-score normalized by the average length of two structures" << endl
		<< "             T or F, (default F)" << endl << endl
		<< "       -m    Output TM-align rotation matrix:" << endl << endl
		<< "       -d    TM-score_ scaled by an assigned d0_, e.g. 5 Angstroms" << endl << endl
		<< "       -o    output the superposition to TM.sup, TM.sup_all and TM.sup_atm" << endl
		<< "             >TMalign chain1 chain2 -o TM.sup" << endl
		<< "             To view superimposed C-alpha traces of aligned regions by rasmol: >rasmol -script TM.sup" << endl
		<< "             To view superimposed C-alpha traces of all regions:               >rasmol -script TM.sup_all" << endl << endl
		<< "             To view superimposed full-atom structs of aligned regions:        >rasmol -script TM.sup_atm" << endl << endl
		<< "             To view superimposed full-atom structs of all regions             >rasmol -script TM.sup_all_atm" << endl << endl
		<< "             To view superimposed full-atom structs of all regions with ligands: >rasmol -script TM.sup_all_atm_lig" << endl << endl
		<< "       -h    print this help" << endl << endl
		<< "       (Options -u, -a, -d -o won't change the final structure alignment)" << endl << endl
		<< " Example usages:" << endl
		<< "        "<< arg <<" PDB1.pdb PDB2.pdb" << endl
		<< "        "<< arg <<" PDB1.pdb PDB2.pdb -u 100 -d 5.0" << endl
		<< "        "<< arg <<" PDB1.pdb PDB2.pdb -a T -o PDB1.sup" << endl
		<< "        "<< arg <<" PDB1.pdb PDB2.pdb -i align.txt" << endl
		<< "        "<< arg <<" PDB1.pdb PDB2.pdb -m matrix.txt" << endl << endl;

}

//________________________________________________________________
//
//
void TMalignc::parameter_set4search( int sourceLen, int targetLen )
{
	//parameter initilization for searching:
	// D0_MIN_, Lnorm_, d0_, d0_search_, score_d8_
	//
	D0_MIN_ = 0.5;
	dcu0_ = 4.25;                      //update 3.85-->4.25

	// normalize TMscore by this in searching
	//
	Lnorm_ = getmin( sourceLen, targetLen );

	if( Lnorm_<=19 )                 //update 15-->19
	{ d0_=0.168; }                   //update 0.5-->0.168
	else
	{ d0_=(1.24*pow( (Lnorm_*1.0-15), 1.0/3 )-1.8); }

	D0_MIN_ = d0_+0.8;              //this should be moved to above
	d0_ = D0_MIN_;                  //update: best for search

	d0_search_ = d0_;

	if( d0_search_>8 )
	{ d0_search_ = 8; }

	if( d0_search_<4.5 )
	{d0_search_ = 4.5;}

	// remove pairs with dis>d8 during search & final
	//
	score_d8_ = 1.5*pow( Lnorm_*1.0, 0.3 )+3.5;
}

//________________________________________________________________
//
//
void TMalignc::parameter_set4final( double len )
{
	D0_MIN_ = 0.5;

	Lnorm_=len;            //normaliz TMscore by this in searching

	if( Lnorm_<=21 )
	{ d0_ = 0.5; }
	else
	{ d0_ = (1.24*pow( (Lnorm_*1.0-15), 1.0/3 )-1.8); }

	if( d0_<D0_MIN_ )
	{ d0_ = D0_MIN_; }

	d0_search_ = d0_;

	if( d0_search_>8 )
	{ d0_search_ = 8; }

	if( d0_search_<4.5 )
	{ d0_search_ = 4.5; }

}

//________________________________________________________________
//
//
void TMalignc::parameter_set4scale( int len, double d_s )
{
	d0_ = d_s;
	Lnorm_ = len;            //normaliz TMscore by this in searching

	d0_search_ = d0_;

	if( d0_search_>8 )
	{ d0_search_ = 8; }

	if( d0_search_<4.5 )
	{ d0_search_ = 4.5; }
}

//________________________________________________________________
//
//
bool TMalignc::main_TMalignc(	bool				  outputStructure,
								bool				  TMscoreAveragedByBothLength,
								MString				  TorF,
								bool				  scaleTMscoreByD0,
								float				  d0scale,
								svdMatrix<float>	& sourcePoints,
								svdMatrix<float>	& targetPoints,
								svdMatrix<float>	& rotMat,
								svdVector<float>	& transVec,
								int					  strucT )
{
	switch( strucT )
	{
	case 0: structureType_ = structureType_e::kProtein; break;
	case 1: structureType_ = structureType_e::kOther; break;
	default: structureType_ = structureType_e::kOther;
	}

	char xname[MAXLEN], yname[MAXLEN], Lnorm_ave[MAXLEN];
	bool A_opt, B_opt, h_opt=false;
	A_opt = B_opt = o_opt_ = a_opt_ = u_opt_ = d_opt_ = false;
	m_opt_ = true;// set -m flag to be false
	char fname_lign[MAXLEN] = "";
	char fname_matrix[MAXLEN] = "";// set names to ""

	int nameIdx = 0;

	a_opt_ = TMscoreAveragedByBothLength;

	if( a_opt_==true )
	{
		if( TorF=="F" )
		{ strcpy( Lnorm_ave, "F" ); }
		else if( TorF=="T" )
		{ strcpy( Lnorm_ave, "T" ); }
	}

	o_opt_ = outputStructure;
	d_opt_ = scaleTMscoreByD0;

	if( d_opt_==true )
	{ d0_scale_ = d0scale; }

	//strcpy( out_reg_, argv[i + 1] );      o_opt_ = true; i++; }
	// normalized by user assigned length
	//Lnorm_ass_ = atof( argv[i + 1] ); u_opt_ = true; i++; }

	/*if( nameIdx_ == 0 )
	{ strcpy( xname, argv[i] );      B_opt = true; }
	else if( nameIdx == 1 )
	{ strcpy( yname, argv[i] );      A_opt = true; }

	nameIdx_++;*/

//cout << " START main_TMalign 1" << endl;

	/*********************************************************************************/
	/*                                get argument                                   */
	/*********************************************************************************/

	if( a_opt_ )
	{
		if( !strcmp( Lnorm_ave, "T" ) )
		{}
		else if( !strcmp( Lnorm_ave, "F" ) )
		{ a_opt_ = false; }
		else
		{
			cout << "Wrong value for option -a!  It should be T or F" << endl;
			return false;
		}
	}

	if( u_opt_ )
	{
		if( Lnorm_ass_<=0 )
		{
			cout << "Wrong value for option -u!  It should be >0" << endl;
			return false;
		}
	}

	if( d_opt_ )
	{
		if( d0_scale_<=0 )
		{
			cout << "Wrong value for option -d!  It should be >0" << endl;
			return false;
		}
	}

	bool sciSuccess = checkArrLen( sourcePoints, targetPoints );

	// Heavily modified.
	//
	sciSuccess = load_PDB_allocate_memory( sourcePoints, targetPoints );

//cout << " START main_TMalign 2" << endl;

	/*********************************************************************************/
	/*                                parameter set                                  */
	/*********************************************************************************/
	//
	// please set parameters in the function
	//

#ifdef TMPrint
cout << " parameter_set4Search" << endl;
#endif

	parameter_set4search( sourceResLen_, targetResLen_ );

	// for similified search engine
	//
	int simplify_step = 40;

	// for scoring method, whether only sum over pairs with dis<score_d8_
	//
	int score_sum_method = 8;

	int i;
	int *invmap0 = new int[targetResLen_+1];
	int *invmap  = new int[targetResLen_+1];
	double TM, TMmax = -1;

	for( i=0; i<targetResLen_; i++ )
	{ invmap0[i] = -1; }

	double ddcc = 0.4;

	if( Lnorm_<=40 )
	{ ddcc = 0.1; }   //Lnorm_ was setted in parameter_set4search

	double local_d0_search = d0_search_;

	//*********************************************************************************//
	//                  get initial alignment from user's input:                       //
	//                  Stick to the initial alignment                                 //
	//*********************************************************************************//
	char dest[1000];

	/*********************************************************************************/
	/*         get initial alignment with gapless threading                          */
	/*********************************************************************************/

#ifdef TMPrint
	cout << " get_initial" << endl;
#endif

	double sciSuccessI = get_initial(	coordsSource_,
										coordsTarget_,
										sourceResLen_,
										targetResLen_,
										invmap0 );

	if( sciSuccessI==-9999.0 )
	{return false;}

	// find the max TMscore for this initial alignment with the simplified search_engine
	//
#ifdef TMPrint
	cout << " detailed_search" << endl;
#endif
	TM = detailed_search(	coordsSource_,
							coordsTarget_,
							sourceResLen_,
							targetResLen_,
							invmap0,
							t_,
							u_,
							simplify_step,
							score_sum_method,
							local_d0_search );

	if( TM>TMmax )
	{ TMmax = TM; }

	// run dynamic programing iteratively to find the best alignment
	//
#ifdef TMPrint
	cout << " DP_iter" << endl;
#endif
	TM = DP_iter(	coordsSource_,
					coordsTarget_,
					sourceResLen_,
					targetResLen_,
					t_,
					u_,
					invmap,
					0,
					2,
					30,
					local_d0_search );

	if( TM>TMmax )
	{
		TMmax = TM;

		for( int i=0; i<targetResLen_; i++ )
		{ invmap0[i] = invmap[i]; }
	}

//cout << " START main_TMalign 3 " << endl;

	/*********************************************************************************/
	/*         get initial alignment based on secondary structure                    */
	/*********************************************************************************/
	//
#ifdef TMPrint
	cout << " get_initial_ss" << endl;
#endif
	get_initial_ss(	coordsSource_,
					coordsTarget_,
					sourceResLen_,
					targetResLen_,
					invmap );

#ifdef TMPrint
	cout << " detailed_search" << endl;
#endif
	TM = detailed_search(	coordsSource_,
							coordsTarget_,
							sourceResLen_,
							targetResLen_,
							invmap,
							t_,
							u_,
							simplify_step,
							score_sum_method,
							local_d0_search );

	if( TM>TMmax )
	{
		TMmax = TM;

		for( int i=0; i<targetResLen_; i++ )
		{ invmap0[i] = invmap[i]; }
	}

	if( TM>TMmax*0.2 )
	{
#ifdef TMPrint
		cout << " TM>TMmax*0.2 -> DP_iter" << endl;
#endif
		TM = DP_iter(	coordsSource_,
						coordsTarget_,
						sourceResLen_,
						targetResLen_,
						t_,
						u_,
						invmap,
						0,
						2,
						30,
						local_d0_search );

		if( TM>TMmax )
		{
			TMmax = TM;

			for( int i=0; i<targetResLen_; i++ )
			{ invmap0[i] = invmap[i]; }
		}
	}

//cout << " 0" << endl;

	/*********************************************************************************/
	/*         get initial alignment based on local superposition                    */
	/*********************************************************************************/
	//
	//=initial5 in original TM-align
	//
#ifdef TMPrint
	cout << " get_initial5, detailed_search" << endl;
#endif
	if( get_initial5(	coordsSource_,
						coordsTarget_,
						sourceResLen_,
						targetResLen_,
						invmap ) )
	{
		TM = detailed_search(	coordsSource_,
								coordsTarget_,
								sourceResLen_,
								targetResLen_,
								invmap,
								t_,
								u_,
								simplify_step,
								score_sum_method,
								local_d0_search );

		if( TM>TMmax )
		{
			TMmax = TM;

			for( int i=0; i<targetResLen_; i++ )
			{ invmap0[i] = invmap[i]; }
		}

		if( TM>TMmax*ddcc )
		{
			TM = DP_iter(	coordsSource_,
							coordsTarget_,
							sourceResLen_,
							targetResLen_,
							t_,
							u_,
							invmap,
							0,
							2,
							2,
							local_d0_search );

			if( TM>TMmax )
			{
				TMmax = TM;

				for( int i=0; i<targetResLen_; i++ )
				{ invmap0[i] = invmap[i]; }
			}
		}
	}
	else
	{ cout << endl << endl << "Warning: initial alignment from local superposition fail!" << endl << endl << endl; }

//cout << "1" << endl;

	/*********************************************************************************/
	/*    get initial alignment based on previous alignment+secondary structure      */
	/*********************************************************************************/
	//=initial3 in original TM-align
	//
#ifdef TMPrint
	cout << " get_initial_ssplus" << endl;
#endif
	get_initial_ssplus(	coordsSource_,
						coordsTarget_,
						sourceResLen_,
						targetResLen_,
						invmap0,
						invmap );

#ifdef TMPrint
	cout << " detailed_search" << endl;
#endif
	TM = detailed_search(	coordsSource_,
							coordsTarget_,
							sourceResLen_,
							targetResLen_,
							invmap,
							t_,
							u_,
							simplify_step,
							score_sum_method,
							local_d0_search );

	if( TM>TMmax )
	{
		TMmax = TM;

		for( i=0; i<targetResLen_; i++ )
		{ invmap0[i] = invmap[i]; }
	}

	if( TM>TMmax*ddcc )
	{
#ifdef TMPrint
		cout << " TM>TMmax*ddcc -> DP_iter" << endl;
#endif
		TM = DP_iter(	coordsSource_,
						coordsTarget_,
						sourceResLen_,
						targetResLen_,
						t_,
						u_,
						invmap,
						0,
						2,
						30,
						local_d0_search );

		if( TM>TMmax )
		{
			TMmax = TM;

			for( i=0; i<targetResLen_; i++ )
			{ invmap0[i] = invmap[i]; }
		}
	}

	/*********************************************************************************/
	/*        get initial alignment based on fragment gapless threading              */
	/*********************************************************************************/
	//
	//=initial4 in original TM-align
	//
#ifdef TMPrint
	cout << " get_initial_fgt" << endl;
#endif
	get_initial_fgt(	coordsSource_,
						coordsTarget_,
						sourceResLen_,
						targetResLen_,
						sourceResNo_,
						targetResNo_,
						invmap );

#ifdef TMPrint
	cout << " detailed_search" << endl;
#endif
	TM = detailed_search(	coordsSource_,
							coordsTarget_,
							sourceResLen_,
							targetResLen_,
							invmap,
							t_,
							u_,
							simplify_step,
							score_sum_method,
							local_d0_search );

	if( TM>TMmax )
	{
		TMmax = TM;

		for( i=0; i<targetResLen_; i++ )
		{ invmap0[i] = invmap[i]; }
	}

	if( TM>TMmax*ddcc )
	{
#ifdef TMPrint
		cout << " TM>TMmax*ddcc -> DP_iter" << endl;
#endif
		TM = DP_iter(	coordsSource_,
						coordsTarget_,
						sourceResLen_,
						targetResLen_,
						t_,
						u_,
						invmap,
						1,
						2,
						2,
						local_d0_search );

		if( TM>TMmax )
		{
			TMmax = TM;

			for( i=0; i<targetResLen_; i++ )
			{ invmap0[i] = invmap[i]; }
		}
	}


	//*********************************************************************************//
	//     The alignment will not be changed any more in the following                 //
	//*********************************************************************************//
	//check if the initial alignment is generated approately
	//
	bool flag = false;

	for( i=0; i<targetResLen_; i++ )
	{
		if( invmap0[i]>=0 )
		{
			flag = true;
			break;
		}
	}

	if( !flag )
	{
		cout << "There is no alignment between the two proteins!" << endl;
		cout << "Program stop with no result!" << endl;
		return false;
	}

//cout << " 3" << endl;

	//*********************************************************************************//
	//       Detailed TMscore search engine  --> prepare for final TMscore             //
	//*********************************************************************************//
	//run detailed TMscore search engine for the best alignment, and
	//extract the best rotation matrix (t, u) for the best alginment
	//
	simplify_step = 1;
	score_sum_method = 8;

#ifdef TMPrint
	cout << " detailed_search_standard" << endl;
#endif
	TM = detailed_search_standard(	coordsSource_,
									coordsTarget_,
									sourceResLen_,
									targetResLen_,
									invmap0,
									t_,
									u_,
									simplify_step,
									score_sum_method,
									local_d0_search,
									false );


	// select pairs with dis<d8 for final TMscore computation and output alignment
	//
	int n_ali8, k = 0;
	int n_ali = 0;
	int *m1, *m2;
	double d;
	m1 = new int[sourceResLen_]; //alignd index in x
	m2 = new int[targetResLen_]; //alignd index in y

	do_rotation( coordsSource_, source_t_, sourceResLen_, t_, u_ );

	k=0;

	for( int j=0; j<targetResLen_; j++ )
	{
		i = invmap0[j];

		// aligned
		//
		if( i>=0 )
		{
			n_ali++;

			d = sqrt( dist( &source_t_[i][0], &coordsTarget_[j][0] ) );

			if( d<=score_d8_ )
			{
				m1[k] = i;
				m2[k] = j;

				sourceTm_[k][0] = coordsSource_[i][0];
				sourceTm_[k][1] = coordsSource_[i][1];
				sourceTm_[k][2] = coordsSource_[i][2];

				targetTm_[k][0] = coordsTarget_[j][0];
				targetTm_[k][1] = coordsTarget_[j][1];
				targetTm_[k][2] = coordsTarget_[j][2];

				r1_[k][0] = source_t_[i][0];
				r1_[k][1] = source_t_[i][1];
				r1_[k][2] = source_t_[i][2];

				r2_[k][0] = coordsTarget_[j][0];
				r2_[k][1] = coordsTarget_[j][1];
				r2_[k][2] = coordsTarget_[j][2];

				k++;
			}
		}
	}

	n_ali8 = k;

	double rmsd0 = 0.0;

	// rmsd0 is used for final output, only recalculate rmsd0, not t & u
	//
#ifdef TMPrint
	cout << " Kabsch" << endl;
#endif

	Kabsch( r1_,
			r2_,
			n_ali8,
			0,
			&rmsd0,
			t_,
			u_ );

	rmsd0 = sqrt( rmsd0 / n_ali8 );

	//*********************************************************************************//
	//                               Final TMscore                                     //
	//                     Please set parameters for output                            //
	//*********************************************************************************//
	double rmsd;
	double t0[3], u0[3][3];
	double TM1, TM2;
	double d0_out = 5.0;
	simplify_step = 1;
	score_sum_method = 0;

	double d0_0, TM_0;
	double Lnorm_0 = targetResLen_;

	// normalized by length of structure A
	//
	parameter_set4final( Lnorm_0 );
	d0A_ = d0_;
	d0_0 = d0A_;
	local_d0_search = d0_search_;

#ifdef TMPrint
	cout << " TMscore8_search" << endl;
#endif
	TM1 = TMscore8_search(	sourceTm_,
							targetTm_,
							n_ali8,
							t0,
							u0,
							simplify_step,
							score_sum_method,
							&rmsd,
							local_d0_search );
	TM_0 = TM1;

	// normalized by length of structure B
	//
	parameter_set4final( sourceResLen_+0.0 );
	d0B_ = d0_;
	local_d0_search = d0_search_;

#ifdef TMPrint
	cout << " TMscore8_search" << endl;
#endif
	TM2 = TMscore8_search(	sourceTm_,
							targetTm_,
							n_ali8,
							t_,
							u_,
							simplify_step,
							score_sum_method,
							&rmsd,
							local_d0_search );

	// TM-score normalized by the average length of two structures"
	// currently set to false
	//
	if( a_opt_ )
	{
		// normalized by average length of structures A, B
		//
		Lnorm_0 = (sourceResLen_+targetResLen_)*0.5;
		parameter_set4final( Lnorm_0 );
		d0a_ = d0_;
		d0_0 = d0a_;
		local_d0_search = d0_search_;

#ifdef TMPrint
		cout << " a_opt_ -> TMscore8_search" << endl;
#endif
		TM3_ = TMscore8_search(	sourceTm_,
								targetTm_,
								n_ali8,
								t0,
								u0,
								simplify_step,
								score_sum_method,
								&rmsd,
								local_d0_search );
		TM_0 = TM3_;
	}

	// TM-score normalized by user assigned length
	// always false
	//
	if( u_opt_ )
	{
		// normalized by user assigned length
		//
#ifdef TMPrint
		cout << " u_opt_ -> parameter_set4final" << endl;
#endif
		parameter_set4final( Lnorm_ass_ );

		d0u_ = d0_;
		d0_0 = d0u_;
		Lnorm_0 = Lnorm_ass_;
		local_d0_search = d0_search_;

#ifdef TMPrint
		cout << " u_opt_ -> TMscore8_search" << endl;
#endif
		TM4_ = TMscore8_search(	sourceTm_,
								targetTm_,
								n_ali8,
								t0,
								u0,
								simplify_step,
								score_sum_method,
								&rmsd,
								local_d0_search );
		TM_0 = TM4_;
	}

	// scaleTMscoreByD0
	// currently set to false
	//
	if( d_opt_ )
	{
		// scaled by user assigned d0_
		//
		parameter_set4scale( targetResLen_, d0_scale_ );
		d0_out = d0_scale_;
		d0_0 = d0_scale_;

		//Lnorm_0=targetResLen_;

		Lnorm_d0_ = Lnorm_0;
		local_d0_search = d0_search_;

#ifdef TMPrint
		cout << " d_opt_ -> TMscore8_search" << endl;
#endif
		TM5_ = TMscore8_search(	sourceTm_,
								targetTm_,
								n_ali8,
								t0,
								u0,
								simplify_step,
								score_sum_method,
								&rmsd,
								local_d0_search );
		TM_0 = TM5_;
	}

#ifdef TMPrint
	cout << " output_results" << endl;
#endif
	output_results( xname,
					yname,
					sourceResLen_,
					targetResLen_,
					t0,
					u0,
					TM1,
					TM2,
					rmsd0,
					d0_out,
					m1,
					m2,
					n_ali8,
					n_ali,
					TM_0,
					Lnorm_0,
					d0_0,
					fname_matrix,
					rotMat,
					transVec );

	//*********************************************************************************//
	//                            Done! Free memory                                    //
	//*********************************************************************************//
	free_memory();

	delete[] invmap0;
	delete[] invmap;
	delete[] m1;
	delete[] m2;

	return true;
}

//________________________________________________________________
//
//

}

