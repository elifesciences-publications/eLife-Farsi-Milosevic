//
/*
===============================================================================
   Implementation of TM-align in C/C++

   This program is written by Jianyi Yang at
   Yang Zhang lab
   And it is updated by Jianjie Wu at
   Yang Zhang lab
   Department of Computational Medicine and Bioinformatics
   University of Michigan
   100 Washtenaw Avenue, Ann Arbor, MI 48109-2218

   Please report bugs and questions to jianjiew@umich.edu or zhng@umich.edu
===============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <malloc.h>

#include <sstream>
#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include <algorithm>

#include "TMalign.h"

namespace sciloop
{
#define ATOMNMAX 900000//upper limit for number of ATOM,
#define CANMAX 50000//upper limit for number of C-alpha,

//________________________________________________________________
//
//
bool TMalignc::PrintErrorAndQuit( char* sErrorString )
{
	cout << sErrorString << endl;
	return false;
}


//________________________________________________________________
//
//
char TMalignc::AAmap( string AA )
{
	char A=' ';

	if( AA.compare( "BCK" )==0 )   A='X';
	else if( AA.compare( "GLY" )==0 )   A='G';
	else if( AA.compare( "ALA" )==0 )   A='A';
	else if( AA.compare( "SER" )==0 )   A='S';
	else if( AA.compare( "CYS" )==0 )   A='C';
	else if( AA.compare( "VAL" )==0 )   A='V';
	else if( AA.compare( "THR" )==0 )   A='T';
	else if( AA.compare( "ILE" )==0 )   A='I';
	else if( AA.compare( "PRO" )==0 )   A='P';
	else if( AA.compare( "MET" )==0 )   A='M';
	else if( AA.compare( "ASP" )==0 )   A='D';
	else if( AA.compare( "ASN" )==0 )   A='N';
	else if( AA.compare( "LEU" )==0 )   A='L';
	else if( AA.compare( "LYS" )==0 )   A='K';
	else if( AA.compare( "GLU" )==0 )   A='E';
	else if( AA.compare( "GLN" )==0 )   A='Q';
	else if( AA.compare( "ARG" )==0 )   A='R';
	else if( AA.compare( "HIS" )==0 )   A='H';
	else if( AA.compare( "PHE" )==0 )   A='F';
	else if( AA.compare( "TYR" )==0 )   A='Y';
	else if( AA.compare( "TRP" )==0 )   A='W';
	else if( AA.compare( "CYX" )==0 )   A='C';
	else
		A='Z'; //ligand

	return A;
}

//________________________________________________________________
//
//
void TMalignc::AAmap3( char A, char AA[3] )
{
	if( A=='X' )
		strcpy( AA, "BCK" );
	else if( A=='G' )   strcpy( AA, "GLY" );
	else if( A=='A' )   strcpy( AA, "ALA" );
	else if( A=='S' )   strcpy( AA, "SER" );
	else if( A=='C' )   strcpy( AA, "CYS" );
	else if( A=='V' )   strcpy( AA, "VAL" );
	else if( A=='T' )   strcpy( AA, "THR" );
	else if( A=='I' )   strcpy( AA, "ILE" );
	else if( A=='P' )   strcpy( AA, "PRO" );
	else if( A=='M' )   strcpy( AA, "MET" );
	else if( A=='D' )   strcpy( AA, "ASP" );
	else if( A=='N' )   strcpy( AA, "ASN" );
	else if( A=='L' )   strcpy( AA, "LEU" );
	else if( A=='K' )   strcpy( AA, "LYS" );
	else if( A=='E' )   strcpy( AA, "GLU" );
	else if( A=='Q' )   strcpy( AA, "GLN" );
	else if( A=='R' )   strcpy( AA, "ARG" );
	else if( A=='H' )   strcpy( AA, "HIS" );
	else if( A=='F' )   strcpy( AA, "PHE" );
	else if( A=='Y' )   strcpy( AA, "TYR" );
	else if( A=='W' )   strcpy( AA, "TRP" );
	else if( A=='C' )   strcpy( AA, "CYX" );
	else
		strcpy( AA, "UNK" );
}

//________________________________________________________________
//
//
string TMalignc::Trim( string inputString )
{
	string result = inputString;
	int idxBegin = inputString.find_first_not_of( " " );
	int idxEnd = inputString.find_last_not_of( " " );

	if( idxBegin >= 0 && idxEnd >= 0 )
		result = inputString.substr( idxBegin, idxEnd + 1 - idxBegin );

	return result;
}

//________________________________________________________________
//
//
int TMalignc::get_PDB_len( char *filename )
{
	int i = 0;
	string line;
	string atom( "ATOM " );

	ifstream fin( filename );

	if( fin.is_open() )
	{
		while( fin.good() )
		{
			getline( fin, line );

			if( line.compare( 0, atom.length(), atom )==0 )
				i++;
		}
		fin.close();
	}
	else
	{
		char message[5000];
		sprintf( message, "Can not open file: %s\n", filename );

		if( !PrintErrorAndQuit(message) )
		{ return -1; }
	}

	return i;
}

//________________________________________________________________
//
//
int TMalignc::read_PDB( const svdMatrix<float> & sourcePoints,
						const svdMatrix<float> & targetPoints )
{
	cout << " source row len : " << sourcePoints.GetRows() << endl;
	cout << " target row len : " << targetPoints.GetRows() << endl;


	// We want CA atoms.
	//
	unsigned k=0;
	for( unsigned i=1, l=sourcePoints.GetRows(); i<l; i+=3 )
	{
		coordsSource_[k][0] = sourcePoints[i][0];
		coordsSource_[k][1] = sourcePoints[i][1];
		coordsSource_[k][2] = sourcePoints[i][2];

		coordsTarget_[k][0] = targetPoints[i][0];
		coordsTarget_[k][1] = targetPoints[i][1];
		coordsTarget_[k][2] = targetPoints[i][2];
		k++;
	}

	return 0;
}

//________________________________________________________________
//
//
int TMalignc::get_ligand_len( char *filename )
{
	int i=0;
	string line;
	string atom1_( "ATOM  " );
	string atom2_( "HETATM" );
	string finish( "END" );

	ifstream fin( filename );

	if( fin.is_open() )
	{
		while( fin.good() )
		{
			getline( fin, line );

			if( line.compare( 0, atom1_.length(), atom1_ ) == 0 || line.compare( 0, atom2_.length(), atom2_ ) == 0 )
			{i++;}
			else if( line.compare( 0, finish.length(), finish )==0 )
			{break;}
		}

		fin.close();
	}
	else
	{
		char message[5000];
		sprintf( message, "Can not open file: %s\n", filename );

		if( !PrintErrorAndQuit( message ) )
		{ return -1; }
	}

	return i;
}

//________________________________________________________________
//
//
double TMalignc::dist( double x[3], double y[3] )
{
	double d1=x[0]-y[0];
	double d2=x[1]-y[1];
	double d3=x[2]-y[2];

	return (d1*d1 + d2*d2 + d3*d3);
}

//________________________________________________________________
//
//
double TMalignc::dot( double *a, double *b )
{return (a[0] * b[0] + a[1] * b[1] + a[2] * b[2]);}

//________________________________________________________________
//
//
void TMalignc::transform( double t[3], double u[3][3], double *x, double *x1 )
{
	x1[0]=t[0]+dot( &u[0][0], x );
	x1[1]=t[1]+dot( &u[1][0], x );
	x1[2]=t[2]+dot( &u[2][0], x );
}

//________________________________________________________________
//
//
void TMalignc::do_rotation(	double **x,
							double **x1,
							int len,
							double t[3],
							double u[3][3] )
{
	for( int i=0; i<len; i++ )
	{transform( t, u, &x[i][0], &x1[i][0] );}
}

//________________________________________________________________
//
//
void TMalignc::output_align1( int *invmap0, int len )
{
	for( int i=0; i<len; i++ )
	{
		if( invmap0[i]>=0 )
		{cout << invmap0[i]+1 << " ";}
		else
		{cout << invmap0[i] << " ";}

	}
	cout << endl << endl;
}

//________________________________________________________________
//
//
int TMalignc::output_align( int *invmap0, int len )
{
	int n_ali=0;
	for( int i=0; i<len; i++ )
	{
		cout <<  invmap0[i] << " ";
		n_ali++;
	}
	cout << endl << endl;

	return n_ali;
}

//________________________________________________________________
//
//
// output aligned residues to string
string TMalignc::output_align_to_string( int *invmap, int len )
{
	string result = "";
	int step = 10;
	int rest = len % step;
	int loop = len / step;
	int i, k;
	char temp[1000];

	for( i = 0; i<loop; i++ )
	{
		k = i * step;

		for( int j = 0; j < step; j++ )
		{
			sprintf( temp, "%4d ", invmap[k + j] );
			result += string( temp );
		}

		result += "\n";
	}

	k = i * step;

	for( int j = 0; j < rest; j++ )
	{
		sprintf( temp, "%4d ", invmap[k + j] );
		result += string( temp );
	}

	result += "\n";

	return result;
}

//________________________________________________________________
//
//
// output aligned coords to string
string TMalignc::output_coord_to_string( double **x, double **y, int len )
{
	string result = "";
	int i, k;
	char temp[1000];
	result += "sourceTm_ coords:\n";

	for( i = 0; i<len; i++ )
	{
		sprintf( temp, "%8.3f %8.3f %8.3f\n", x[i][0], x[i][1], x[i][2] );
		result += string( temp );
	}

	result += "targetTm_ coords:\n";

	for( i = 0; i<len; i++ )
	{
		sprintf( temp, "%8.3f %8.3f %8.3f\n", y[i][0], y[i][1], y[i][2] );
		result += string( temp );
	}
	return result;
}

//________________________________________________________________
//
//

}

