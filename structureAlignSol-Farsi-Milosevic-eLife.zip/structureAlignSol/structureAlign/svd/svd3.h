//

#ifndef SCI_SVD_H
#define SCI_SVD_H

namespace sciloop
{
int sciSVD( int		  rowCount,
			int		  columnCount,
			double	* a,
			double	* u,
			double	* s,
			double	* v );
}

#endif