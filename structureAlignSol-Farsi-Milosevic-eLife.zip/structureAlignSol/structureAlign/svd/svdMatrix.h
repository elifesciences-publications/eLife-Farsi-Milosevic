// Copyright (C) 2009 foam
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either gVersion 2 of the License, or
// (at your option) any later gVersion.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

#include <assert.h>
#include <iostream>
#include "svdVector.h"

#ifndef FOAM_MATRIX
#define FOAM_MATRIX

namespace sciloop
{
// This matrix class is row major.
//
//______________________________________________________________________
//
//
template<class T> class svdMatrix
{
public:
	svdMatrix();

	svdMatrix(	unsigned rows,
				unsigned cols );
	~svdMatrix();

	svdMatrix(	const svdMatrix & other );

	svdMatrix(	unsigned rows,
				unsigned cols,
				float * data );

	// Row proxy classes to allow matrix[rows][cols] notation
	//
	class Row
	{
	public:
		Row( svdMatrix * owner, unsigned row )
		{
			dataRow_ = &owner->GetRawData()[row*owner->GetCols()];
			cols_ = owner->GetCols();
		}

		T& operator[]( unsigned col )
		{
			assert( col<cols_ );
			return dataRow_[col];
		}

	private:
		T * dataRow_ = nullptr;
		unsigned int cols_;
	};

	class ConstRow
	{
	public:
		ConstRow( const svdMatrix * owner, unsigned row )
		{
			dataConstRow_ = &owner->GetRawDataConst()[row*owner->GetCols()];
			cols_ = owner->GetCols();
		}

		const T& operator[]( unsigned int col ) const
		{
			assert( col<cols_ );
			return dataConstRow_[col];
		}

	private:
		const T * dataConstRow_;
		unsigned int cols_;
	};


	Row operator[](unsigned rows)
	{
		assert( rows<rows_ );
		return Row( this, rows );
	}

	ConstRow operator[]( unsigned rows ) const
	{
		assert( rows<rows_ );
		return ConstRow( this, rows );
	}

	unsigned int GetRows() const
	{ return rows_; }

	unsigned int GetCols() const
	{ return cols_; }

	T* GetRawData()
	{ return dataCol_; }

	const T* GetRawDataConst() const
	{ return dataCol_; }

	svdVector<T> GetRowVector( unsigned rows ) const;
	svdVector<T> GetColVector( unsigned cols ) const;
	void SetRowVector( unsigned rows, const svdVector<T> & row );
	void SetColVector( unsigned cols, const svdVector<T> & col );
	void NormaliseRows();
	void NormaliseCols();

	void Print() const;
	void SetAll( T s );

	void Zero()
	{ SetAll(0); }

	bool IsInf();
	svdMatrix Transposed() const;
	svdMatrix Inverted() const;

	bool operator==( const svdMatrix & other ) const;

	svdMatrix operator+( const svdMatrix & other ) const;
	svdMatrix operator-( const svdMatrix & other ) const;
	svdMatrix operator*( const svdMatrix & other ) const;
	svdVector<T> operator*( const svdVector<T> & other ) const;
	svdVector<T> VecMulTransposed( const svdVector<T> & other ) const;

	svdMatrix& operator=( const svdMatrix & other );
	svdMatrix& operator+=( const svdMatrix & other );
	svdMatrix& operator-=( const svdMatrix & other );
	svdMatrix& operator*=( const svdMatrix & other );


	// sciloop add
	//
	void setRowAndCol( unsigned rows, unsigned cols );
	//void deleteAllData();
	float determinant() const;

	void SortRows( svdVector<T> & v );
	void SortCols( svdVector<T> & v );

	svdMatrix CropRows( unsigned int s, unsigned int e );
	svdMatrix CropCols( unsigned int s, unsigned int e );

	void Save( FILE * f ) const;
	void Load( FILE * f );

	static void RunTests();

private:

	unsigned int rows_;
	unsigned int cols_;

	T * dataCol_ = nullptr;
};

//______________________________________________________________________
//
//
template<class T>
float svdMatrix<T>::determinant() const
{
	if( rows_!=cols_ || rows_<3 || rows_>4 )
	{
		//cout << " cannot do determinant with " << rows_ << " rows and " << cols_ << " cols" << endl;
		return 0.0;
	}

	float det = ((*this)[0][0] * ((*this)[1][1]*(*this)[2][2] - (*this)[1][2]*(*this)[2][1])) -
		((*this)[0][1] * ((*this)[1][0]*(*this)[2][2] - (*this)[1][2]*(*this)[2][0])) +
		((*this)[0][2] * ((*this)[1][0]*(*this)[2][1] - (*this)[1][1]*(*this)[2][0]));

//cout << " det0 : " << det << std::endl;


	det = 	((*this)[0][0]*(*this)[1][1]*(*this)[2][2] +	(*this)[1][0]*(*this)[2][1]*(*this)[0][2] + (*this)[0][1]*(*this)[1][2]*(*this)[2][0]) -
		((*this)[0][2]*(*this)[1][1]*(*this)[2][0] +	(*this)[0][1]*(*this)[1][0]*(*this)[2][2] + (*this)[1][2]*(*this)[2][1]*(*this)[0][0]);

//cout << " det0 : " << det << std::endl;

	return det;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T>::svdMatrix(	unsigned rows,
							unsigned cols ) :
								rows_(rows),
								cols_(cols)
{
	dataCol_ = new T[rows*cols];
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T>::svdMatrix() :
				rows_(0),
				cols_(0),
				dataCol_(nullptr)
{}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T>::svdMatrix(	unsigned r,
							unsigned c,
							float * data ) :
							rows_(r),
							cols_(c),
							dataCol_(data)
{}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T>::~svdMatrix()
{delete[] dataCol_;}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T>::svdMatrix( const svdMatrix & other )
{
	rows_ = other.rows_;
	cols_ = other.cols_;
	dataCol_ = new T[rows_*cols_];

	memcpy(	dataCol_,
			other.dataCol_,
			rows_*cols_*sizeof(T) );
}

//______________________________________________________________________
//
// sciloop add
//
template<class T>
void svdMatrix<T>::setRowAndCol( unsigned rows, unsigned cols )
{
	if( dataCol_!=nullptr )
	{ delete[] dataCol_; }

	rows_ = rows;
	cols_ = cols;
	dataCol_ = new T[rows_*cols_];
}

//______________________________________________________________________
//
// sciloop add
//
//template<class T>
//void svdMatrix<T>::deleteAllData()
//{
//	if( data_!=nullptr )
//	{ delete[] data_; }
//
//	rows_ = 0;
//	cols_ = 0;
//}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> & svdMatrix<T>::operator=( const svdMatrix & other )
{
	if( dataCol_!=nullptr )
	{delete[] dataCol_;}

	rows_ = other.rows_;
	cols_ = other.cols_;
	dataCol_ = new T[rows_*cols_];

	memcpy( dataCol_,
			other.dataCol_,
			rows_*cols_*sizeof(T) );

	return *this;
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::Print() const
{
	for( unsigned int i=0; i<rows_; i++ )
	{
		for( unsigned int j=0; j<cols_; j++ )
		{std::cerr<<(*this)[i][j]<<" ";}

		std::cerr<<std::endl;
	}
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::SetAll( T s )
{
	for( unsigned int i=0; i<rows_; i++ )
	{
		for( unsigned int j=0; j<cols_; j++ )
		{(*this)[i][j] = s;}
	}
}

//______________________________________________________________________
//
//
template<class T>
bool svdMatrix<T>::IsInf()
{
	for( unsigned int i=0; i<rows_; i++ )
	{
		for( unsigned int j=0; j<cols_; j++ )
		{
			if( isinf( (*this)[i][j] ) )
			{ return true; }

			if( isnan( (*this)[i][j] ) )
			{ return true; }
		}
	}
	return false;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> svdMatrix<T>::Transposed() const
{
	svdMatrix<T> copyMat( cols_, rows_ );

	for( unsigned int i=0; i<rows_; i++ )
	{
		for( unsigned int j=0; j<cols_; j++ )
		{ copyMat[j][i] = (*this)[i][j];}
	}

	return copyMat;
}

//______________________________________________________________________
//
//
void matrix_inverse(	const float * Min,
						float * Mout,
						int actualsize );

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> svdMatrix<T>::Inverted() const
{
	// only works for square matrices
	//
	assert( rows_==cols_ );

	/*svdMatrix<T> inverse( rows_, cols_ );

	bool invertible;
	T c00 = (*this)[1, 1]*(*this)[2, 2] - (*this)[1, 2]*(*this)[2, 1];
	T c10 = (*this)[1, 2]*(*this)[2, 0] - (*this)[1, 0]*(*this)[2, 2];
	T c20 = (*this)[1, 0]*(*this)[2, 1] - (*this)[1, 1]*(*this)[2, 0];
	T det = (*this)[0, 0]*c00 + (*this)[0, 1]*c10 + (*this)[0, 2]*c20;

	if( det!=(T)0 )
	{
		T invDet = ((T)1) / det;

		inverse = Matrix3x3<Real>
		{
			c00*invDet,
			(M( 0, 2 )*M( 2, 1 ) - M( 0, 1 )*M( 2, 2 ))*invDet,
			(M( 0, 1 )*M( 1, 2 ) - M( 0, 2 )*M( 1, 1 ))*invDet,
			c10*invDet,
			(M( 0, 0 )*M( 2, 2 ) - M( 0, 2 )*M( 2, 0 ))*invDet,
			(M( 0, 2 )*M( 1, 0 ) - M( 0, 0 )*M( 1, 2 ))*invDet,
			c20*invDet,
			(M( 0, 1 )*M( 2, 0 ) - M( 0, 0 )*M( 2, 1 ))*invDet,
			(M( 0, 0 )*M( 1, 1 ) - M( 0, 1 )*M( 1, 0 ))*invDet
		};

		invertible = true;
	}
	else
	{
		inverse.MakeZero();
		invertible = false;
	}

	if( reportInvertibility )
	{ *reportInvertibility = invertible; }

	return inverse;*/




	matrix_inverse(	GetRawDataConst(),
					ret.GetRawData(),
					rows_ );

	return ret;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> svdMatrix<T>::operator+( const svdMatrix & other ) const
{
	assert( rows_==other.rows_ );
	assert( cols_==other.cols_ );

	svdMatrix<T> ret( rows_,cols_ );

	for( unsigned int i=0; i<rows_; i++ )
	{
		for (unsigned int j=0; j<cols_; j++)
		{ret[i][j] = (*this)[i][j]+other[i][j];}
	}
	return ret;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> svdMatrix<T>::operator-( const svdMatrix & other ) const
{
	assert( rows_==other.rows_ );
	assert( cols_==other.cols_ );

	svdMatrix<T> ret( rows_,cols_ );

	for( unsigned i=0; i<rows_; i++ )
	{
		for( unsigned j=0; j<cols_; j++ )
		{ret[i][j]=(*this)[i][j]-other[i][j];}
	}
	return ret;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> svdMatrix<T>::operator*( const svdMatrix & other ) const
{
	assert( cols_==other.rows_ );

	svdMatrix<T> ret( rows_, other.cols_ );

	for( unsigned i=0; i<rows_; i++ )
	{
		for( unsigned j=0; j<other.cols_; j++ )
		{
			ret[i][j] = 0;

			for( unsigned k=0; k<cols_; k++ )
			{ret[i][j] += (*this)[i][k]*other[k][j];}
		}
	}
	return ret;
}

//______________________________________________________________________
//
// Transform a vector with the matrix.
//
template<class T>
svdVector<T> svdMatrix<T>::operator*( const svdVector<T> & other ) const
{
	assert( cols_==other.Size() );

	svdVector<T> ret( rows_ );

	for( unsigned int i=0; i<rows_; i++ )
	{
		//for( unsigned int j=0; j<other.Size(); j++ )
		//{
			ret[i] = 0;

			for( unsigned int k=0; k<cols_; k++ )
			{ret[i] += (*this)[i][k]*other[k];}
		//}
	}

	return ret;
}

//______________________________________________________________________
//
//
template<class T>
svdVector<T> svdMatrix<T>::VecMulTransposed( const svdVector<T> &other ) const
{
	assert( rows_==other.Size() );

	svdVector<T> ret( cols_ );

	for( unsigned int i=0; i<cols_; i++ )
	{
		for( unsigned int j=0; j<other.Size(); j++ )
		{
			ret[i] = 0;

			for( unsigned int k=0; k<rows_; k++ )
			{ret[i] += (*this)[k][i]*other[k];}
		}
	}
	return ret;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> &svdMatrix<T>::operator+=( const svdMatrix & other )
{
	(*this) = (*this) + other;

	return *this;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> &svdMatrix<T>::operator-=( const svdMatrix & other )
{
	(*this) = (*this) - other;

	return *this;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> &svdMatrix<T>::operator*=( const svdMatrix & other )
{
	(*this) = (*this) * other;

	return *this;
}

//______________________________________________________________________
//
//
template<class T>
bool svdMatrix<T>::operator==( const svdMatrix & other ) const
{
	if( rows_ != other.rows_ ||
		cols_ != other.cols_ )
	{return false;}

	for( unsigned int i=0; i<cols_; i++ )
	{
		for( unsigned int j=0; j<rows_; j++ )
		{
			if( !feq( (*this)[i][j], other[i][j] ) )
			{ return false; }
		}
	}

	return true;
}

//______________________________________________________________________
//
//
//todo: use memcpy for these 4 functions
template<class T>
svdVector<T> svdMatrix<T>::GetRowVector( unsigned currRow ) const
{
	assert( currRow<rows_ );
	svdVector<T> ret( cols_ );

	for( unsigned int j=0; j<cols_; j++ )
	{ret[j] = (*this)[currRow][j];}

	return ret;
}

//______________________________________________________________________
//
//
template<class T>
svdVector<T> svdMatrix<T>::GetColVector( unsigned currCol ) const
{
	assert( currCol<cols_ );

	svdVector<T> ret( rows_ );

	for( unsigned i=0; i<rows_; i++ )
	{ret[i] = (*this)[i][currCol];}

	return ret;
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::SetRowVector(	unsigned int currRow,
									const svdVector<T> & row )
{
	assert( currRow<rows_ );
	assert( row.Size()==cols_ );

	for (unsigned int j=0; j<cols_; j++)
	{(*this)[currRow][j] = row[j];}
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::SetColVector(	unsigned int currCol,
									const svdVector<T> & col )
{
	assert( currCol<cols_ );
	assert(col.Size()==rows_);

	for (unsigned int i=0; i<rows_; i++)
	{(*this)[i][currCol] = col[i];}
}

//______________________________________________________________________
//
//
// sort rows by v
template<class T>
void svdMatrix<T>::SortRows( svdVector<T> & v )
{
	assert( v.Size()==rows_ );

	bool sorted = false;

	while( !sorted )
	{
		sorted = true;

		for( unsigned int i=0; i<v.Size()-1; i++ )
		{
			if (v[i]<v[i+1])
			{
				sorted = false;

				float vtmp = v[i];
				v[i] = v[i+1];
				v[i+1] = vtmp;

				svdVector<float> rtmp = GetRowVector( i );
				SetRowVector( i, GetRowVector(i+1) );
				SetRowVector( i+1,rtmp );
			}
		}
	}
}

//______________________________________________________________________
//
// sort cols by v
// From first to last index we want to have biggest to smallest v value.
//
template<class T>
void svdMatrix<T>::SortCols( svdVector<T> & v )
{
	assert( v.Size()==cols_ );

	bool sorted = false;

	while( !sorted )
	{
		sorted = true;

		for( unsigned int i=0; i<v.Size()-1; i++ )
		{
			if( v[i]<v[i+1] )
			{
				sorted = false;

				float vtmp = v[i];
				v[i] = v[i+1];
				v[i+1] = vtmp;

				svdVector<float> rtmp = GetColVector( i );
				SetColVector( i, GetColVector(i+1) );
				SetColVector( i+1, rtmp );
			}
		}
	}
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> svdMatrix<T>::CropRows(	unsigned int s,
										unsigned int e )
{
	assert(s<e);
	assert(s<rows_);
	assert(e<=rows_);

	svdMatrix r(e-s,cols_);
	unsigned int c = 0;

	for( unsigned int i=s; i<e; i++ )
	{
		r.SetRowVector(c,GetRowVector(i));
		c++;
	}

	return r;
}

//______________________________________________________________________
//
//
template<class T>
svdMatrix<T> svdMatrix<T>::CropCols(	unsigned int s,
										unsigned int e )
{
	assert(s<e);
	assert(s<cols_);
	assert(e<=cols_);

	svdMatrix r(rows_,e-s);
	unsigned int c=0;

	for( unsigned int i=s; i<e; i++ )
	{
		r.SetColVector(c,GetColVector(i));
		c++;
	}

	return r;
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::NormaliseRows()
{
	for(unsigned int i=0; i<rows_; i++)
	{SetRowVector(i,GetRowVector(i).Normalised());}
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::NormaliseCols()
{
	for(unsigned int i=0; i<cols_; i++)
	{SetColVector(i,GetColVector(i).Normalised());}
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::Save(FILE* f) const
{
	int gVersion = 1;
	fwrite( &gVersion,1,sizeof(gVersion),f );
	fwrite( &rows_,1,sizeof(rows_),f );
	fwrite( &cols_,1,sizeof(cols_),f );
	fwrite( data_,1,sizeof(T)*rows_*cols_, f);
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::Load( FILE* f )
{
	int gVersion;
	fread( &gVersion,sizeof(gVersion),1,f );
	fread( &rows_,sizeof(rows_),1,f );
	fread( &cols_,sizeof(cols_),1,f );
	data_ = new T[rows_*cols_];
	fread( data_,sizeof(T)*rows_*cols_,1,f );
}

//______________________________________________________________________
//
//
template<class T>
void svdMatrix<T>::RunTests()
{
	svdVector<T>::RunTests();

	std::cerr<<"running matrix tests"<<std::endl;

	svdMatrix<T> mMat(10,10);
	mMat.SetAll(0);

	assert( mMat[0][0]==0 );

	mMat[5][2]=0.5;

	assert( mMat[5][2]==0.5 );

	svdMatrix<T> omMat( mMat );

	assert( omMat[5][2]==0.5);

	svdMatrix<T> aMat(2,3);
	aMat[0][0]=1; aMat[0][1]=2; aMat[0][2]=3;
	aMat[1][0]=4; aMat[1][1]=5; aMat[1][2]=6;

	svdMatrix<T> bMat(3,1);
	bMat[0][0]=3;
	bMat[1][0]=1;
	bMat[2][0]=2;

	svdMatrix<T> cMat = aMat * bMat;

	assert( cMat[0][0]==11 && cMat[1][0]==29 );

	// test matrix * vector
	//
	svdVector<T> dVec(3);
	dVec[0]=3;
	dVec[1]=1;
	dVec[2]=2;
	svdVector<T> eVec = aMat*dVec;

	assert( eVec[0]==11 && eVec[1]==29 );

	svdMatrix<T> fMat = aMat.CropCols(1,3);

	assert( fMat.GetRows()==2 && fMat.GetCols()==2 && fMat[0][0]==2 );

	svdMatrix<T> gMat = aMat.CropRows(0,1);

	assert( gMat.GetRows()==1 && gMat.GetCols()==3 && gMat[0][0]==1 );

	// test matrix invert
	svdMatrix<T> hMat(3,3);
	hMat.Zero();
	hMat[0][0]=1;
	hMat[1][1]=1;
	hMat[2][2]=1;
	svdMatrix<T> iMat = hMat.Inverted();
	iMat==hMat;

	// some transforms from fluxus
	svdMatrix<T> jMat(4,4);
	jMat[0][0]=1.0;
	jMat[0][1]=0.0 ;
	jMat[0][2]=0.0;
	jMat[0][3]=0.0;

	jMat[1][0]=0.0 			;
	jMat[1][1]=0.7071067690849304 ;
	jMat[1][2]=0.7071067690849304 ;
	jMat[1][3]=0.0 				;

	jMat[2][0]=0.0 				;
	jMat[2][1]=-0.7071067690849304 ;
	jMat[2][2]=0.7071067690849304  ;
	jMat[2][3]=0.0 				;

	j[3][0]=1.0 				;
	j[3][1]=2.0 				;
	j[3][2]=3.0 				;
	j[3][3]=1.0 				;

	svdMatrix<T> k(4,4);
	k[0][0]=1.0 				 ;
	k[0][1]=0.0 				 ;
	k[0][2]=0.0 				 ;
	k[0][3]=0.0 				 ;

	k[1][0]=0.0 				 ;
	k[1][1]=0.7071068286895752   ;
	k[1][2]=-0.7071068286895752  ;
	k[1][3]=0.0 				 ;

	k[2][0]=0.0 				 ;
	k[2][1]=0.7071068286895752   ;
	k[2][2]=0.7071068286895752   ;
	k[2][3]=0.0 				 ;

	k[3][0]=-0.9999999403953552  ;
	k[3][1]=-3.535533905029297   ;
	k[3][2]=-0.7071067690849304  ;
	k[3][3]=0.9999999403953552	 ;

	assert(j.Inverted()==k);

	svdMatrix<float> l(2,2);
	l[0][0]=3;
	l[0][1]=3;
	l[1][0]=0;
	l[1][1]=0;

	svdMatrix<float> n(2,2);
	n[0][0]=2;
	n[0][1]=2;
	n[1][0]=0;
	n[1][1]=0;

	n*=l;

	svdMatrix<float> o(4,4);
	o.Zero();
	o[0][0]=1;
	o[1][1]=1;
	o[2][2]=1;
	o[3][3]=1;

	j*=k;
	assert(j==o);

	{
		svdMatrix<float> a(2,3);
		svdMatrix<float> b(3,2);

		a[0][0]=1; a[0][1]=2; a[0][2]=3;
		a[1][0]=4; a[1][1]=5; a[1][2]=6;

		b[0][0]=2; b[0][1]=3;
		b[1][0]=-1; b[1][1]=1;
		b[2][0]=1; b[2][1]=2;

		svdMatrix<float> result(2,2);
		result[0][0]=3; result[0][1]=11;
		result[1][0]=9; result[1][1]=29;

		assert(a*b==result);
	}
}

//______________________________________________________________________
//
//

}

#endif
