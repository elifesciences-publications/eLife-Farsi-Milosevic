// Copyright (C) 2009 foam
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either gVersion 2 of the License, or
// (at your option) any later gVersion.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

#include <assert.h>
#include <cmath>
#include <iostream>
#include <stdio.h>
#include <memory.h>

#ifndef FOAM_VECTOR
#define FOAM_VECTOR

namespace sciloop
{
//______________________________________________________________________
//
//
template<class T> bool feq(	T a,
							T b,
							T t=0.001 )
{return fabs(a-b)<t;}

//______________________________________________________________________
//
//
template<class T>class svdVector
{
public:
	svdVector();
	svdVector( unsigned int s );
	~svdVector();
	svdVector( const svdVector & other );

	T& operator[]( unsigned int i )
	{
		assert( i<size_ );
		return data_[i];
	}

	const T& operator[]( unsigned int i ) const
	{
		assert( i<size_ );
		return data_[i];
	}

	unsigned int Size() const
	{ return size_; }

	T* GetRawData()
	{ return data_; }

	const T* GetRawDataConst() const
	{ return data_; }

	void Print() const;
	void SetAll( T s );

	// sciloop add
	//
	//void deleteAllData();
	//void resize( unsigned newSize );

	void Zero()
	{ SetAll(0); }

	bool IsInf();
	T Mean();
	T DistanceFrom( const svdVector & other ) const;
	T Magnitude() const;
	T Dot( const svdVector<T> & other );
	svdVector Normalised() const;

	svdVector & operator=( const svdVector & other );
	svdVector operator+( const svdVector & other ) const;
	svdVector operator-( const svdVector & other ) const;
	float operator*( const svdVector & other ) const;
	svdVector operator+( T v ) const;
	svdVector operator-( T v ) const;
	svdVector operator*( T v ) const;
	svdVector operator/( T v ) const;
	svdVector & operator+=( const svdVector & other );
	svdVector & operator-=( const svdVector & other );
	svdVector & operator+=( T v );
	svdVector & operator-=( T v );
	svdVector & operator*=( T v );
	svdVector & operator/=( T v );

	void Save( FILE *f ) const;
	void Load( FILE *f );

	static void RunTests();

private:

	unsigned size_;
	T * data_ = nullptr;
};

//______________________________________________________________________
//
//
template<class T> svdVector<T>::svdVector() :
										size_(0)
{data_ = nullptr;}

//______________________________________________________________________
//
// sciloop add
//
//template<class T>
//void svdVector<T>::deleteAllData()
//{
//	if( data_!=nullptr )
//	{ delete[] data_; }
//}

//______________________________________________________________________
//
//
template<class T> svdVector<T>::svdVector(	unsigned int s) :
											size_(s)
{data_ = new T[s];}

//______________________________________________________________________
//
//
template<class T> svdVector<T>::~svdVector()
{delete[] data_;}

//______________________________________________________________________
//
//
template<class T> svdVector<T>::svdVector( const svdVector & other )
{
	size_ = other.size_;
	data_ = new T[size_];
	memcpy( data_,other.data_,size_*sizeof(T) );
}

//______________________________________________________________________
//
//
template<class T> svdVector<T>& svdVector<T>::operator=( const svdVector & other )
{
	if( data_!=nullptr )
	{delete[] data_;}

	size_ = other.size_;
	data_ = new T[size_];
	memcpy( data_, other.data_, size_*sizeof(T) );

	return *this;
}

//______________________________________________________________________
//
//
template<class T> void svdVector<T>::Print() const
{
	for( unsigned int i=0; i<size_; i++ )
	{std::cerr<<(*this)[i]<<" ";}

	std::cerr<<std::endl;
}

//______________________________________________________________________
//
//
template<class T> void svdVector<T>::SetAll( T s )
{
	for (unsigned int i=0; i<size_; i++)
	{(*this)[i] = s;}
}

//______________________________________________________________________
//
// sciloop add
//
//template<class T>
//void svdVector<T>::resize( unsigned newSize )
//{
//	if( size_==newSize )
//	{ return; }
//
//	else
//	{
//		if( data_!=nullptr )
//		{
//			T * data = new T[size_];
//			memcpy( data, data_, size_*sizeof(T) );
//
//			delete[] data_;
//
//			data_ = new T[newSize];
//			memcpy( data_, data, size_*sizeof( T ) );
//
//			delete[] data;
//		}
//		else
//		{data_ = new T[newSize];}
//
//		size_ = newSize;
//	}
//}


//______________________________________________________________________
//
//
template<class T> bool svdVector<T>::IsInf()
{
	for( unsigned int i=0; i<size_; i++ )
	{
		if( isinf( (*this)[i] ) )
		{ return true; }

		if( isnan( (*this)[i] ) )
		{ return true; }
	}
	return false;
}

//______________________________________________________________________
//
//
template<class T> T svdVector<T>::DistanceFrom( const svdVector &other ) const
{
	assert( size_==other.size_ );

	float acc = 0;

	for( unsigned int i=0; i<size_; i++ )
	{acc += (other[i]-(*this)[i]) * (other[i]-(*this)[i]);}

	return sqrt( acc );
}

//______________________________________________________________________
//
//
template<class T> T svdVector<T>::Magnitude() const
{
	float acc = 0;

	for( unsigned int i=0; i<size_; i++ )
	{acc += (*this)[i] * (*this)[i];}

	return sqrt( acc );
}

//______________________________________________________________________
//
//
template<class T> T svdVector<T>::Dot( const svdVector<T> & other )
{
	assert( size_==other.size_ );
	T acc = 0;

	for( unsigned int i=0; i<size_; i++ )
	{acc += (*this)[i] * other[i];}

	return acc;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> svdVector<T>::Normalised() const
{
	svdVector<T> ret(*this);
	ret /= ret.Magnitude();

	return ret;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> svdVector<T>::operator+( const svdVector & other ) const
{
	assert( size_==other.size_ );

	svdVector<T> ret( size_ );

	for ( unsigned int i=0; i<size_; i++ )
	{ret[i] = (*this)[i] + other[i];}

	return ret;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> svdVector<T>::operator-(const svdVector & other) const
{
	assert( size_==other.size_ );

	svdVector<T> ret( size_ );

	for( unsigned int i=0; i<size_; i++ )
	{ret[i] = (*this)[i] - other[i];}

	return ret;
}

//______________________________________________________________________
//
// sciloop add dot product
//
template<class T> float svdVector<T>::operator*( const svdVector & other ) const
{
	assert( size_==other.size_ );

	float res = 0.0f;

	for( unsigned int i=0; i<size_; i++ )
	{ res += (*this)[i] * other[i]; }

	return res;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> svdVector<T>::operator+(T v) const
{
	svdVector<T> ret( size_ );

	for( unsigned int i=0; i<size_; i++ )
	{ret[i] = (*this)[i] + v;}

	return ret;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> svdVector<T>::operator-(T v) const
{
	svdVector<T> ret(size_);

	for( unsigned int i=0; i<size_; i++ )
	{ret[i] = (*this)[i] - v;}

	return ret;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> svdVector<T>::operator*(T v) const
{
	svdVector<T> ret( size_ );

	for( unsigned int i=0; i<size_; i++ )
	{ret[i] = (*this)[i] * v;}

	return ret;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> svdVector<T>::operator/(T v) const
{
	svdVector<T> ret( size_ );

	for( unsigned int i=0; i<size_; i++ )
	{ret[i] = (*this)[i] / v;}

	return ret;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> &svdVector<T>::operator+=( const svdVector & other )
{
	assert( size_==other.size_ );

	for( unsigned int i=0; i<size_; i++ )
	{(*this)[i] += other[i];}

	return *this;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> &svdVector<T>::operator-=( const svdVector & other )
{
	assert( size_==other.size_ );

	for( unsigned int i=0; i<size_; i++ )
	{(*this)[i] -= other[i];}

	return *this;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> &svdVector<T>::operator+=(T v)
{
	for( unsigned int i=0; i<size_; i++ )
	{(*this)[i] += v;}

	return *this;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> &svdVector<T>::operator-=(T v)
{
	for( unsigned int i=0; i<size_; i++ )
	{(*this)[i] -= v;}

	return *this;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> &svdVector<T>::operator*=(T v)
{
	for( unsigned int i=0; i<size_; i++ )
	{(*this)[i] *= v;}

	return *this;
}

//______________________________________________________________________
//
//
template<class T> svdVector<T> &svdVector<T>::operator/=(T v)
{
	for( unsigned int i=0; i<size_; i++ )
	{(*this)[i] /= v;}

	return *this;
}

//______________________________________________________________________
//
//
template<class T> T svdVector<T>::Mean()
{
	T acc = 0;

	for( unsigned int i=0; i<size_; i++ )
	{acc += (*this)[i];}

	return acc/(float)size_;
}

//______________________________________________________________________
//
//
template<class T> void svdVector<T>::Save(FILE* f) const
{
	int gVersion = 1;
	fwrite( &gVersion, sizeof(gVersion), 1, f );
	fwrite( &size_, sizeof(size_), 1, f );
	fwrite( data_, sizeof(T)*size_, 1, f );
}

//______________________________________________________________________
//
//
template<class T> void svdVector<T>::Load(FILE* f)
{
	int gVersion;
	fread( &gVersion, sizeof(gVersion), 1, f );
	fread( &size_, sizeof(size_), 1, f );
	data_ = new T[size_];
	fread( data_, sizeof(T)*size_, 1, f );
}

//______________________________________________________________________
//
//
template<class T> void svdVector<T>::RunTests()
{
	svdVector<T> m(10);
	m.SetAll(0);

	assert(m[0]==0);

	m[5]=0.5;

	assert(m[5]==0.5);

	svdVector<T> om(m);

	assert(om[5]==0.5);

	assert(feq(m.Magnitude(),0.5f));

	svdVector<T> a(10);
	a.Zero();
	a[5]=-10;

	assert(feq(a.DistanceFrom(m),10.5f));
}

//______________________________________________________________________
//
//

}

#endif

