//
// Copyright (C) 2009 foam
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either gVersion 2 of the License, or
// (at your option) any later gVersion.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received aMat copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

// from http://www.public.iastate.edu/~dicook/JSS/paper/paper.html

/************************************************************
 *                                                          *
 *  Permission is hereby granted  to  any  individual   or  *
 *  institution   for  use,  copying, or redistribution of  *
 *  this code and associated documentation,  provided       *
 *  that   such  code  and documentation are not sold  for  *
 *  profit and the  following copyright notice is retained  *
 *  in the code and documentation:                          *
 *     Copyright (c) held by Dianne Cook                    *
 *  All Rights Reserved.                                    *
 *                                                          *
 *  Questions and comments are welcome, and I request       *
 *  that you share any modifications with me.               *
 *                                                          *
 *                Dianne Cook                               *
 *             dicook@iastate.edu                           *
 *                                                          *
 ************************************************************/

/*
 * svdcomp - SVD decomposition routine.
 * Takes an mxn matrix aMat and decomposes it into udv, where u,v are
 * left and right orthogonal transformation matrices, and d is aMat
 * diagonal matrix of singular values.
 *
 * This routine is adapted from svdecomp.c in XLISP-STAT 2.1 which is
 * code from Numerical Recipes adapted by Luke Tierney and David Betz.
 *
 * Input to dsvd is as follows:
 * uMat   = mxn matrix to be decomposed, gets overwritten with u	-> u -> python : u
 * rowDim = row    dimension of uMat
 * colDim = column dimension of uMat
 * w      = returns the vector of singular values of uMat			-> d -> python : s
 * vMat   = returns the right orthogonal transformation matrix		-> v -> python : v
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <algorithm>
#include <list>
#include "SVD.h"

using namespace std;

namespace sciloop
{
#define SIGN(aMat, b) ((b) >= 0.0 ? fabs(aMat) : -fabs(aMat))
#define MAX(x,y) ((x)>(y)?(x):(y))


//______________________________________________________________________
//
//
svdVector<float> SVD( svdMatrix<float> & uMat )
{
	svdVector<float> sVec( uMat.GetRows() );
	svdMatrix<float> vMat( uMat.GetRows(), uMat.GetCols() );

	dsvd(	uMat,
			uMat.GetRows(),
			uMat.GetCols(),
			sVec.GetRawData(),
			vMat );

	uMat.SortCols( sVec );

	return sVec;
}

//______________________________________________________________________
//
//
static double PYTHAG( double a, double b )
{
	double at = fabs( a );
	double bt = fabs( b );
	double ct;
	double result;

	if( at>bt )
	{
		ct = bt / at;
		result = at*sqrt( 1.0 + ct*ct ); }

	else if( bt>0.0 )
	{
		ct = at / bt;
		result = bt*sqrt( 1.0 + ct*ct ); }

	else
	{ result = 0.0; }

	return result;
}

//______________________________________________________________________
//
//
int dsvd(   svdMatrix<float>	& uMat,
			int					  rowDim,
			int					  colDim,
			float				* w,
			svdMatrix<float>	& vMat )
{

	int flag, i, its, j, jj, k, l, nm;
	double c, f, h, s, x, y, z;
	double anorm = 0.0;
	double g = 0.0;
	double scale = 0.0;
	double * rv1 = nullptr;

	// In our case rowDim==colDim.
	//
	if( rowDim<colDim )
	{
		fprintf(stderr, "#rows must be > #cols \n");
		return 0;
	}

	rv1 = (double *)malloc((unsigned int)colDim*sizeof(double));

// Householder reduction to bidiagonal form

	for( i=0; i<colDim; i++ )
	{
		// left-hand reduction
		//
		l = i + 1;
		rv1[i] = scale*g;
		g = s = scale = 0.0;

		if( i<rowDim )
		{
			for( k=i; k<rowDim; k++ )
			{ scale += fabs( (double)uMat[k][i] ); }

			if( scale )
			{
				for( k=i; k<rowDim; k++ )
				{
					uMat[k][i] = (float)((double)uMat[k][i]/scale);
					s += ((double)uMat[k][i] * (double)uMat[k][i]);
				}

				f = (double)uMat[i][i];
				g = -SIGN(sqrt(s), f);
				h = f*g - s;
				uMat[i][i] = (float)(f - g);

				if( i!=colDim-1 )
				{
					for( j=l; j<colDim; j++ )
					{
						for( s=0.0, k=i; k<rowDim; k++ )
						{ s += ((double)uMat[k][i] * (double)uMat[k][j]); }

						f = s / h;

						for( k=i; k<rowDim; k++ )
						{ uMat[k][j] += (float)(f*(double)uMat[k][i]); }
					}
				}

				for( k=i; k<rowDim; k++ )
				{ uMat[k][i] = (float)((double)uMat[k][i]*scale); }
			}
		}

		w[i] = (float)(scale*g);

		// right-hand reduction
		//
		g = s = scale = 0.0;

		if( i<rowDim && i!=colDim-1 )
		{
			for( k=l; k<colDim; k++ )
			{ scale += fabs( (double)uMat[i][k] ); }

			if( scale )
			{
				for( k=l; k<colDim; k++ )
				{
					uMat[i][k] = (float)((double)uMat[i][k]/scale);
					s += ((double)uMat[i][k] * (double)uMat[i][k]);
				}

				f = (double)uMat[i][l];
				g = -SIGN(sqrt(s), f);
				h = f*g - s;
				uMat[i][l] = (float)(f - g);

				for( k=l; k<colDim; k++ )
				{ rv1[k] = (double)uMat[i][k] / h; }

				if( i!=rowDim-1 )
				{
					for( j=l; j<rowDim; j++ )
					{
						for( s=0.0, k=l; k<colDim; k++ )
						{ s += ((double)uMat[j][k] * (double)uMat[i][k]); }

						for( k=l; k<colDim; k++ )
						{ uMat[j][k] += (float)(s * rv1[k]); }
					}
				}

				for( k=l; k<colDim; k++ )
				{ uMat[i][k] = (float)((double)uMat[i][k]*scale); }
			}
		}

		anorm = MAX(anorm, (fabs((double)w[i]) + fabs(rv1[i])));
	}

	// accumulate the right-hand transformation
	//
	for( i=colDim-1; i>=0; i-- )
	{
		if( i<colDim-1 )
		{
			if( g )
			{
				for( j=l; j<colDim; j++ )
				{ vMat[j][i] = (float)(((double)uMat[i][j] / (double)uMat[i][l]) / g); }

					/* double division to avoid underflow */
				for( j=l; j<colDim; j++ )
				{
					for( s=0.0, k=l; k<colDim; k++ )
					{ s += ((double)uMat[i][k] * (double)vMat[k][j]); }

					for( k=l; k<colDim; k++ )
					{ vMat[k][j] += (float)(s * (double)vMat[k][i]); }
				}
			}

			for( j=l; j<colDim; j++ )
			{ vMat[i][j] = vMat[j][i] = 0.0; }
		}

		vMat[i][i] = 1.0;
		g = rv1[i];
		l = i;
	}

	/* accumulate the left-hand transformation */
	for( i=colDim-1; i>=0; i-- )
	{
		l = i + 1;
		g = (double)w[i];

		if( i<colDim-1 )
		{
			for( j=l; j<colDim; j++ )
			{ uMat[i][j] = 0.0; }
		}

		if( g )
		{
			g = 1.0 / g;

			if( i!=colDim-1 )
			{
				for( j=l; j<colDim; j++ )
				{
					for( s=0.0, k=l; k<rowDim; k++ )
					{ s += ((double)uMat[k][i]*(double)uMat[k][j]); }

					f = (s / (double)uMat[i][i])*g;

					for( k=i; k<rowDim; k++ )
					{ uMat[k][j] += (float)(f*(double)uMat[k][i]); }
				}
			}

			for( j=i; j<rowDim; j++ )
			{ uMat[j][i] = (float)((double)uMat[j][i]*g); }
		}
		else
		{
			for( j=i; j<rowDim; j++ )
			{ uMat[j][i] = 0.0; }
		}

		++uMat[i][i];
	}

	/* diagonalize the bidiagonal form */
	//
	for( k=colDim-1; k>=0; k-- )
	{                             /* loop over singular values */
		for(its=0; its<30; its++)
		{                         /* loop over allowed iterations */
			flag = 1;

			for( l=k; l>=0; l-- )
			{                     /* test for splitting */
				nm = l - 1;

				if( fabs(rv1[l]) + anorm == anorm )
				{
					flag = 0;
					break;
				}

				if( fabs( (double)w[nm] ) + anorm == anorm )
				{ break; }
			}

			if( flag )
			{
				c = 0.0;
				s = 1.0;

				for( i=l; i<=k; i++ )
				{
					f = s*rv1[i];

					if( fabs(f) + anorm != anorm )
					{
						g = (double)w[i];
						h = PYTHAG(f, g);
						w[i] = (float)h;
						h = 1.0 / h;
						c = g*h;
						s = (- f * h);

						for( j=0; j<rowDim; j++ )
						{
							y = (double)uMat[j][nm];
							z = (double)uMat[j][i];
							uMat[j][nm] = (float)(y*c + z*s);
							uMat[j][i] = (float)(z*c - y*s);
						}
					}
				}
			}

			z = (double)w[k];

			if( l==k )
			{                  /* convergence */
				if( z<0.0 )
				{              /* make singular value nonnegative */
					w[k] = (float)(-z);

					for( j=0; j<colDim; j++ )
					{ vMat[j][k] = (-vMat[j][k]); }
				}
				break;
			}

			if( its>=30 )
			{
				free((void*) rv1);
				fprintf(stderr, "No convergence after 30,000! iterations \n");
				return(0);
			}

			/* shift from bottom 2 x 2 minor */
			//
			x = (double)w[l];
			nm = k - 1;
			y = (double)w[nm];
			g = rv1[nm];
			h = rv1[k];
			f = ((y-z)*(y+z) + (g-h)*(g+h)) / (2.0*h*y);
			g = PYTHAG(f, 1.0);
			f = ((x-z)*(x+z) + h*((y / (f + SIGN(g, f))) - h)) / x;

			/* next QR transformation */
			//
			c = s = 1.0;

			for( j=l; j<=nm; j++ )
			{
				i = j + 1;
				g = rv1[i];
				y = (double)w[i];
				h = s*g;
				g = c*g;
				z = PYTHAG(f, h);
				rv1[j] = z;
				c = f / z;
				s = h / z;
				f = x * c + g*s;
				g = g * c - x*s;
				h = y * s;
				y = y * c;

				for( jj=0; jj<colDim; jj++ )
				{
					x = (double)vMat[jj][j];
					z = (double)vMat[jj][i];
					vMat[jj][j] = (float)(x*c + z*s);
					vMat[jj][i] = (float)(z*c - x*s);
				}

				z = PYTHAG(f, h);
				w[j] = (float)z;

				if( z )
				{
					z = 1.0 / z;
					c = f*z;
					s = h*z;
				}

				f = (c*g) + (s*y);
				x = (c*y) - (s*g);

				for( jj=0; jj<rowDim; jj++ )
				{
					y = (double)uMat[jj][j];
					z = (double)uMat[jj][i];
					uMat[jj][j] = (float)(y*c + z*s);
					uMat[jj][i] = (float)(z*c - y*s);
				}
			}

			rv1[l] = 0.0;
			rv1[k] = f;
			w[k] = (float)x;
		}
	}

	free( (void*) rv1 );

	return 1;
}

}

