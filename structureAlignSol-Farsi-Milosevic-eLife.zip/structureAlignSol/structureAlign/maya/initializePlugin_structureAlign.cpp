//

#include <maya/MFnPlugin.h>
#include <maya/MGlobal.h>
#include "structureAlign.h"

//________________________________________________________________________
//
//
__declspec(dllexport) MStatus __cdecl initializePlugin( MObject obj )
{
	MStatus   stat;
	MFnPlugin plugin( obj, "sciloop", "2018", "Any" );

	stat = plugin.registerNode(	"structureAlign",
								structureAlign::id,
								structureAlign::creator,
								structureAlign::initialize );

	if( !stat )
	{
		MGlobal::displayInfo(	" sciloop message: c++ API: nodeType:"
								" 'structureAlign' -> registerNode failed!" );
	}
	else
	{

	MGlobal::displayInfo( " sciloop message: c++ API: nodeType:"
							" 'structureAlign' loaded." );
	}

	return stat;
}

//________________________________________________________________________
//
//
__declspec(dllexport) MStatus __cdecl uninitializePlugin( MObject obj )
{
	MStatus   stat;
	MFnPlugin plugin( obj );

	stat = plugin.deregisterNode( structureAlign::id );

	if( stat ) MGlobal::displayInfo( " sciloop message: c++ API: nodeType:"
									" 'structureAlign' unloaded." );

	return stat;
}

//________________________________________________________________________
//
//

