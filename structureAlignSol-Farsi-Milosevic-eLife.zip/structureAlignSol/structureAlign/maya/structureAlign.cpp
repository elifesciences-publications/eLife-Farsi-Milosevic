//

#include "structureAlign.h"

#include <maya/MDGModifier.h>
#include <maya/MVectorArray.h>

#include "../sciloop/sciMat33.h"
#include "../sciloop/sciVec3.h"

//____________________________________________________________________________
//
//
MTypeId structureAlign::id = 0x93;

//_________________________________________________________________________________
//
//
structureAlign::SchedulingType structureAlign::schedulingType()const
{return SchedulingType::kParallel;}

//____________________________________________________________________________
//
//
structureAlign::structureAlign()
{}

//____________________________________________________________________________
//
//
structureAlign::~structureAlign()
{}

//____________________________________________________________________________
//
//
void* structureAlign::creator()
{return( new structureAlign() );}

//____________________________________________________________________________
//
//
MStatus structureAlign::connectionMade( const MPlug & thisPlug,
										const MPlug & otherPlug,
										bool		  asSrc )
{
	if( thisPlug==iSource || thisPlug==iTarget || thisPlug==oOut )
	{
		dataType_e thisDataType;
		switch( thisPlug.asMObject().apiType() )
		{
		case MFn::Type::kMeshData:           thisDataType = dataType_e::kMesh; break;
		case MFn::Type::kNurbsCurveData:     thisDataType = dataType_e::kNurbsCurve;; break;
		case MFn::Type::kNurbsSurfaceData:   thisDataType = dataType_e::kNurbsSurface; break;
		case MFn::Type::kPluginGeometryData: thisDataType = dataType_e::kPluginGeometry; break;
		case MFn::Type::kPointArrayData:     thisDataType = dataType_e::kPointArray;  break;
		case MFn::Type::kVectorArrayData:    thisDataType = dataType_e::kVectorArray; break;
		default: thisDataType = dataType_e::kNurbsCurve;break;
		}

		bool doDisconnect = false;

		if( thisPlug==iSource )
		{
			if( targetIsConnected_==true )
			{
				if( thisDataType!=targetType_ )
				{
					cout << " tried to connect iSource, but iTarget is"
						   " already connected and has another type." << endl;;
					doDisconnect = true;
				}
			}
			else if( outIsConnected_==true )
			{
				if( thisDataType!=outType_ )
				{
					cout << " tried to connect iSource, but oOut is"
						   " already connected and has another type." << endl;;
					doDisconnect = true;
				}
			}

			if( doDisconnect==false )
			{
				sourceType_= thisDataType;
				sourceIsConnected_ = true;
			}
		}
		else if( thisPlug==iTarget )
		{
			if( sourceIsConnected_==true )
			{
				if( thisDataType!=sourceType_ )
				{
					cout << " tried to connect iTarget, but iSource is"
						   " already connected and has another type."<< endl;
					doDisconnect = true;
				}
			}
			else if( outIsConnected_==true )
			{
				if( thisDataType!=outType_ )
				{
					cout << " tried to connect iTarget, but oOut is"
						   " already connected and has another type."<< endl;
					doDisconnect = true;
				}
			}

			if( doDisconnect==false )
			{
				targetType_= thisDataType;
				targetIsConnected_ = true;
			}
		}
		else if( thisPlug==oOut )
		{
			if( sourceIsConnected_==true )
			{
				if( thisDataType!=sourceType_ )
				{
					cout << " tried to connect oOut, but iSource is"
						   " already connected and has another type."<< endl;
					doDisconnect = true;
				}
			}
			else if( targetIsConnected_==true )
			{
				if( thisDataType!=targetType_ )
				{
					cout << " tried to connect oOut, but iTarget is"
						   " already connected and has another type."<< endl;
					doDisconnect = true;
				}
			}

			if( doDisconnect==false )
			{
				outType_= thisDataType;
				outIsConnected_ = true;
			}
		}

		if( doDisconnect==true )
		{
			MDGModifier mod;
			mod.disconnect( otherPlug, thisPlug );
			mod.doIt();
		}
	}

	return MS::kUnknownParameter;
}


//____________________________________________________________________________
//
//
MStatus	structureAlign::connectionBroken( const MPlug	& thisPlug,
										  const MPlug	& otherPlug,
										  bool			  asSrc )
{
	if( thisPlug==iSource )
	{ sourceIsConnected_ = false; }
	else if( thisPlug==iTarget )
	{ targetIsConnected_ = false; }
	else if( thisPlug==oOut )
	{ outIsConnected_ = false; }

	return MS::kUnknownParameter;
}

//______________________________________________________________________
//
//
bool structureAlign::transformPointsToCentroidZero( MVectorArray	& sourceArr,
													MVectorArray	& targetArr,
													MVector			& sourceCentroid,
													MVector			& targetCentroid,
													bool			  centroidsToZero )
{
	unsigned lenA = sourceArr.length();
	unsigned lenB = targetArr.length();

	if( lenA!=lenB )
	{
		cout << " lenA!=lenB : " << lenA << " : " << lenB << endl;
		return false;
	}

	// Get the centroids.
	//
	for( unsigned i=0; i<lenA; i++ )
	{
		sourceCentroid += sourceArr[i];
		targetCentroid += targetArr[i];
	}

	sourceCentroid.x /= lenA;
	sourceCentroid.y /= lenA;
	sourceCentroid.z /= lenA;

	targetCentroid.x /= lenA;
	targetCentroid.y /= lenA;
	targetCentroid.z /= lenA;

	// Put the points to world zero.
	//
	if( centroidsToZero==true )
	{
		for( unsigned i=0; i<lenA; i++ )
		{
			sourceArr[i] = sourceArr[i] - sourceCentroid;
			targetArr[i] = targetArr[i] - targetCentroid;
		}
	}

	return true;
}

//___________________________________________________________________________________
//
//
bool structureAlign::convertToSvdData(	const MVectorArray	& source,
										const MVectorArray	& target,
										svdMatrix<float>	& sourcePoints,
										svdMatrix<float>	& targetPoints,
										const MVector		& sourceCentroid,
										const MVector		& targetCentroid,
										svdVector<float>	& sourceCentroidPoint,
										svdVector<float>	& targetCentroidPoint )
{
	// Set the matrix
	// svdMatrix is row major. We will have the xyz in 3 columns
	//
	sourcePoints.setRowAndCol( source.length(), 3 );
	targetPoints.setRowAndCol( source.length(), 3 );

	for( unsigned i=0, l=source.length(); i<l; i++ )
	{
		sourcePoints[i][0] = source[i].x;
		sourcePoints[i][1] = source[i].y;
		sourcePoints[i][2] = source[i].z;

		targetPoints[i][0] = target[i].x;
		targetPoints[i][1] = target[i].y;
		targetPoints[i][2] = target[i].z;
	}

	// Set the centroid vector.
	//
	sourceCentroidPoint[0] = sourceCentroid.x;
	sourceCentroidPoint[1] = sourceCentroid.y;
	sourceCentroidPoint[2] = sourceCentroid.z;

	targetCentroidPoint[0] = targetCentroid.x;
	targetCentroidPoint[1] = targetCentroid.y;
	targetCentroidPoint[2] = targetCentroid.z;

	return true;
}

//______________________________________________________________________
//
// Input: expects Nx3 matrix of points
// Returns Rotation, translation
// Rotation = 3x3 rotation matrix
// translation = 3x1 column vector
// -> the Kabsch algorithm
//
bool structureAlign::Kabsch( const svdMatrix<float> & sourcePoints,
							 const svdMatrix<float> & targetPoints,
							 const svdVector<float> & sourceCentroidPoint,
							 const svdVector<float> & targetCentroidPoint,
							 svdMatrix<float>		& rotMat,
							 svdVector<float>		& transVec )
{
	// Dot is matrix multiplication for array.
	// In this specific case the resulting matrix has dim : 3x3
	//
	svdMatrix<float> uMat = sourcePoints.Transposed() * targetPoints;

	unsigned rows = uMat.GetRows();
	unsigned cols = uMat.GetCols();

	svdVector<float> sVec( rows );
	svdMatrix<float> vMat( rows, cols );

	dsvd( uMat,
		  rows,
		  cols,
		  sVec.GetRawData(),
		  vMat );

	rotMat = vMat * uMat.Transposed();

	rotMat.determinant();

	// Get translation.
	//
	transVec = targetCentroidPoint - rotMat*sourceCentroidPoint;

	return true;
}

//______________________________________________________________________
//
// We want the axis of rotation to be the x axis.
// We want the center of rotation by transforming the data to a 2D plane.
// The axis will thus be rotated back to the x axis.
//
// 1. rotate source and target to z-y plane
// 2. get center in 2D
//
bool structureAlign::getCenterOfRotation2( const MPoint		& sourcePoint,
										   const MPoint		& target0FromSourceRotWithRM,
										   const MVector	& axis,
										   const float		  angle,
										   MVector			& rotCenter,
										   MVector			& idealTargetInXYPlane )
{
	sciVec3 sciAxis( (float)axis.x, (float)axis.y, (float)axis.z );
	sciVec3 zAxis( 0.0f, 0.0f, 1.0f );

	sciAxis.normalize();
	zAxis.normalize();

	sciMat33 matToZAxis;
	matToZAxis.orient( sciAxis, zAxis );

	sciVec3 oldSourcePoint( sourcePoint.x, sourcePoint.y, sourcePoint.z );
	sciVec3 oldTarget0FromSourceRotWithRM( target0FromSourceRotWithRM.x,
										   target0FromSourceRotWithRM.y,
										   target0FromSourceRotWithRM.z );

	// Rotate to z axis.
	//
	sciVec3 newSourcePoint = oldSourcePoint*matToZAxis;
	sciVec3 newTarget0FromSource = oldTarget0FromSourceRotWithRM*matToZAxis;

	// Get targetInXYPlane.
	//
	sciVec3 targetInXYPlane;
	targetInXYPlane.x_ = newTarget0FromSource.x_;
	targetInXYPlane.y_ = newTarget0FromSource.y_;
	targetInXYPlane.z_ = newSourcePoint.z_;

	float x1 = newSourcePoint.x_;
	float y1 = newSourcePoint.y_;

	float x2 = newTarget0FromSource.x_;
	float y2 = newTarget0FromSource.y_;

	// Slope of the line through the points
	//
	float slope;
	if( x1==x2 )
	{ slope = 99999999.9f; }
	else
	{ slope = (y1-y2)/(x1-x2); }

	// Slope of a line perpendicular to the linePoints
	//
	float new_slope = -1.0f/slope;

	// Point on the line perpendicular to the linePoints.
	// Note that this line also passes through the center of the circle.
	// xm, ym : middlePoint on linePoints.
	//
	float xm = (x1+x2)/2.0f;
	float ym = (y1+y2)/2.0f;

	// Distance between p1 and p2.
	//
	float distancePoints = sqrt( (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2) );

	float angleHalf = angle*0.5f;
	float distanceHalf = 0.5f*distancePoints;

	float tanAngle = tanf( angleHalf*3.14159f/180.0f );

	// Distance between xm, ym and center of the circle( xc, yc ).
	//
	float d_perp = distanceHalf/tanAngle;

	// Equation of line perpendicular to the linePoints : y-ym = new_slope( x-xm )
	// Distance between xm, ym and xc, yc: (yc-ym)^2 + (xc-xm)^2 = d_perp^2
	// Substituting from 1st to 2nd equation for y,
	// we get :
	// (xc-xm)^2 * (new_slope^2+1) = d_perp^2

	// Solve for xc:
	//
	float xc = d_perp/sqrt( new_slope*new_slope+1 ) + xm;

	// Solve for yc:
	//
	float yc = new_slope*(xc-xm) + ym;

	sciVec3 centerP( xc, yc, 0.0f );

	// Rotate back the center.
	//
	centerP = centerP*matToZAxis.inverse();

	rotCenter.x = centerP.x_;
	rotCenter.y = centerP.y_;
	rotCenter.z = centerP.z_;

	// Rotate back also the targetInXYPlane.
	//
	targetInXYPlane = targetInXYPlane*matToZAxis.inverse();

	idealTargetInXYPlane.x = targetInXYPlane.x_;
	idealTargetInXYPlane.y = targetInXYPlane.y_;
	idealTargetInXYPlane.z = targetInXYPlane.z_;

	return true;
}

//______________________________________________________________________
//
//
