//
#include "structureAlign.h"

#include <maya/MFnTypedAttribute.h>
#include<maya/MFnMatrixAttribute.h>
#include <maya/MFnNumericAttribute.h>
#include <maya/MFnGenericAttribute.h>
#include <maya/MFnUnitAttribute.h>
#include <maya/MFnEnumAttribute.h>

#include <maya/MAngle.h>
#include <maya/MDistance.h>

#include <maya/MFnNurbsSurfaceData.h>
#include <maya/MFnNurbsCurveData.h>
#include <maya/MVectorArray.h>
#include <maya/MFnMeshData.h>

#include <vector>
#include <string>


#define EPSILON				0.001
#define ROTATE_ORDER_XYZ	0
#define ROTATE_ORDER_YZX	1
#define ROTATE_ORDER_ZXY	2
#define ROTATE_ORDER_XZY	3
#define ROTATE_ORDER_YXZ	4
#define ROTATE_ORDER_ZYX	5

#define DEFAULT_ANGLE MAngle( 0.0, MAngle::kDegrees )
#define stringK MFnData::kString

#define IO_N \
	nAttr.setWritable( true ); \
	nAttr.setReadable( true );

#define IO_E \
	eAttr.setWritable( true ); \
	eAttr.setReadable( true );

#define IN_N \
	nAttr.setWritable( true ); \
	nAttr.setReadable( false );

#define OUT_N \
	nAttr.setWritable( false );	\
	nAttr.setReadable( true );

#define OUT_U \
	uAttr.setWritable( false ); \
	uAttr.setReadable( true );

#define MAKE_ANGLEDEG_O_ATTR \
	DEFAULT_ANGLE, &stat );	\
	OUT_U

#define MAKE_IO_ATTR( Attr ) \
	Attr.setWritable( true ); \
	Attr.setReadable( true );

#define MAKE_BOOLEANDEF_IO_ATTR( val )\
	MFnNumericData::kBoolean, val, &stat );\
	nAttr.setChannelBox( true );\
	IO_N

#define MAKE_ENUMDEF_2_IO_ATTR( val0, val1, initial ) \
	initial, &stat ); \
	eAttr.addField( val0, 0 ); \
	eAttr.addField( val1, 1 ); \
	eAttr.setChannelBox( true ); \
	IO_E

#define MAKE_ENUMDEF_3_IO_ATTR( val0, val1, val2, initial )	\
	initial, &stat ); \
	eAttr.addField( val0, 0 ); \
	eAttr.addField( val1, 1 ); \
	eAttr.addField( val2, 2 ); \
	eAttr.setChannelBox( true ); \
	IO_E

#define MAKE_ENUMDEF_4_IO_ATTR( val0, val1, val2, val3, initial ) \
	initial, &stat ); \
	eAttr.addField( val0, 0 ); \
	eAttr.addField( val1, 1 ); \
	eAttr.addField( val2, 2 ); \
	eAttr.addField( val3, 3 ); \
	eAttr.setChannelBox( true ); \
	IO_E

#define MAKE_O_ATTR( Attr )	\
	Attr.setWritable( false ); \
	Attr.setReadable( true );

#define OUT_T \
	tAttr.setWritable( false );	\
	tAttr.setReadable( true );

#define MAKE_TYPED_O_ATTR( type ) \
	type, MObject::kNullObj, &stat ); \
	OUT_T

#define MAKE_DOUBLEDEF_O_ATTR( val ) \
	MFnNumericData::kDouble, val, &stat ); \
	OUT_N

MObject structureAlign::iSource;
MObject structureAlign::iTarget;
MObject structureAlign::iRotateOrder;
MObject structureAlign::iCentroidsToZero;
MObject structureAlign::iPrintToOutput;
MObject structureAlign::iCalcType;
MObject structureAlign::iStructureType;
MObject structureAlign::iAxisCenterType;
	MObject structureAlign::iCustomAxisCenterX;
	MObject structureAlign::iCustomAxisCenterY;
	MObject structureAlign::iCustomAxisCenterZ;
MObject structureAlign::iCustomAxisCenter;

	MObject structureAlign::oCentroidSourceX;
	MObject structureAlign::oCentroidSourceY;
	MObject structureAlign::oCentroidSourceZ;
MObject structureAlign::oCentroidSource;
	MObject structureAlign::oCentroidTargetX;
	MObject structureAlign::oCentroidTargetY;
	MObject structureAlign::oCentroidTargetZ;
MObject structureAlign::oCentroidTarget;

MObject structureAlign::oAngle;

MObject structureAlign::oMatrix;

	MObject structureAlign::oRotateOfRMX;
	MObject structureAlign::oRotateOfRMY;
	MObject structureAlign::oRotateOfRMZ;
MObject structureAlign::oRotateOfRM;

	MObject structureAlign::oRotateOfInvRMX;
	MObject structureAlign::oRotateOfInvRMY;
	MObject structureAlign::oRotateOfInvRMZ;
MObject structureAlign::oRotateOfInvRM;

	MObject structureAlign::oTranslateAfterRMX;
	MObject structureAlign::oTranslateAfterRMY;
	MObject structureAlign::oTranslateAfterRMZ;
MObject structureAlign::oTranslateAfterRM;

	MObject structureAlign::oTranslateAfterAxisX;
	MObject structureAlign::oTranslateAfterAxisY;
	MObject structureAlign::oTranslateAfterAxisZ;
MObject structureAlign::oTranslateAfterAxis;

	MObject structureAlign::oCentroidDiffX;
	MObject structureAlign::oCentroidDiffY;
	MObject structureAlign::oCentroidDiffZ;
MObject structureAlign::oCentroidDiff;

	MObject structureAlign::oRotationAxisX;
	MObject structureAlign::oRotationAxisY;
	MObject structureAlign::oRotationAxisZ;
MObject structureAlign::oRotationAxis;

	MObject structureAlign::oAxisCenterX;
	MObject structureAlign::oAxisCenterY;
	MObject structureAlign::oAxisCenterZ;
MObject structureAlign::oAxisCenter;

	MObject structureAlign::oRotParentX;
	MObject structureAlign::oRotParentZ;
MObject structureAlign::oRotParent;

MObject structureAlign::oOut;
MObject structureAlign::oSourceAfterCentroid;
MObject structureAlign::oTargetAfterCentroid;
MObject structureAlign::oInfoA;
MObject structureAlign::oInfoB;
MObject structureAlign::oShiftAlongAxis;
MObject structureAlign::oDistanceAfterAxis;

static void sciAddAttribute( const MObject attr[], const unsigned size )
{
	bool oneFailed = false;

	std::vector<std::string> res;

	for( unsigned i=0; i<size; i++ )
	{
		if( MPxNode::addAttribute(attr[i])!=MS::kSuccess )
		{
			MFnAttribute attrFn(attr[i]);
			cout << " ERROR : failed addAttribute -> attribute : '" <<
				attrFn.name() << "'" << endl;
			MPxNode::addAttribute(attr[i]);
			oneFailed = true;
			{res.push_back("FAIL");}
		}
		else
		{res.push_back("success");}
	}

	if( oneFailed )
	{
		cout << " \nlist addAttribute:" << endl;

		for( unsigned i=0; i<size; i++ )
		{
			MFnAttribute attrFn(attr[i]);
			cout << " " << std::to_string(i) << " : '" <<
				attrFn.name() << "' : " <<  res[i] << endl;
		}

		cout << endl;
	}
}

static void sciAttributeAffects( const MObject attrI[],
								 const MObject attrO[],
								 const unsigned sizeI,
								 const unsigned sizeO )
{
	bool allAreFine = true;

	for( unsigned i=0; i<sizeI; i++ )
	{
		std::vector<std::string> res;
		bool localIsFine = true;

		for( unsigned k=0; k<sizeO; k++ )
		{
			if( MPxNode::attributeAffects(attrI[i], attrO[k])!=MS::kSuccess )
			{
				MPxNode::attributeAffects(attrI[i], attrO[k]);
				MFnAttribute attrFn1(attrI[i]);
				MFnAttribute attrFn2(attrO[k]);
				cout << " ERROR : failed attributeAffects -> attributes : '" <<
						attrFn1.name() << "' to affect '" << attrFn2.name() <<
					"' at index : '" << std::to_string(i) << " " << std::to_string(k) << "'" << endl;

				allAreFine = false;
				localIsFine = false;
				res.push_back( " FAIL" );
			}
			else
			{res.push_back( " success" );}
		}

		if( localIsFine==false )
		{
			MFnAttribute attrFn1(attrI[i]);
			cout << " " << std::to_string(i) << " : " << attrFn1.name() << " to affect:" << endl;

			for( unsigned k=0; k<sizeO; k++ )
			{
				MFnAttribute attrFn2(attrO[k]);
				cout << " " << std::to_string(k) << " : " << attrFn2.name() <<  " " << res[k] << endl;
			}
		}

	}

	if( allAreFine==false )
	{
		cout << " all attributeAffects : inputs : '" << std::to_string(sizeI) <<
			"', outputs : '" << std::to_string(sizeO) <<"'" << endl;

		for( unsigned i=0; i<sizeI; i++ )
		{
			for( unsigned k=0; k<sizeO; k++ )
			{
				if( MPxNode::attributeAffects(attrI[i], attrO[k])!=MS::kSuccess )
				{
					MFnAttribute attrFn1(attrI[i]);
					MFnAttribute attrFn2(attrO[k]);
					cout << std::to_string(i) << " " << std::to_string(k) << " : " <<
					attrFn1.name() << "' -> '" << attrFn2.name() << "'" << endl;
				}
			}
		}
	}
}

//____________________________________________________________________________
//
//
MStatus structureAlign::initialize()
{
	MStatus stat;

	MFnNurbsCurveData		nurbsCurveDataFn;
	MFnNurbsSurfaceData		nurbsSurfaceDataFn;
	MFnMeshData				meshDataFn;

	MFnTypedAttribute	tAttr;
	MFnNumericAttribute	nAttr;
	MFnGenericAttribute	gAttr;
	MFnEnumAttribute	eAttr;
	MFnUnitAttribute	uAttr;
	MFnMatrixAttribute mAttr;

	iRotateOrder = eAttr.create( "rotateOrder", "ro", ROTATE_ORDER_XYZ );
	eAttr.addField( "xyz", ROTATE_ORDER_XYZ );
	eAttr.addField( "yzx", ROTATE_ORDER_YZX );
	eAttr.addField( "zxy", ROTATE_ORDER_ZXY );
	eAttr.addField( "xzy", ROTATE_ORDER_XZY );
	eAttr.addField( "yxz", ROTATE_ORDER_YXZ );
	eAttr.addField( "zyx", ROTATE_ORDER_ZYX );
	MAKE_IO_ATTR( eAttr );

	iSource = gAttr.create( "source", "sour", &stat );
	gAttr.addDataAccept( MFnData::kMesh );
	gAttr.addDataAccept( MFnData::kNurbsCurve );
	gAttr.addDataAccept( MFnData::kNurbsSurface );
	gAttr.addDataAccept( MFnData::kPluginGeometry );
	gAttr.addDataAccept( MFnData::kPointArray );
	gAttr.addDataAccept( MFnData::kVectorArray );
	MAKE_IO_ATTR( gAttr );

	iTarget = gAttr.create( "target", "targ", &stat );
	gAttr.addDataAccept( MFnData::kMesh );
	gAttr.addDataAccept( MFnData::kNurbsCurve );
	gAttr.addDataAccept( MFnData::kNurbsSurface );
	gAttr.addDataAccept( MFnData::kPluginGeometry );
	gAttr.addDataAccept( MFnData::kPointArray );
	gAttr.addDataAccept( MFnData::kVectorArray );
	MAKE_IO_ATTR( gAttr );

	iCentroidsToZero = nAttr.create( "centroidsToZero", "ctoze", MAKE_BOOLEANDEF_IO_ATTR( true );
	iPrintToOutput = nAttr.create( "printToOutput", "pttou", MAKE_BOOLEANDEF_IO_ATTR( true );

	iCalcType = eAttr.create(
		"calcType", "caty", MAKE_ENUMDEF_2_IO_ATTR( "simpleSVD", "TMalignc", 0 );
	iStructureType = eAttr.create(
		"structureType", "strty", MAKE_ENUMDEF_2_IO_ATTR( "protein", "other", 0 );
	iAxisCenterType = eAttr.create(
		"axisCenterType", "axlot", MAKE_ENUMDEF_4_IO_ATTR( "betweenCentroids", "offsetShiftAlongAxis", "smallestOffset", "custom", 1 );

		iCustomAxisCenterX = nAttr.create( "axisLocationX", "axlox", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		iCustomAxisCenterY = nAttr.create( "axisLocationY", "axloy", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		iCustomAxisCenterZ = nAttr.create( "axisLocationZ", "axloz", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
	iCustomAxisCenter = nAttr.create( "customAxisCenter", "cuac",	iCustomAxisCenterX,
																	iCustomAxisCenterY,
																	iCustomAxisCenterZ ); IN_N;

		oCentroidSourceX = nAttr.create( "centroidSourceX", "ocsx", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oCentroidSourceY = nAttr.create( "centroidSourceY", "ocsy", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oCentroidSourceZ = nAttr.create( "centroidSourceZ", "ocsz", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
	oCentroidSource = nAttr.create( "oCentroidSource", "ocs", oCentroidSourceX,
									oCentroidSourceY,
									oCentroidSourceZ ); OUT_N;

		oCentroidTargetX = nAttr.create( "centroidTargetX", "octx", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oCentroidTargetY = nAttr.create( "centroidTargetY", "octy", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oCentroidTargetZ = nAttr.create( "centroidTargetZ", "octz", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
	oCentroidTarget = nAttr.create( "oCentroidTarget", "oct",	oCentroidTargetX,
																oCentroidTargetY,
																oCentroidTargetZ );OUT_N;

		oCentroidDiffX = nAttr.create( "oCentroidDiffX", "ocdix", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oCentroidDiffY = nAttr.create( "oCentroidDiffY", "ocdiy", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oCentroidDiffZ = nAttr.create( "oCentroidDiffZ", "ocdiz", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
	oCentroidDiff = nAttr.create( "oCentroidDiff", "ocdif",	oCentroidDiffX,
															oCentroidDiffY,
															oCentroidDiffZ ); OUT_N;

	oAngle = uAttr.create( "oAngle", "oang", MAKE_ANGLEDEG_O_ATTR;
	oMatrix = mAttr.create( "oMatrix", "omat", MFnMatrixAttribute::kDouble, &stat ); mAttr.setStorable( false );
	oInfoA = tAttr.create( "oInfoA", "oina", MAKE_TYPED_O_ATTR( stringK );
	oInfoB = tAttr.create( "oInfoB", "oinb", MAKE_TYPED_O_ATTR( stringK );

		oRotateOfRMX = uAttr.create( "oRotateOfRMX", "ororx", MFnUnitAttribute::kAngle, 0.0 ); nAttr.setStorable( false );
		oRotateOfRMY = uAttr.create( "oRotateOfRMY", "orory", MFnUnitAttribute::kAngle, 0.0 ); nAttr.setStorable( false );
		oRotateOfRMZ = uAttr.create( "oRotateOfRMZ", "ororz", MFnUnitAttribute::kAngle, 0.0 ); nAttr.setStorable( false );
	oRotateOfRM = nAttr.create( "oRotateOfRM", "oror",	oRotateOfRMX,
														oRotateOfRMY,
														oRotateOfRMZ ); OUT_N;

		oRotateOfInvRMX = uAttr.create( "oRotateOfInvRMX", "orirx", MFnUnitAttribute::kAngle, 0.0 ); nAttr.setStorable( false );
		oRotateOfInvRMY = uAttr.create( "oRotateOfInvRMY", "oriry", MFnUnitAttribute::kAngle, 0.0 ); nAttr.setStorable( false );
		oRotateOfInvRMZ = uAttr.create( "oRotateOfInvRMZ", "orirz", MFnUnitAttribute::kAngle, 0.0 ); nAttr.setStorable( false );
	oRotateOfInvRM = nAttr.create( "oRotateOfInvRM", "oroi",	oRotateOfInvRMX,
																oRotateOfInvRMY,
																oRotateOfInvRMZ ); OUT_N;

		oTranslateAfterRMX = nAttr.create( "oTranslateAfterRMX", "otrmx", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oTranslateAfterRMY = nAttr.create( "oTranslateAfterRMY", "otrmy", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oTranslateAfterRMZ = nAttr.create( "oTranslateAfterRMZ", "otrmz", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
	oTranslateAfterRM = nAttr.create( "oTranslateAfterRM", "otrm",	oTranslateAfterRMX,
																	oTranslateAfterRMY,
																	oTranslateAfterRMZ ); OUT_N;

		oTranslateAfterAxisX = nAttr.create( "oTranslateAfterAxisX", "otrxx", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oTranslateAfterAxisY = nAttr.create( "oTranslateAfterAxisY", "otrxy", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oTranslateAfterAxisZ = nAttr.create( "oTranslateAfterAxisZ", "otrxz", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
	oTranslateAfterAxis = nAttr.create( "oTranslateAfterAxis", "otrx", oTranslateAfterAxisX,
																	  oTranslateAfterAxisY,
																	  oTranslateAfterAxisZ ); OUT_N;

		oRotationAxisX = nAttr.create( "oRotationAxisX", "orotax", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oRotationAxisY = nAttr.create( "oRotationAxisY", "orotay", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oRotationAxisZ = nAttr.create( "oRotationAxisZ", "orotaz", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
	oRotationAxis = nAttr.create( "oRotationAxis", "orota", oRotationAxisX,
															oRotationAxisY,
															oRotationAxisZ ); OUT_N;

		oAxisCenterX = nAttr.create( "oAxisCenterX", "oaxcx", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oAxisCenterY = nAttr.create( "oAxisCenterY", "oaxcy", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
		oAxisCenterZ = nAttr.create( "oAxisCenterZ", "oaxcz", MFnNumericData::kDouble, 0.0 ); nAttr.setStorable( false );
	oAxisCenter = nAttr.create( "oAxisCenter", "oaxc",	oAxisCenterX,
														oAxisCenterY,
														oAxisCenterZ );OUT_N;

		oRotParentX = uAttr.create( "oRotParentX", "orotpx", MFnUnitAttribute::kAngle, 0.0 ); OUT_U;
		oRotParentZ = uAttr.create( "oRotParentZ", "orotpz", MFnUnitAttribute::kAngle, 0.0 ); OUT_U;
	oRotParent = nAttr.create( "oRotParent", "orotp",	oRotParentX,
														oRotParentZ ); OUT_N;

	oShiftAlongAxis = nAttr.create( "oShiftAlongAxis", "osaax", MAKE_DOUBLEDEF_O_ATTR( 0.0 );
	oDistanceAfterAxis = nAttr.create( "oDistanceAfterAxis", "odiaa", MAKE_DOUBLEDEF_O_ATTR( 0.0 );

	oOut = gAttr.create( "oOut", "oout", &stat );
	gAttr.addDataAccept( MFnData::kMesh );
	gAttr.addDataAccept( MFnData::kNurbsCurve );
	gAttr.addDataAccept( MFnData::kNurbsSurface );
	gAttr.addDataAccept( MFnData::kPluginGeometry );
	gAttr.addDataAccept( MFnData::kPointArray );
	gAttr.addDataAccept( MFnData::kVectorArray );
	MAKE_O_ATTR( gAttr );

	oSourceAfterCentroid = gAttr.create( "oSourceAfterCentroid", "osace", &stat );
	gAttr.addDataAccept( MFnData::kMesh );
	gAttr.addDataAccept( MFnData::kNurbsCurve );
	gAttr.addDataAccept( MFnData::kNurbsSurface );
	gAttr.addDataAccept( MFnData::kPluginGeometry );
	gAttr.addDataAccept( MFnData::kPointArray );
	gAttr.addDataAccept( MFnData::kVectorArray );
	MAKE_O_ATTR( gAttr );

	oTargetAfterCentroid = gAttr.create( "oTargetAfterCentroid", "otace", &stat );
	gAttr.addDataAccept( MFnData::kMesh );
	gAttr.addDataAccept( MFnData::kNurbsCurve );
	gAttr.addDataAccept( MFnData::kNurbsSurface );
	gAttr.addDataAccept( MFnData::kPluginGeometry );
	gAttr.addDataAccept( MFnData::kPointArray );
	gAttr.addDataAccept( MFnData::kVectorArray );
	MAKE_O_ATTR( gAttr );

	// addAttribute
	//
	const MObject attrs[] =
	{
		iSource, iTarget, iRotateOrder, iCentroidsToZero, iPrintToOutput,
		iCalcType, iStructureType, iAxisCenterType, iCustomAxisCenter,
		oCentroidSource, oCentroidTarget, oCentroidDiff, oRotateOfRM,
		oRotateOfInvRM, oTranslateAfterRM, oTranslateAfterAxis, oAngle,
		oRotationAxis, oAxisCenter, oRotParent, oOut, oSourceAfterCentroid,
		oTargetAfterCentroid, oShiftAlongAxis, oDistanceAfterAxis, oMatrix,
		oInfoA, oInfoB, };

	sciAddAttribute( attrs, sizeof( attrs ) / sizeof( attrs[0] ) );

	// attributeAffects
	//
	attributeAffects( iRotateOrder, oRotateOfRM );
	attributeAffects( iRotateOrder, oRotateOfInvRM );

	const MObject arrayMI[] =
	{
		iSource, iTarget, iCalcType, iStructureType,
		iAxisCenterType, iCustomAxisCenterX, iCustomAxisCenterY,
		iCustomAxisCenterZ, iCustomAxisCenter
	};

	const MObject arrayMO[] =
	{
		oRotateOfRM, oRotateOfRMX, oRotateOfRMY, oRotateOfRMZ,
		oRotateOfInvRM, oRotateOfInvRMX, oRotateOfInvRMY, oRotateOfInvRMZ,
		oTranslateAfterRMX, oTranslateAfterRMY, oTranslateAfterRMZ, oTranslateAfterRM,
		oTranslateAfterAxisX, oTranslateAfterAxisY, oTranslateAfterAxisZ, oTranslateAfterAxis,
		oRotationAxisX, oRotationAxisY,oRotationAxisZ, oRotationAxis,
		oAxisCenterX, oAxisCenterY, oAxisCenterZ, oAxisCenter,
		oCentroidSourceX, oCentroidSourceY, oCentroidSourceZ,  oCentroidSource,
		oCentroidTargetX, oCentroidTargetY, oCentroidTargetZ, oCentroidTarget,
		oCentroidDiffX, oCentroidDiffY, oCentroidDiffZ, oCentroidDiff,
		oRotParentX, oRotParentZ, oRotParent,
		oAngle, oMatrix, oInfoA, oInfoB, oOut, oShiftAlongAxis, oDistanceAfterAxis
	};

	sciAttributeAffects(	arrayMI,
							arrayMO,
							sizeof(arrayMI) / sizeof(arrayMI[0]),
							sizeof(arrayMO) / sizeof(arrayMO[0]) );



	return MS::kSuccess;
}

//____________________________________________________________________________
//
//