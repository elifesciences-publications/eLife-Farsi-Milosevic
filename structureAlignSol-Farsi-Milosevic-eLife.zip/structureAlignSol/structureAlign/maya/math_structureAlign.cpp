//

#include "structureAlign.h"

#include <maya/MPlugArray.h>
#include <maya/MDGModifier.h>
#include <maya/MFloatMatrix.h>
#include <maya/MMatrix.h>
#include <maya/MVectorArray.h>
#include <maya/MTransformationMatrix.h>

//______________________________________________________________________
//
//
svdMatrix<float> structureAlign::eulerToMayaMat( const MVector & euler )
{
	float _a00, _a01, _a02, _a03;
	float _a10, _a11, _a12, _a13;
	float _a20, _a21, _a22, _a23;
	float _a30, _a31, _a32, _a33;

	float _b00, _b01, _b02, _b03;
	float _b10, _b11, _b12, _b13;
	float _b20, _b21, _b22, _b23;
	float _b30, _b31, _b32, _b33;

	float _t00, _t01, _t02, _t03;
	float _t10, _t11, _t12, _t13;
	float _t20, _t21, _t22, _t23;
	float _t30, _t31, _t32, _t33;

	float _c00, _c01, _c02, _c03;
	float _c10, _c11, _c12, _c13;
	float _c20, _c21, _c22, _c23;
	float _c30, _c31, _c32, _c33;

	float _F00, _F01, _F02, _F03;
	float _F10, _F11, _F12, _F13;
	float _F20, _F21, _F22, _F23;
	float _F30, _F31, _F32, _F33;

	float sinX = sin( euler.x );
	float cosX = cos( euler.x );

	float sinY = sin( euler.y );
	float cosY = cos( euler.y );

	float sinZ = sin( euler.z );
	float cosZ = cos( euler.z );

	_a00 = 1; _a01 = 0;     _a02 = 0;    _a03 = 0;
	_a10 = 0; _a11 = cosX;  _a12 = sinX; _a13 = 0;
	_a20 = 0; _a21 = -sinX; _a22 = cosX; _a23 = 0;
	_a30 = 0; _a31 = 0;     _a32 = 0;    _a33 = 1;


	_b00 = cosY; _b01 = 0; _b02 = -sinY; _b03 = 0;
	_b10 = 0;    _b11 = 1; _b12 = 0;     _b13 = 0;
	_b20 = sinY; _b21 = 0; _b22 = cosY;  _b23 = 0;
	_b30 = 0;    _b31 = 0; _b32 = 0;     _b33 = 1;


	_c00 = cosZ;  _c01 = sinZ; _c02 = 0; _c03 = 0;
	_c10 = -sinZ; _c11 = cosZ; _c12 = 0; _c13 = 0;
	_c20 = 0;     _c21 = 0;    _c22 = 1; _c23 = 0;
	_c30 = 0;     _c31 = 0;    _c32 = 0; _c33 = 1;


	_t00 = _a00*_b00 + _a01*_b10 + _a02*_b20 + _a03*_b30;
	_t01 = _a00*_b01 + _a01*_b11 + _a02*_b21 + _a03*_b31;
	_t02 = _a00*_b02 + _a01*_b12 + _a02*_b22 + _a03*_b32;
	_t03 = _a00*_b03 + _a01*_b13 + _a02*_b23 + _a03*_b33;
	_t10 = _a10*_b00 + _a11*_b10 + _a12*_b20 + _a13*_b30;
	_t11 = _a10*_b01 + _a11*_b11 + _a12*_b21 + _a13*_b31;
	_t12 = _a10*_b02 + _a11*_b12 + _a12*_b22 + _a13*_b32;
	_t13 = _a10*_b03 + _a11*_b13 + _a12*_b23 + _a13*_b33;
	_t20 = _a20*_b00 + _a21*_b10 + _a22*_b20 + _a23*_b30;
	_t21 = _a20*_b01 + _a21*_b11 + _a22*_b21 + _a23*_b31;
	_t22 = _a20*_b02 + _a21*_b12 + _a22*_b22 + _a23*_b32;
	_t23 = _a20*_b03 + _a21*_b13 + _a22*_b23 + _a23*_b33;
	_t30 = _a30*_b00 + _a31*_b10 + _a32*_b20 + _a33*_b30;
	_t31 = _a30*_b01 + _a31*_b11 + _a32*_b21 + _a33*_b31;
	_t32 = _a30*_b02 + _a31*_b12 + _a32*_b22 + _a33*_b32;
	_t33 = _a30*_b03 + _a31*_b13 + _a32*_b23 + _a33*_b33;


	svdMatrix<float> mat( 3, 3 );

	mat[0][0] =	_t00*_c00 + _t01*_c10 + _t02*_c20 + _t03*_c30;
	mat[0][1] =	_t00*_c01 + _t01*_c11 + _t02*_c21 + _t03*_c31;
	mat[0][2] =	_t00*_c02 + _t01*_c12 + _t02*_c22 + _t03*_c32;


	mat[1][0] =	_t10*_c00 + _t11*_c10 + _t12*_c20 + _t13*_c30;
	mat[1][1] =	_t10*_c01 + _t11*_c11 + _t12*_c21 + _t13*_c31;
	mat[1][2] =	_t10*_c02 + _t11*_c12 + _t12*_c22 + _t13*_c32;


	mat[2][0] =	_t20*_c00 + _t21*_c10 + _t22*_c20 + _t23*_c30;
	mat[2][1] =	_t20*_c01 + _t21*_c11 + _t22*_c21 + _t23*_c31;
	mat[2][2] =	_t20*_c02 + _t21*_c12 + _t22*_c22 + _t23*_c32;

	return mat;
}

//________________________________________________________________________________________
//
//
void structureAlign::projectPointOnLine( const svdVector<float>	& pointToProject,
										 const svdVector<float>	& lineStart,
										 const svdVector<float>	& lineEnd,
										 svdVector<float>		& projectedPoint )
{
	svdVector<float> UU = (lineEnd-lineStart).Normalised();
	projectedPoint = lineStart +  UU * (UU*(pointToProject - lineStart));
}

//___________________________________________________________________________________
//
//
bool structureAlign::rotateYWithAxisAngle( const MFloatVector	& target,
										   MFloatVector			& rotValues )
{
	// Get the gegenkathete.
	//
	MFloatVector y( 0.0f, 1.0f, 0.0f );
	MFloatVector diffVec = target - y;

	// Get the angle.
	//
	float angleRadian = y.angle( target );

	// Get the axis (normal).
	//
	diffVec.normalize();
	MFloatVector axis = y^diffVec;
	axis.normalize();

	// Construct the matrix.
	//
	float c = cosf( angleRadian );
	float l_c = 1 - c;

	float s = sinf( angleRadian );

	double f[4][4] =
	{
		{ axis[0]*axis[0] + (1.0f - axis[0]*axis[0])*c,
		axis[0]*axis[1]*l_c + axis[2]*s,
		axis[0]*axis[2]*l_c - axis[1]*s,
		0.0f },
		{ axis[0]*axis[1]*l_c - axis[2]*s,
		axis[1]*axis[1] + (1.0f - axis[1]*axis[1])*c,
		axis[1]*axis[2]*l_c + axis[0]*s,
		0.0f },
		{ axis[0]*axis[2]*l_c + axis[1]*s,
		axis[1]*axis[2]*l_c - axis[0]*s,
		axis[2]*axis[2] + (1.0f - axis[2]*axis[2])*c,
		0.0f },
		{ 0.0f,	0.0f, 0.0f, 1.0f }
	};

	MFloatMatrix mat( f );


	// Extract the rotation values.
	//
	toHeadPitchRoll( rotValues.x,
					 rotValues.y,
					 rotValues.z,
					 mat );
	return true;

}

//_____________________________________________________________________________
//
//
MMatrix structureAlign::matrixFromAxisAngle( const MFloatVector & axis,
											 float				  angleRadian )
{
	float c = cosf( angleRadian );
	float l_c = 1 - c;

	float s = sinf( angleRadian );

	MMatrix mtx;

	// ROW MAJOR
	//
	mtx[0][0] = axis[0]*axis[0]      + (1 - axis[0]*axis[0])*c;
	mtx[0][1] = axis[0]*axis[1]*l_c  + axis[2]*s;
	mtx[0][2] = axis[0]*axis[2]*l_c  - axis[1]*s;

	mtx[1][0] = axis[0]*axis[1]*l_c  - axis[2]*s;
	mtx[1][1] = axis[1]*axis[1] + (1 - axis[1]*axis[1])*c;
	mtx[1][2] = axis[1]*axis[2]*l_c  + axis[0]*s;

	mtx[2][0] = axis[0]*axis[2]*l_c  + axis[1]*s;
	mtx[2][1] = axis[1]*axis[2]*l_c  - axis[0]*s;
	mtx[2][2] = axis[2]*axis[2]      + (1 - axis[2]*axis[2])*c;

	return mtx;
}

//____________________________________________________________________________
//
//
static double sciRadToDeg( double radians )
{ return radians * (180.0 / sciPI); }

//____________________________________________________________________________
//
//
MStatus	structureAlign::toHeadPitchRoll( float					& pitchDegreesX,
										 float					& headDegreesY,
										 float					& rollDegreesZ,
										 const svdMatrix<float>	& mtx )
{
	float sy = sqrt( mtx[0][0]*mtx[0][0] + mtx[1][0]*mtx[1][0] );

	bool singular = sy<1e-6;

	if( !singular )
	{
		pitchDegreesX = atan2f( mtx[2][1], mtx[2][2] );
		headDegreesY  = atan2f( -mtx[2][0], sy );
		rollDegreesZ  = atan2f( mtx[1][0], mtx[0][0] );
	}
	else
	{
		pitchDegreesX = atan2f( -mtx[1][2], mtx[1][1] );
		headDegreesY  = atan2f( -mtx[2][0], sy );
		rollDegreesZ  = 0;
	}

	headDegreesY  = sciRadToDeg( headDegreesY );
	pitchDegreesX = sciRadToDeg( pitchDegreesX );
	rollDegreesZ  = sciRadToDeg( rollDegreesZ );

	return MS::kSuccess;
}

//____________________________________________________________________________
//
//
MStatus	structureAlign::toHeadPitchRoll( float					& pitchDegreesX,
										 float					& headDegreesY,
										 float					& rollDegreesZ,
										 const MFloatMatrix		& mtx )
{
	float thetaX = asinf( mtx[1][2] );
	float thetaY = 0.0f;
	float thetaZ = 0.0f;

	if( thetaX<sciHALF_PI )
	{
		if( thetaX>-sciHALF_PI )
		{
			thetaZ = atan2f( -mtx[1][0], mtx[1][1] );
			thetaY = atan2f( -mtx[0][2], mtx[2][2] );
		}

		// Not a unique solution.
		//
		else
		{
			thetaZ = -atan2f( mtx[2][0], mtx[0][0] );
			thetaY = 0.0f;
		}
	}

	// Not a unique solution.
	//
	else
	{
		thetaZ = atan2f( mtx[2][0], mtx[0][0] );
		thetaY = 0.0f;
	}

	headDegreesY  = sciRadToDeg( thetaY );
	pitchDegreesX = sciRadToDeg( thetaX );
	rollDegreesZ  = sciRadToDeg( thetaZ );

	return MS::kSuccess;
}

//_____________________________________________________________________________
//
//
bool structureAlign::getAxisAngle( svdMatrix<float>	& mtx,
								   MVector			& axis,
								   float			& angle )
{
	// Margin to allow for rounding errors.
	//
	float epsilon = 0.01f;

	// Margin to distinguish between 0 and 180 degrees.
	//
	float epsilon2 = 0.1f;


	if( (abs( mtx[1][0] - mtx[0][1] )<epsilon) &&
		(abs( mtx[2][0] - mtx[0][2] )<epsilon) &&
		(abs( mtx[2][1] - mtx[1][2] )<epsilon) )
	{
		// Singularity found.
		// first check for identity matrix which must have +1 for all terms
		// in leading diagonaland zero in other terms.
		//
		if( (abs( mtx[1][0]+mtx[0][1] )<epsilon2) &&
			(abs( mtx[2][0]+mtx[0][2] )<epsilon2) &&
			(abs( mtx[2][1]+mtx[1][2] )<epsilon2) &&
			(abs( mtx[0][0]+mtx[1][1]+mtx[2][2] - 3 )<epsilon2) )
		{
			// This singularity is identity matrix so angle = 0.
			// zero angle, arbitrary axis.
			//
			axis.x = 1.0;
			axis.y = 0.0;
			axis.z = 0.0;

			angle = 0.0;

			return true;
		}

		//--------------------------------------------------------------------------------

		// Otherwise this singularity is angle = 180.
		//
		float xx = (mtx[0][0]+1)/2;
		float yy = (mtx[1][1]+1)/2;
		float zz = (mtx[2][2]+1)/2;
		float xy = (mtx[1][0]+mtx[0][1])/4;
		float xz = (mtx[2][0]+mtx[0][2])/4;
		float yz = (mtx[2][1]+mtx[1][2])/4;

		// mat[0][0] is the largest diagonal term
		//
		if( xx>yy && xx>zz )
		{
			if( xx<epsilon )
			{
				axis.x = 0;
				axis.y = 0.7071;
				axis.z = 0.7071;
			}
			else
			{
				axis.x = sqrt( xx );
				axis.y = xy/axis.x;
				axis.z = xz/axis.x;
			}
		}

		// mat[1][1] is the largest diagonal term
		//
		else if( yy>zz )
		{
			if( yy<epsilon )
			{
				axis.x = 0.7071;
				axis.y = 0;
				axis.z = 0.7071;
			}
			else
			{
				axis.y = sqrt( yy );
				axis.x = xy/axis.y;
				axis.z = yz/axis.y;
			}
		}

		// mat[2][2] is the largest diagonal term so base result on this
		//
		else
		{
			if( zz<epsilon )
			{
				axis.x = 0.7071;
				axis.y = 0.7071;
				axis.z = 0.0;
			}
			else
			{
				axis.z = sqrt( zz );
				axis.x = xz/axis.z;
				axis.y = yz/axis.z;
			}
		}

		// return 180 deg rotation
		//
		angle = 3.14159265f;

		return true;

		//--------------------------------------------------------------------------------

	}

	// As we have reached here there are no
	// singularities so we can handle normally.
	//
	// Used to normalize.
	//
	double temp = sqrt( pow( (mtx[1][2] - mtx[2][1]), 2 ) +
						pow( (mtx[2][0] - mtx[0][2]), 2 ) +
						pow( (mtx[0][1] - mtx[1][0]), 2 ) );

	// Prevent divide by zero, should not happen
	// if matrix is orthogonal and should be
	// caught by singularity test above,
	// but its left in just in case.
	//
	if( abs( temp )<0.001 )
	{
		cout << " alert : abs(temp)<0.001" << endl;
		temp = 1.0;
	}

	axis.x = (mtx[1][2] - mtx[2][1]) / temp;
	axis.y = (mtx[2][0] - mtx[0][2]) / temp;
	axis.z = (mtx[0][1] - mtx[1][0]) / temp;

	angle = acos( (mtx[0][0] + mtx[1][1] + mtx[2][2] - 1) / 2 );

	return true;
}

//___________________________________________________________________________________
//
//