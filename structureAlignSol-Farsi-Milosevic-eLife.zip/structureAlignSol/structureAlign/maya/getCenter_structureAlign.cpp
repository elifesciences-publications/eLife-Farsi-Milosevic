//

#include "structureAlign.h"
#include <maya/MVectorArray.h>
#include <maya/MMatrix.h>

//_____________________________________________________________________________
//
//
bool structureAlign::getBetweenCentroidsCenter( const svdVector<float>	& sourceCentroidPoint,
												const svdVector<float>	& targetCentroidPoint,
												const float				  angleInRad,
												const MVector			& axis,
												const svdMatrix<float>	& rotMatSVD,
												const svdVector<float>	& transAfterRM,
												MVectorArray			& sourceAsMVector,
												MVectorArray			& targetAsMVector,
												MVector					& center,
												MVector					& transAfterAxis )
{
	svdVector<float> sToT = (targetCentroidPoint - sourceCentroidPoint).Normalised();
	float len = sourceCentroidPoint.DistanceFrom( targetCentroidPoint );
	svdVector<float>middlePoint = sourceCentroidPoint + sToT*0.5*len;
	center.x = middlePoint[0];
	center.y = middlePoint[1];
	center.z = middlePoint[2];

	transAfterAxis = getTranslateAfterAxis( angleInRad,
											center,
											axis,
											rotMatSVD,
											transAfterRM,
											sourceAsMVector,
											targetAsMVector );

	return true;
}

//_____________________________________________________________________________
//
//
bool structureAlign::getOffsetShiftAlongAxisCenter( const svdVector<float>	& transAfter,
													const svdMatrix<float>	& rotMatSVD,
													const MVector			& axis,
													const float				  angleInRad,
													MVectorArray			& sourceAsMVector,
													MVectorArray			& targetAsMVector,
													MVector					& center,
													double					& shiftAlongAxis,
													MVector					& transAfterAxis )
{
	MVector transAfterRM( transAfter[0], transAfter[1], transAfter[2] );
	MVector normalAxisTarget = axis^transAfterRM;
	MVector dirAxisTarget = axis^normalAxisTarget;

	// Half angle in radians
	//
	float angleHalf = 0.5*angleInRad;

	if( sinf(angleHalf)!=0.0f )
	{
		float ct2 = cosf(angleHalf) / sinf(angleHalf); // cotangens(angleHalf) -> A/G
		center = 0.5*(ct2*normalAxisTarget - dirAxisTarget);
		shiftAlongAxis = axis*transAfterRM;

		transAfterAxis = getTranslateAfterAxis( angleInRad,
												center,
												axis,
												rotMatSVD,
												transAfter,
												sourceAsMVector,
												targetAsMVector );
	}

	return true;
}

//_____________________________________________________________________________
//
//
bool structureAlign::getSmallestOffsetCenter( const svdMatrix<float>	& rotMat,
											  const svdVector<float>	& transAfterRM,
											  const MVectorArray		& sourceAsMVector,
											  const MVectorArray		& targetAsMVector,
											  const MPoint				& sourcePoint0,
											  const MVector				& axis,
											  const float				  angle,
											  MVector					& center,
											  MVector					& transAfterAxis )
{
	svdVector<float> svdSV( 3 );
	svdSV[0] = sourceAsMVector[0].x;
	svdSV[1] = sourceAsMVector[0].y;
	svdSV[2] = sourceAsMVector[0].z;
	svdVector<float> svdTV = rotMat*svdSV;
	svdTV += transAfterRM;
	MPoint target0FromSourceRotWithRM( svdTV[0], svdTV[1], svdTV[2] );

	MVector idealTargetInXYPlane;

	getCenterOfRotation2( sourcePoint0,
						  target0FromSourceRotWithRM,
						  axis,
						  angle,
						  center,
						  idealTargetInXYPlane );

	transAfterAxis.x = targetAsMVector[0].x - idealTargetInXYPlane.x;
	transAfterAxis.y = targetAsMVector[0].y - idealTargetInXYPlane.y;
	transAfterAxis.z = targetAsMVector[0].z - idealTargetInXYPlane.z;
	return true;
}

//_____________________________________________________________________________
//
//
MVector structureAlign::getTranslateAfterAxis( const float				  angle,
											   const MVector			& center,
											   const MVector			& axis,
											   const svdMatrix<float>	& rotMat,
											   const svdVector<float>	& transAfterRM,
											   MVectorArray				  sourceAsMVector,
											   MVectorArray				  targetAsMVector )
{

	// Transform the first source point to its target point location for later use.
	//
	svdVector<float> svdSV( 3 );
	svdSV[0] = sourceAsMVector[0].x;
	svdSV[1] = sourceAsMVector[0].y;
	svdSV[2] = sourceAsMVector[0].z;
	svdVector<float> svdTV = rotMat*svdSV;
	svdTV += transAfterRM;

	// Put back the axis to world zero.
	// Do the same for the source data.
	//
	sourceAsMVector[0] -= center;

	// Create the rotation matrix again from axis angle.
	//
	MMatrix newRotMat;
	MTransformationMatrix matTM( newRotMat );

	matTM.setToRotationAxis( axis, (double( angle )) );
	newRotMat = matTM.asMatrix();

	// Rotate the source data.
	//
	sourceAsMVector[0] = sourceAsMVector[0]*newRotMat;

	// Reapply the translate data.
	//
	sourceAsMVector[0] += center;

	float diffX = svdTV[0] - (float)sourceAsMVector[0].x;
	float diffY = svdTV[1] - (float)sourceAsMVector[0].y;
	float diffZ = svdTV[2] - (float)sourceAsMVector[0].z;

	MVector transAfterAxis( diffX, diffY, diffZ );

	return transAfterAxis;
}

//_____________________________________________________________________________
//
//