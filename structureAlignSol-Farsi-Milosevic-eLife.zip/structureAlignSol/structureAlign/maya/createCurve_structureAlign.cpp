//

#include "structureAlign.h"

#include <maya/MFnNurbsCurveData.h>
#include <maya/MFnNurbsCurve.h>
#include <maya/MDoubleArray.h>

#include <string>
using std::string;
using std::to_string;

//____________________________________________________________________________________
//
//
MStatus structureAlign::createCurve(	unsigned	  ncvs,
										unsigned	  curveDegree,
										MPointArray	& controlVertices,
										MObject		& outAttrM,
										MDataBlock	& data )
{
	MStatus stat;

	// Number of spans
	//
	unsigned spans = ncvs - curveDegree;

	// Number of knots
	//
	unsigned nknots	= spans + 2*curveDegree - 1;

	MDoubleArray knotSequences;
	stat = knotSequences.setLength( nknots );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

	// Depending on the curve degree, set the
	// beginning of the knotSequences variable.
	//
	for( unsigned i=0; i<curveDegree; i++ )
	{ knotSequences.set( 0.0, i ); }

	// Depending on the curve degree, set the
	// middlge part of the knotSequences variable.
	//
	for( unsigned i=curveDegree; i<nknots-curveDegree; i++ )
	{knotSequences.set( (double)(i+curveDegree), i );}

	// Depending on the curve degree, set the
	// end of the knotSequences variable.
	//
	unsigned currLen = knotSequences.length();
	for( unsigned i=nknots-curveDegree; i<nknots; i++ )
	{ knotSequences.set( (double)currLen, i ); }

	// Create the curve.
	//
	MFnNurbsCurve curveFn;

	MFnNurbsCurveData dataCreator;
	MObject tmpM = dataCreator.create();

	curveFn.create( controlVertices,
					knotSequences,
					curveDegree,
					MFnNurbsCurve::kOpen,
					false,
					false,
					tmpM,
					&stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

	MDataHandle outputH = data.outputValue( outAttrM, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	outputH.set( tmpM );

	return MS::kSuccess;
}

//____________________________________________________________________________________
//
//