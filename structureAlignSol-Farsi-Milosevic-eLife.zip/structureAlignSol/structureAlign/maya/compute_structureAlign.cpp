//

#include "structureAlign.h"

#include <maya/MFnMesh.h>
#include <maya/MFnVectorArrayData.h>
#include <maya/MFnPointArrayData.h>
#include <maya/MPointArray.h>
#include <maya/MFnNurbsCurve.h>
#include <maya/MAngle.h>

#include <maya/MFloatMatrix.h>

#include "../svd/svd3.h"
#include "../TMalignc/TMalign.h"

#include <vector>
#include <string>

using sciloop::TMalignc;
using std::vector;
using std::string;
using std::to_string;

//_____________________________________________________________________________
//
//
MStatus structureAlign::compute(	const MPlug & plug,
									MDataBlock  & data )
{
	if( plug!=oMatrix						&&
		plug!=oRotateOfRM					&&
		plug.parent()!=oRotateOfRM			&&
		plug!=oTranslateAfterRM				&&
		plug.parent()!=oTranslateAfterRM	&&
		plug!=oRotationAxis					&&
		plug.parent()!=oRotationAxis		&&
		plug!=oAxisCenter					&&
		plug.parent()!=oAxisCenter )
	{return MS::kUnknownParameter;}

	if( sourceIsConnected_==false ||
		targetIsConnected_==false  )
	{
		return MS::kFailure;
	}

	MStatus stat;
	MDataHandle sourceH = data.inputValue( iSource, &stat );

	if( stat!=MS::kSuccess )
	{return MS::kFailure;}

	MDataHandle targetH = data.inputValue( iTarget, &stat );

	if( stat!=MS::kSuccess )
	{return MS::kFailure;}

	MObject sourceM = sourceH.data();
	MObject targetM = targetH.data();

	if( sourceM.apiType()!=targetM.apiType() )
	{return MS::kFailure;}

	svdMatrix<float> sourcePoints;
	svdMatrix<float> targetPoints;
	svdVector<float> sourceCentroidPoint( 3 );
	svdVector<float> targetCentroidPoint( 3 );
	MVectorArray sourceAsMVector( 1 );
	MVectorArray targetAsMVector( 1 );
	MVectorArray sourceArr( 1 );
	MVectorArray targetArr( 1 );

	MDataHandle cH =  data.inputValue( iCentroidsToZero, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	bool centroidsToZero = cH.asBool();

	if( sourceM.apiType()==MFn::Type::kVectorArrayData ||
		sourceM.apiType()==MFn::Type::kFloatVectorArrayData )
	{
		MFnVectorArrayData vecArrDataFn;
		stat = vecArrDataFn.setObject( sourceH.data() );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

		stat = vecArrDataFn.copyTo( sourceArr );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		sourceAsMVector[0] = sourceArr[0];

		stat = vecArrDataFn.setObject( targetH.data() );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

		stat = vecArrDataFn.copyTo( targetArr );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		targetAsMVector[0] = targetArr[0];
	}
	else if( sourceM.apiType()==MFn::Type::kPointArrayData )
	{
		MFnPointArrayData pointArrDataFn;
		stat = pointArrDataFn.setObject( sourceH.data() );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

		MPointArray sourceArrP;
		stat = pointArrDataFn.copyTo( sourceArrP );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

		sourceArr.setLength( sourceArrP.length() );
		for( unsigned i=0, l=sourceArrP.length(); i<l; i++ )
		{
			sourceArr[i].x = sourceArrP[i].x;
			sourceArr[i].y = sourceArrP[i].y;
			sourceArr[i].z = sourceArrP[i].z;
		}
		sourceAsMVector[0] = sourceArr[0];

		stat = pointArrDataFn.setObject( targetH.data() );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		MPointArray targetArrP;
		stat = pointArrDataFn.copyTo( targetArrP );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		targetArr.setLength( targetArrP.length() );
		for( unsigned i=0, l=targetArrP.length(); i<l; i++ )
		{
			targetArr[i].x = targetArrP[i].x;
			targetArr[i].y = targetArrP[i].y;
			targetArr[i].z = targetArrP[i].z;
		}
		targetAsMVector[0] = targetArr[0];
	}
	else if( sourceM.apiType()==MFn::Type::kNurbsCurveData )
	{

		MObject sourceM = sourceH.asNurbsCurveTransformed();
		MObject targetM = targetH.asNurbsCurveTransformed();
		MFnNurbsCurve nurbsCurveFn( sourceM, &stat );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

		unsigned numCV = nurbsCurveFn.numCVs();
		int degree = nurbsCurveFn.degree();
		MPointArray sourceArrP;
		stat = nurbsCurveFn.getCVs( sourceArrP, MSpace::kObject );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		sourceArr.setLength( sourceArrP.length() );
		for( unsigned i=0, l=sourceArrP.length(); i<l; i++ )
		{
			sourceArr[i].x = sourceArrP[i].x;
			sourceArr[i].y = sourceArrP[i].y;
			sourceArr[i].z = sourceArrP[i].z;
		}
		sourceAsMVector[0] = sourceArr[0];

		stat = nurbsCurveFn.setObject( targetM );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		MPointArray targetArrP;
		stat = nurbsCurveFn.getCVs( targetArrP, MSpace::kObject );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		targetArr.setLength( targetArrP.length() );
		for( unsigned i=0, l=targetArrP.length(); i<l; i++ )
		{
			targetArr[i].x = targetArrP[i].x;
			targetArr[i].y = targetArrP[i].y;
			targetArr[i].z = targetArrP[i].z;
		}
		targetAsMVector[0] = targetArr[0];
	}
	else if( sourceM.apiType()==MFn::Type::kMeshData )
	{
		MObject sourceM = sourceH.asMeshTransformed();
		MObject targetM = targetH.asMeshTransformed();

		MFnMesh meshFn( sourceM, &stat );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

		MPointArray sourceArrP;
		stat = meshFn.getPoints( sourceArrP, MSpace::kWorld );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		sourceArr.setLength( sourceArrP.length() );
		for( unsigned i=0, l=sourceArrP.length(); i<l; i++ )
		{
			sourceArr[i].x = sourceArrP[i].x;
			sourceArr[i].y = sourceArrP[i].y;
			sourceArr[i].z = sourceArrP[i].z;
		}
		sourceAsMVector[0] = sourceArr[0];

		stat = meshFn.setObject( targetM );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		MPointArray targetArrP;
		stat = meshFn.getPoints( targetArrP, MSpace::kWorld );
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

		targetArr.setLength( targetArrP.length() );
		for( unsigned i=0, l=targetArrP.length(); i<l; i++ )
		{
			targetArr[i].x = targetArrP[i].x;
			targetArr[i].y = targetArrP[i].y;
			targetArr[i].z = targetArrP[i].z;
		}
		targetAsMVector[0] = targetArr[0];
	}
	else
	{
		return MS::kFailure;

	}

	unsigned sourceLen = sourceArr.length();
	unsigned targetLen = targetArr.length();

	if( sourceLen<3 )
	{
		return MS::kFailure;
	}

	if( sourceLen<targetLen )
	{
		targetArr.setLength( sourceLen );
	}
	else if( sourceLen>targetLen )
	{
		sourceArr.setLength( targetLen );
	}

	MPoint sourcePoint0( sourceArr[0] );
	MPoint sourcePoint1( sourceArr[targetLen-1] );

	MVector sourceCentroid;
	MVector targetCentroid;

	if( !transformPointsToCentroidZero( sourceArr,
										targetArr,
										sourceCentroid,
										targetCentroid,
										centroidsToZero ) )
	{return MS::kFailure;}

	convertToSvdData(	sourceArr,
						targetArr,
						sourcePoints,
						targetPoints,
						sourceCentroid,
						targetCentroid,
						sourceCentroidPoint,
						targetCentroidPoint );

	short structureT = data.inputValue( iStructureType, &stat ).asShort();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

	structureType_e strucType;

	switch( structureT )
	{
	case 0: strucType = structureType_e::kProtein; break;
	case 1: strucType = structureType_e::kOther; break;
	default: strucType = structureType_e::kOther;
	}

	short calcT = data.inputValue( iCalcType, &stat ).asShort();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

	calcType_e calcType;

	switch( calcT )
	{
	case 0: calcType = calcType_e::kSimpleSVD; break;
	case 1: calcType = calcType_e::kTMalign; break;
	default: calcType = calcType_e::kSimpleSVD;
	}

	// Get the rotation and translation matrix.
	//
	svdMatrix<float> rotMatSVD( 3, 3 );
	rotMatSVD[0][0] = 1.0f; rotMatSVD[0][1] = 0.0f; rotMatSVD[0][2] = 0.0f;
	rotMatSVD[1][0] = 0.0f; rotMatSVD[1][1] = 1.0f; rotMatSVD[1][2] = 0.0f;
	rotMatSVD[2][0] = 0.0f; rotMatSVD[2][1] = 0.0f; rotMatSVD[2][2] = 1.0f;
	svdVector<float> transAfterRM( 3 );
	transAfterRM[0] = 0.0f; transAfterRM[1] = 0.0f; transAfterRM[2] = 0.0f;

	if( calcType==calcType_e::kSimpleSVD )
	{

		Kabsch( sourcePoints,
				targetPoints,
				sourceCentroidPoint,
				targetCentroidPoint,
				rotMatSVD,
				transAfterRM );
	}
	else if( calcType==calcType_e::kTMalign )
	{


		bool outputStructure = true;
		bool TMscoreAveragedByBothLength = false;
		MString TorF( "F" );
		bool scaleTMscoreByD0 = false;
		float d0scale = 1.0f;

		TMalignc align;
		bool sciSuccess = align.main_TMalignc(	outputStructure,
												TMscoreAveragedByBothLength,
												TorF,
												scaleTMscoreByD0,
												d0scale,
												sourcePoints,
												targetPoints,
												rotMatSVD,
												transAfterRM,
												(int)strucType );

		if (!sciSuccess) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
		{
			cout << " fail TMalign" << endl;
			return MS::kFailure;
		}

		// TMalignc returns potential additional translate.
		// Basically, there is no need for putting the structures
		// to world zero, but its a nice way for adjusting offset
		// interactively.
		//
		svdVector<float> transVecAdd = targetCentroidPoint - rotMatSVD*sourceCentroidPoint;
		transAfterRM += transVecAdd;
	}

	// We want the euler rotation values.
	//
	float pitchDegreesX = 0.0f;
	float headDegreesY = 0.0f;
	float rollDegreesZ = 0.0f;

	toHeadPitchRoll( pitchDegreesX,
					 headDegreesY,
					 rollDegreesZ,
					 rotMatSVD );



	// We want the Maya matrix type, which is the transpose of the svdMatrix.
	//
	svdMatrix<float> rotMatMaya = rotMatSVD.Transposed();

	MFloatMatrix mat;
	mat[0][0] = (double)rotMatMaya[0][0]; mat[0][1] = (double)rotMatMaya[0][1];	mat[0][2] = (double)rotMatMaya[0][2]; mat[0][3] = 0.0;
	mat[1][0] = (double)rotMatMaya[1][0]; mat[1][1] = (double)rotMatMaya[1][1];	mat[1][2] = (double)rotMatMaya[1][2]; mat[1][3] = 0.0;
	mat[2][0] = (double)rotMatMaya[2][0]; mat[2][1] = (double)rotMatMaya[2][1];	mat[2][2] = (double)rotMatMaya[2][2]; mat[2][3] = 0.0;
	mat[3][0] = (double)transAfterRM[0];  mat[3][1] = (double)transAfterRM[1];  mat[3][2] = (double)transAfterRM[2];  mat[3][3] = 1.0;

	// We also want the inverse rotation values.
	//
	float pitchDegreesIX = 0.0f;
	float headDegreesIY = 0.0f;
	float rollDegreesIZ = 0.0f;
	toHeadPitchRoll( pitchDegreesIX,
					 headDegreesIY,
					 rollDegreesIZ,
					 mat.inverse() );

	// We want the axis and angle of the rotation.
	//
	float angleInRad = 0.0f;
	MVector axis( 0.0, 1.0, 0.0 );
	getAxisAngle( rotMatMaya,
				  axis,
				  angleInRad );

	float angle = angleInRad*(180.0f / sciPI);
	axis.normalize();

	if( angle==0.0 )
	{
		axis.x = 0.0;
		axis.y = 1.0;
		axis.z = 0.0;
	}

//cout << " axis: " << axis.x << " " << axis.y << " " << axis.z << endl;
//cout << " angle: " << angle << endl;

	MVector transAfterAxis;
	MVector center( 0.0f, 0.0f, 0.0f );
	double shift = 0.0;

	if( angle>10e-6 )
	{
		short axisLoc = data.inputValue( iAxisCenterType, &stat ).asShort();
		if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

		axisLocation_e axisLocation;
		switch( axisLoc )
		{
		case 0: axisLocation = axisLocation_e::kBetweenCentroids; break;
		case 1: axisLocation = axisLocation_e::kOffsetShiftAlongAxis; break;
		case 2: axisLocation = axisLocation_e::kSmallestOffset; break;
		case 3: axisLocation = axisLocation_e::kCustom; break;
		default: axisLocation = axisLocation_e::kOffsetShiftAlongAxis;
		}

		if( axisLocation==axisLocation_e::kBetweenCentroids )
		{
			getBetweenCentroidsCenter( sourceCentroidPoint,
									   targetCentroidPoint,
									   angleInRad,
									   axis,
									   rotMatSVD,
									   transAfterRM,
									   sourceAsMVector,
									   targetAsMVector,
									   center,
									   transAfterAxis );
		}
		else if( axisLocation==axisLocation_e::kOffsetShiftAlongAxis )
		{
			getOffsetShiftAlongAxisCenter( transAfterRM,
										   rotMatSVD,
										   axis,
										   angleInRad,
										   sourceAsMVector,
										   targetAsMVector,
										   center,
										   shift,
										   transAfterAxis );
		}
		else if( axisLocation==axisLocation_e::kSmallestOffset )
		{
			getSmallestOffsetCenter(	rotMatSVD,
										transAfterRM,
										sourceAsMVector,
										targetAsMVector,
										sourcePoint0,
										axis,
										angle,
										center,
										transAfterAxis );
		}
		else if( axisLocation==axisLocation_e::kCustom )
		{
			double3 & cente = data.inputValue( iCustomAxisCenter, &stat ).asDouble3();
			if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}

			center.x = cente[0];
			center.y = cente[1];
			center.z = cente[2];

			transAfterAxis = getTranslateAfterAxis( angleInRad,
													center,
													axis,
													rotMatSVD,
													transAfterRM,
													sourceAsMVector,
													targetAsMVector );
		}
	}

	// If there is no rotation, we still might have pure translation going on.
	//
	else
	{
		transAfterAxis.x = transAfterRM[0];
		transAfterAxis.y = transAfterRM[1];
		transAfterAxis.z = transAfterRM[2];
	}

	double distAfterAx = transAfterAxis.length();

	// We want the world rotation values for the axis orientation.
	// The y axis is rotated to the axis.
	//
	MFloatVector target( axis );
	MFloatVector rotValues;
	rotateYWithAxisAngle( target,
						  rotValues );

	// Set the outputs.
	//
	double & shiftAlongAxis = data.outputValue( oShiftAlongAxis, &stat ).asDouble();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	shiftAlongAxis = shift;

	double & distanceAfterAxis = data.outputValue( oDistanceAfterAxis, &stat ).asDouble();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	distanceAfterAxis = distAfterAx;

	double3 & taa = data.outputValue( oTranslateAfterAxis, &stat ).asDouble3();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	taa[0] = transAfterAxis[0];	taa[1] = transAfterAxis[1];	taa[2] = transAfterAxis[2];

	double3 & ces = data.outputValue( oCentroidSource, &stat ).asDouble3();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	ces[0] = (double)sourceCentroidPoint[0]; ces[1] = (double)sourceCentroidPoint[1];
	ces[2] = (double)sourceCentroidPoint[2];

	double3 & cet = data.outputValue( oCentroidTarget, &stat ).asDouble3();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	cet[0] = (double)targetCentroidPoint[0]; cet[1] = (double)targetCentroidPoint[1];
	cet[2] = (double)targetCentroidPoint[2];

	double3 & ced = data.outputValue( oCentroidDiff, &stat ).asDouble3();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	ced[0] = sourceCentroidPoint[0] - targetCentroidPoint[0];
	ced[1] = sourceCentroidPoint[1] - targetCentroidPoint[1];
	ced[2] = sourceCentroidPoint[2] - targetCentroidPoint[2];

	double3 & tar = data.outputValue( oTranslateAfterRM, &stat ).asDouble3();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	tar[0] = (double)transAfterRM[0]; tar[1] = (double)transAfterRM[1];	tar[2] = (double)transAfterRM[2];

	MDataHandle rotHX = data.outputValue( oRotateOfRMX, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	MDataHandle rotHY = data.outputValue( oRotateOfRMY, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	MDataHandle rotHZ = data.outputValue( oRotateOfRMZ, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	rotHX.setMAngle( MAngle( (double)pitchDegreesX, MAngle::kDegrees ) );
	rotHY.setMAngle( MAngle( (double)headDegreesY, MAngle::kDegrees ) );
	rotHZ.setMAngle( MAngle( (double)rollDegreesZ, MAngle::kDegrees ) );
	rotHX.setClean();
	rotHY.setClean();
	rotHZ.setClean();

	MDataHandle rotIHX = data.outputValue( oRotateOfInvRMX, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	MDataHandle rotIHY = data.outputValue( oRotateOfInvRMY, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	MDataHandle rotIHZ = data.outputValue( oRotateOfInvRMZ, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	rotIHX.setMAngle( MAngle( (double)pitchDegreesIX, MAngle::kDegrees ) );
	rotIHY.setMAngle( MAngle( (double)headDegreesIY, MAngle::kDegrees ) );
	rotIHZ.setMAngle( MAngle( (double)rollDegreesIZ, MAngle::kDegrees ) );
	rotIHX.setClean();
	rotIHY.setClean();
	rotIHZ.setClean();

	double3 & roa = data.outputValue( oRotationAxis, &stat ).asDouble3();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	roa[0] = (double)axis.x; roa[1] = (double)axis.y; roa[2] = (double)axis.z;

	double3 & roc = data.outputValue( oAxisCenter, &stat ).asDouble3();
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	roc[0] = (double)center.x; roc[1] = (double)center.y; roc[2] = (double)center.z;

	MDataHandle rotPXH = data.outputValue( oRotParentX, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	MDataHandle rotPZH = data.outputValue( oRotParentZ, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	rotPXH.setMAngle( MAngle( (double)rotValues.x, MAngle::kDegrees) );
	rotPZH.setMAngle( MAngle( (double)rotValues.z, MAngle::kDegrees ) );
	rotPXH.setClean();

	MAngle angleM;
	angleM.setUnit( MAngle::kDegrees );
	angleM.setValue( (double)angle );
	MAngle da( (double)angle, MAngle::kDegrees );
	MDataHandle angleH = data.outputValue( oAngle, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	angleH.set( angleM );
	angleH.setClean();

	MDataHandle matH = data.outputValue( oMatrix, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	matH.set( mat );
	matH.setClean();

	MDataHandle resultH = data.outputValue( oInfoA, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	MDataHandle resH = data.outputValue( oInfoB, &stat );
	if (!stat) {stat.perror((MString)__FILE__+(MString)(to_string(__LINE__).c_str()));return stat;}
	MString result;

	shortenValue( transAfterAxis.x ); shortenValue( transAfterAxis.y );	shortenValue( transAfterAxis.z );
	shortenValue( center.x ); shortenValue( center.y );	shortenValue( center.z );
	shortenValue( axis.x );	shortenValue( axis.y );	shortenValue( axis.z );
	shortenValue( angle );
	shortenValue( shiftAlongAxis );
	result += " center: "; result += center.x; result += " "; result += center.y; result += " "; result += center.z;
	result += "; axis: ";  result += axis.x;   result += " "; result += axis.y;	  result += " "; result += axis.z;
	result += "; angle: "; result += angle;
	resultH.setString( result );
	resultH.setClean();

	result = " transAfterAxis: "; result += transAfterAxis.x; result += " ";
	result += transAfterAxis.y; result +=" "; 	result += transAfterAxis.z;
	result += "; shiftAlongAxis: "; result += shiftAlongAxis;
	resH.setString( result );
	resH.setClean();

	if( data.inputValue( iPrintToOutput, &stat ).asBool() )
	{
		cout << endl;
		cout << " centroidSource : " <<
			sourceCentroidPoint[0] << " " << sourceCentroidPoint[1] << " " << sourceCentroidPoint[2] << endl;
		cout << " centroidTarget : " <<
			targetCentroidPoint[0] << " " << targetCentroidPoint[1] << " " << targetCentroidPoint[2] << endl;
		cout << " centroidDiff   : " <<
			ced[0] << " " << ced[1] << " " << ced[2] << endl;
		cout << " rotCenter loc  : " <<
			center[0] << " " <<	center[1] << " " <<	center[2] << endl;
		cout << " rotCenter axis : " <<
			axis.x <<  " " <<	axis.y  << " " << axis.z  << endl;
		cout << " transAfterAxis : " <<
			transAfterAxis.x <<  " " <<	transAfterAxis.y  << " " << transAfterAxis.z  << endl;
		cout << " shiftAlong axis: " << shiftAlongAxis  << endl;
		cout << " rot angle      : " << angle << endl;
		cout << " rotMat : " << rotMatMaya[0][0] << " " << rotMatMaya[0][1] << " " << rotMatMaya[0][2] << " " << 0.0 << endl;
		cout << "          " << rotMatMaya[1][0] << " " << rotMatMaya[1][1] << " " << rotMatMaya[1][2] << " " << 0.0 << endl;
		cout << "          " << rotMatMaya[2][0] << " " << rotMatMaya[2][1] << " " << rotMatMaya[2][2] << " " << 0.0 << endl;
		cout << "          " << transAfterRM[0]  << " " << transAfterRM[1]  << " " << transAfterRM[2]  << " " << 1.0 << endl;
		cout << " rotate around world zero: " << pitchDegreesX << " " << headDegreesY << " " << rollDegreesZ << endl;

		cout << endl;
	}

	return MS::kSuccess;
}

//______________________________________________________________________
//
//