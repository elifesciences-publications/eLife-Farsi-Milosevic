//

#ifndef STRUCTURE_ALIGN_H
#define STRUCTURE_ALIGN_H

#include <maya/MPxNode.h>
#include <maya/MVector.h>
#include <maya/MVectorArray.h>
#include <maya/MFloatArray.h>
#include <maya/MPointArray.h>

#include "../svd/SVD.h"

using sciloop::svdMatrix;
using sciloop::svdVector;

static const float sciPI = 3.141592653589793238462643383279502884197e0f;
static const float sciHALF_PI = sciPI/2.0f;

//___________________________________________________________________________________
//
//
class structureAlign : public MPxNode
{
public:

	enum class calcType_e
	{
		kInvalid,
		kSimpleSVD,
		kTMalign,
		kLast
	};

	enum class structureType_e
	{
		kInvalid,
		kProtein,
		kOther,
		kLast
	};

	enum class axisLocation_e
	{
		kInvalid,
		kBetweenCentroids,
		kOffsetShiftAlongAxis,
		kSmallestOffset,
		kCustom,
		kLast
	};

	virtual SchedulingType schedulingType() const override;
						structureAlign();
	virtual				~structureAlign();

	virtual MStatus		compute(	const MPlug & plug,
									MDataBlock  & data ) override;

	static  void*		creator();

	static  MStatus		initialize();

	MStatus				connectionMade( const MPlug & thisPlug,
										const MPlug & otherPlug,
										bool		  asSrc ) override;

	MStatus				connectionBroken( const MPlug & thisPlug,
										  const MPlug & otherPlug,
										  bool			asSrc ) override;

	bool transformPointsToCentroidZero( MVectorArray	& source,
										MVectorArray	& target,
										MVector			& sourceCentroid,
										MVector			& targetCentroid,
										bool			  centroidsToZero );

	bool convertToSvdData(	const MVectorArray	& source,
							const MVectorArray	& target,
							svdMatrix<float>	& sourcePoints,
							svdMatrix<float>	& targetPoints,
							const MVector		& sourceCentroid,
							const MVector		& targetCentroid,
							svdVector<float>	& sourceCentroidPoint,
							svdVector<float>	& targetCentroidPoint );


	bool	Kabsch( const svdMatrix<float>	& sourcePoints,
					const svdMatrix<float>	& targetPoints,
					const svdVector<float>	& sourceCentroidPoint,
					const svdVector<float>	& targetCentroidPoint,
					svdMatrix<float>		& RotMat,
					svdVector<float>		& transVec );

	MStatus createCurve(	unsigned	  ncvs,
							unsigned	  curveDegree,
							MPointArray	& controlVertices,
							MObject		& outAttrM,
							MDataBlock	& data );

	MStatus toHeadPitchRoll(	float					& pitchDegreesX,
								float					& headDegreesY,
								float					& rollDegreesZ,
								const svdMatrix<float>	& mtx );

	MStatus	toHeadPitchRoll( float					& pitchDegreesX,
							 float					& headDegreesY,
							 float					& rollDegreesZ,
							 const MFloatMatrix		& mtx );

	bool getAxisAngle(	svdMatrix<float>	& mtx,
						MVector				& axis,
						float				& angle );

	svdMatrix<float> eulerToMayaMat( const MVector & euler );

	bool getCenterOfRotation2( const MPoint		& sourcePoint,
							   const MPoint		& targetPoint,
							   const MVector	& axis,
							   const float		  angle,
							   MVector			& rotCenter,
							   MVector			& offset );

	bool rotateYWithAxisAngle( const MFloatVector	& axis,
							   MFloatVector			& rotValues );

	template<class T> void shortenValue( T & val );

	MMatrix matrixFromAxisAngle(	const MFloatVector & axis,
									float				 angleRadian );

	MVector getTranslateAfterAxis( const float				  angle,
								   const MVector			& center,
								   const MVector			& axis,
								   const svdMatrix<float>	& rotMat,
								   const svdVector<float>	& transVec,
								   MVectorArray				  sourceAsMVector,
								   MVectorArray				  targetAsMVector );

	void	projectPointOnLine( const svdVector<float>	& pointToProject,
								const svdVector<float>	& lineStart,
								const svdVector<float>	& lineEnd,
								svdVector<float>		& projectedPoint );

	bool getBetweenCentroidsCenter( const svdVector<float>	& sourceCentroidPoint,
									const svdVector<float>	& targetCentroidPoint,
									const float				  angleInRad,
									const MVector			& axis,
									const svdMatrix<float>	& rotMat,
									const svdVector<float>	& transVec,
									MVectorArray			& sourceAsMVector,
									MVectorArray			& targetAsMVector,
									MVector					& center,
									MVector					& transAfterAxis );

	bool getOffsetShiftAlongAxisCenter( const svdVector<float>	& transAfterRM,
										const svdMatrix<float>	& rotMatSVD,
										const MVector			& axis,
										const float				  angleInRad,
										MVectorArray			& sourceAsMVector,
										MVectorArray			& targetAsMVector,
										MVector					& center,
										double					& shift,
										MVector					& transAfterAxis );

	bool getSmallestOffsetCenter( const svdMatrix<float>	& rotMat,
								  const svdVector<float>	& transAfterRM,
								  const MVectorArray		& sourceAsMVector,
								  const MVectorArray		& targetAsMVector,
								  const MPoint				& sourcePoint0,
								  const MVector				& axis,
								  const float				  angle,
								  MVector					& center,
								  MVector					& transAfterAxis );



	static	MTypeId id;

	static MObject iSource;
	static MObject iTarget;
	static MObject iRotateOrder;
	static MObject iCentroidsToZero;
	static MObject iPrintToOutput;
	static MObject iCalcType;
	static MObject iStructureType;
	static MObject iAxisCenterType;
		static MObject iCustomAxisCenterX;
		static MObject iCustomAxisCenterY;
		static MObject iCustomAxisCenterZ;
	static MObject iCustomAxisCenter;

		static MObject oCentroidSourceX;
		static MObject oCentroidSourceY;
		static MObject oCentroidSourceZ;
	static MObject oCentroidSource;
		static MObject oCentroidTargetX;
		static MObject oCentroidTargetY;
		static MObject oCentroidTargetZ;
	static MObject oCentroidTarget;

	static MObject oAngle;

	static MObject oMatrix;

		static MObject oRotateOfRMX;
		static MObject oRotateOfRMY;
		static MObject oRotateOfRMZ;
	static MObject oRotateOfRM;

		static MObject oRotateOfInvRMX;
		static MObject oRotateOfInvRMY;
		static MObject oRotateOfInvRMZ;
	static MObject oRotateOfInvRM;

		static MObject oTranslateAfterRMX;
		static MObject oTranslateAfterRMY;
		static MObject oTranslateAfterRMZ;
	static MObject oTranslateAfterRM;

		static MObject oTranslateAfterAxisX;
		static MObject oTranslateAfterAxisY;
		static MObject oTranslateAfterAxisZ;
	static MObject oTranslateAfterAxis;

		static MObject oCentroidDiffX;
		static MObject oCentroidDiffY;
		static MObject oCentroidDiffZ;
	static MObject oCentroidDiff;

		static MObject oRotationAxisX;
		static MObject oRotationAxisY;
		static MObject oRotationAxisZ;
	static MObject oRotationAxis;

		static MObject oAxisCenterX;
		static MObject oAxisCenterY;
		static MObject oAxisCenterZ;
	static MObject oAxisCenter;

		static MObject oRotParentX;
		static MObject oRotParentZ;
	static MObject oRotParent;

	static MObject oOut;
	static MObject oSourceAfterCentroid;
	static MObject oTargetAfterCentroid;
	static MObject oInfoA;
	static MObject oInfoB;
	static MObject oShiftAlongAxis;
	static MObject oDistanceAfterAxis;

private:

	enum class dataType_e
	{
		kInvalid,
		kMesh,
		kNurbsCurve,
		kNurbsSurface,
		kPluginGeometry,
		kPointArray,
		kVectorArray,
		kLast
	};

	dataType_e sourceType_ = dataType_e::kInvalid;
	dataType_e targetType_ = dataType_e::kInvalid;
	dataType_e outType_ = dataType_e::kInvalid;

	bool sourceIsConnected_ = false;
	bool targetIsConnected_ = false;
	bool outIsConnected_ = false;
};


//______________________________________________________________________
//
//
template<class T> void structureAlign::shortenValue( T & val_ )
{
	if( val_>0.0 )
	{ val_ = ((float)(int)(val_*1000 + 0.5)) / 1000; }

	else
	{ val_ = ((float)(int)(val_*1000 - 0.5)) / 1000; }

	double min = 1.0e-5;

	if( val_<min && val_>-1*min )
	{ val_ = 0.0; }
}
//____________________________________________________________________________
//
//
#endif

