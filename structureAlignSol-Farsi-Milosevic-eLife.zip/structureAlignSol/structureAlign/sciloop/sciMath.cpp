//

#include "../sciloop/sciMath.h"

const float sciMath::PI         = 3.141592653589793238462643383279502884197e0f;
const float sciMath::HALF_PI    = sciMath::PI/2.0f;
const float sciMath::QUARTER_PI = sciMath::PI/4.0f;
const float sciMath::TWO_PI     = sciMath::PI*2.0f;
const float sciMath::EPSILON    = 0.000001f;