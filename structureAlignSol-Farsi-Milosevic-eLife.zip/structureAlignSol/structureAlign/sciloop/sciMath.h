//

#ifndef SCI_MATH_H
#define SCI_MATH_H

#include <cmath>
#include <cstdlib>

//____________________________________________________________________________
//
//
class sciMath
{
public:
	static const float PI;
	static const float HALF_PI;
	static const float QUARTER_PI;
	static const float TWO_PI;
	static const float EPSILON;

	static bool closeEnough(	float f1,
								float f2 )
	{return fabsf((f1 - f2) / ((f2==0.0f) ? 1.0f : f2)) < EPSILON;}

	static float degreesToRadians( float degrees )
	{return (degrees * PI) / 180.0f;}

	static float radiansToDegrees(float radians)
	{return (radians * 180.0f) / PI;}

};

#endif