//

#include <iostream>
using std::cout;
using std::endl;

#include "sciMath.h"
#include "sciMat33.h"
#include "sciVec3.h"

//______________________________________________________________________
//
//
sciMat33 sciMat33::inverse() const
{
	sciMat33 tmp;
	float d = determinant();

	if( sciMath::closeEnough(d, 0.0f) )
	{tmp.identity();}
	else
	{
		d = 1.0f / d;

		tmp.mtx_[0][0] = d*(mtx_[1][1]*mtx_[2][2] - mtx_[1][2]*mtx_[2][1]);
		tmp.mtx_[0][1] = d*(mtx_[0][2]*mtx_[2][1] - mtx_[0][1]*mtx_[2][2]);
		tmp.mtx_[0][2] = d*(mtx_[0][1]*mtx_[1][2] - mtx_[0][2]*mtx_[1][1]);

		tmp.mtx_[1][0] = d*(mtx_[1][2]*mtx_[2][0] - mtx_[1][0]*mtx_[2][2]);
		tmp.mtx_[1][1] = d*(mtx_[0][0]*mtx_[2][2] - mtx_[0][2]*mtx_[2][0]);
		tmp.mtx_[1][2] = d*(mtx_[0][2]*mtx_[1][0] - mtx_[0][0]*mtx_[1][2]);

		tmp.mtx_[2][0] = d*(mtx_[1][0]*mtx_[2][1] - mtx_[1][1]*mtx_[2][0]);
		tmp.mtx_[2][1] = d*(mtx_[0][1]*mtx_[2][0] - mtx_[0][0]*mtx_[2][1]);
		tmp.mtx_[2][2] = d*(mtx_[0][0]*mtx_[1][1] - mtx_[0][1]*mtx_[1][0]);
	}

	return tmp;
}

//______________________________________________________________________
//
//
void sciMat33::orient(	const sciVec3 & from,
						const sciVec3 & to )
{
	float e = sciVec3::dot( from, to );

	if( sciMath::closeEnough( e, 1.0f ) )
	{identity();}

	else if( sciMath::closeEnough( e, -1.0f ) )
	{
		sciVec3 side( 0.0f, from.z_, -from.y_ );

		if( sciMath::closeEnough( sciVec3::dot( side, side ), 0.0f ) )
		{side.set( -from.z_, 0.0f, from.x_ );}

		side.normalize();

		sciVec3 up = sciVec3::cross( side, from );
		up.normalize();

		mtx_[0][0] = -from.x_*from.x_ + up.x_*up.x_ - side.x_*side.x_;
		mtx_[0][1] = -from.x_*from.y_ + up.x_*up.y_ - side.x_*side.y_;
		mtx_[0][2] = -from.x_*from.z_ + up.x_*up.z_ - side.x_*side.z_;
		mtx_[1][0] = -from.x_*from.y_ + up.x_*up.y_ - side.x_*side.y_;
		mtx_[1][1] = -from.y_*from.y_ + up.y_*up.y_ - side.y_*side.y_;
		mtx_[1][2] = -from.y_*from.z_ + up.y_*up.z_ - side.y_*side.z_;
		mtx_[2][0] = -from.x_*from.z_ + up.x_*up.z_ - side.x_*side.z_;
		mtx_[2][1] = -from.y_*from.z_ + up.y_*up.z_ - side.y_*side.z_;
		mtx_[2][2] = -from.z_*from.z_ + up.z_*up.z_ - side.z_*side.z_;
	}
	else
	{
		sciVec3 v = sciVec3::cross( from, to );
		v.normalize();

		float h = (1.0f - e) / sciVec3::dot( v, v );

		mtx_[0][0] = e + h*v.x_*v.x_;
		mtx_[0][1] = h*v.x_*v.y_ + v.z_;
		mtx_[0][2] = h*v.x_*v.z_ - v.y_;

		mtx_[1][0] = h*v.x_*v.y_ - v.z_;
		mtx_[1][1] = e + h*v.y_*v.y_;
		mtx_[1][2] = h*v.x_*v.z_ + v.x_;

		mtx_[2][0] = h*v.x_*v.z_ + v.y_;
		mtx_[2][1] = h*v.y_*v.z_ - v.x_;
		mtx_[2][2] = e + h*v.z_*v.z_;
	}
}

//_____________________________________________________________________________
//
//
sciMat33::sciMat33()
{};

//_____________________________________________________________________________
//
//
sciMat33::~sciMat33()
{}

//_____________________________________________________________________________
//
//
sciMat33 operator*(	float scalar,
					const sciMat33 & rhs )
{return rhs*scalar;}

//_____________________________________________________________________________
//
//
sciMat33::sciMat33(	float m11, float m12, float m13,
					float m21, float m22, float m23,
					float m31, float m32, float m33)
{
	mtx_[0][0] = m11, mtx_[0][1] = m12, mtx_[0][2] = m13;
	mtx_[1][0] = m21, mtx_[1][1] = m22, mtx_[1][2] = m23;
	mtx_[2][0] = m31, mtx_[2][1] = m32, mtx_[2][2] = m33;
}

//_____________________________________________________________________________
//
//
float * sciMat33::operator[]( int row )
{return mtx_[row];}

//_____________________________________________________________________________
//
//
const float * sciMat33::operator[]( int row ) const
{return mtx_[row];}

//_____________________________________________________________________________
//
//
bool sciMat33::operator==( const sciMat33 & rhs ) const
{
	return sciMath::closeEnough( mtx_[0][0], rhs.mtx_[0][0] )
		&& sciMath::closeEnough( mtx_[0][1], rhs.mtx_[0][1] )
		&& sciMath::closeEnough( mtx_[0][2], rhs.mtx_[0][2] )
		&& sciMath::closeEnough( mtx_[1][0], rhs.mtx_[1][0] )
		&& sciMath::closeEnough( mtx_[1][1], rhs.mtx_[1][1] )
		&& sciMath::closeEnough( mtx_[1][2], rhs.mtx_[1][2] )
		&& sciMath::closeEnough( mtx_[2][0], rhs.mtx_[2][0] )
		&& sciMath::closeEnough( mtx_[2][1], rhs.mtx_[2][1] )
		&& sciMath::closeEnough( mtx_[2][2], rhs.mtx_[2][2] );
}

//_____________________________________________________________________________
//
//
bool sciMat33::operator!=( const sciMat33 & rhs ) const
{return !(*this == rhs);}

//_____________________________________________________________________________
//
//
sciMat33 & sciMat33::operator+=( const sciMat33 & rhs )
{
	mtx_[0][0] += rhs.mtx_[0][0], mtx_[0][1] += rhs.mtx_[0][1], mtx_[0][2] += rhs.mtx_[0][2];
	mtx_[1][0] += rhs.mtx_[1][0], mtx_[1][1] += rhs.mtx_[1][1], mtx_[1][2] += rhs.mtx_[1][2];
	mtx_[2][0] += rhs.mtx_[2][0], mtx_[2][1] += rhs.mtx_[2][1], mtx_[2][2] += rhs.mtx_[2][2];
	return *this;
}

//_____________________________________________________________________________
//
//
sciMat33 & sciMat33::operator-=( const sciMat33 & rhs )
{
	mtx_[0][0] -= rhs.mtx_[0][0], mtx_[0][1] -= rhs.mtx_[0][1], mtx_[0][2] -= rhs.mtx_[0][2];
	mtx_[1][0] -= rhs.mtx_[1][0], mtx_[1][1] -= rhs.mtx_[1][1], mtx_[1][2] -= rhs.mtx_[1][2];
	mtx_[2][0] -= rhs.mtx_[2][0], mtx_[2][1] -= rhs.mtx_[2][1], mtx_[2][2] -= rhs.mtx_[2][2];
	return *this;
}

//_____________________________________________________________________________
//
//
sciMat33 & sciMat33::operator*=( const sciMat33 & rhs )
{
	sciMat33 tmp;


	tmp.mtx_[0][0] = mtx_[0][0]*rhs.mtx_[0][0] +
					 mtx_[0][1]*rhs.mtx_[1][0] +
					 mtx_[0][2]*rhs.mtx_[2][0];

	tmp.mtx_[0][1] = mtx_[0][0]*rhs.mtx_[0][1] +
					 mtx_[0][1]*rhs.mtx_[1][1] +
					 mtx_[0][2]*rhs.mtx_[2][1];

	tmp.mtx_[0][2] = mtx_[0][0]*rhs.mtx_[0][2] +
					 mtx_[0][1]*rhs.mtx_[1][2] +
					 mtx_[0][2]*rhs.mtx_[2][2];


	tmp.mtx_[1][0] = (mtx_[1][0] * rhs.mtx_[0][0]) +
					(mtx_[1][1] * rhs.mtx_[1][0]) +
					(mtx_[1][2] * rhs.mtx_[2][0]);

	tmp.mtx_[1][1] = (mtx_[1][0] * rhs.mtx_[0][1]) +
					(mtx_[1][1] * rhs.mtx_[1][1]) +
					(mtx_[1][2] * rhs.mtx_[2][1]);

	tmp.mtx_[1][2] = (mtx_[1][0] * rhs.mtx_[0][2]) +
					(mtx_[1][1] * rhs.mtx_[1][2]) +
					(mtx_[1][2] * rhs.mtx_[2][2]);


	tmp.mtx_[2][0] = (mtx_[2][0] * rhs.mtx_[0][0]) +
					(mtx_[2][1] * rhs.mtx_[1][0]) +
					(mtx_[2][2] * rhs.mtx_[2][0]);

	tmp.mtx_[2][1] = (mtx_[2][0] * rhs.mtx_[0][1]) +
					(mtx_[2][1] * rhs.mtx_[1][1]) +
					(mtx_[2][2] * rhs.mtx_[2][1]);

	tmp.mtx_[2][2] = (mtx_[2][0] * rhs.mtx_[0][2]) +
					(mtx_[2][1] * rhs.mtx_[1][2]) +
					(mtx_[2][2] * rhs.mtx_[2][2]);

	*this = tmp;
	return *this;
}

//_____________________________________________________________________________
//
//
sciMat33 & sciMat33::operator*=( float scalar )
{
	mtx_[0][0] *= scalar, mtx_[0][1] *= scalar, mtx_[0][2] *= scalar;
	mtx_[1][0] *= scalar, mtx_[1][1] *= scalar, mtx_[1][2] *= scalar;
	mtx_[2][0] *= scalar, mtx_[2][1] *= scalar, mtx_[2][2] *= scalar;
	return *this;
}

//_____________________________________________________________________________
//
//
sciMat33 & sciMat33::operator/=( float scalar )
{
	mtx_[0][0] /= scalar, mtx_[0][1] /= scalar, mtx_[0][2] /= scalar;
	mtx_[1][0] /= scalar, mtx_[1][1] /= scalar, mtx_[1][2] /= scalar;
	mtx_[2][0] /= scalar, mtx_[2][1] /= scalar, mtx_[2][2] /= scalar;
	return *this;
}

//_____________________________________________________________________________
//
//
sciMat33 sciMat33::operator+( const sciMat33 & rhs ) const
{
	sciMat33 tmp(*this);
	tmp += rhs;
	return tmp;
}

//_____________________________________________________________________________
//
//
sciMat33 sciMat33::operator-( const sciMat33 & rhs ) const
{
	sciMat33 tmp(*this);
	tmp -= rhs;
	return tmp;
}

//_____________________________________________________________________________
//
//
sciMat33 sciMat33::operator*( const sciMat33 & rhs ) const
{
	sciMat33 tmp(*this);
	tmp *= rhs;
	return tmp;
}

//_____________________________________________________________________________
//
//
sciMat33 sciMat33::operator*( float scalar ) const
{
	sciMat33 tmp(*this);
	tmp *= scalar;
	return tmp;
}

//_____________________________________________________________________________
//
//
sciMat33 sciMat33::operator/( float scalar ) const
{
	sciMat33 tmp(*this);
	tmp /= scalar;
	return tmp;
}

//_____________________________________________________________________________
//
//
float sciMat33::determinant() const
{
		float det = (mtx_[0][0] * (mtx_[1][1]*mtx_[2][2] - mtx_[1][2]*mtx_[2][1])) -
			(mtx_[0][1] * (mtx_[1][0]*mtx_[2][2] - mtx_[1][2]*mtx_[2][0])) +
			(mtx_[0][2] * (mtx_[1][0]*mtx_[2][1] - mtx_[1][1]*mtx_[2][0]));

		det = 	(mtx_[0][0]*mtx_[1][1]*mtx_[2][2] +	mtx_[1][0]*mtx_[2][1]*mtx_[0][2] + mtx_[0][1]*mtx_[1][2]*mtx_[2][0]) -
			(mtx_[0][2]*mtx_[1][1]*mtx_[2][0] +	mtx_[0][1]*mtx_[1][0]*mtx_[2][2] + mtx_[1][2]*mtx_[2][1]*mtx_[0][0]);

		return det;
}

//_____________________________________________________________________________
//
//
void sciMat33::identity()
{
	mtx_[0][0] = 1.0f, mtx_[0][1] = 0.0f, mtx_[0][2] = 0.0f;
	mtx_[1][0] = 0.0f, mtx_[1][1] = 1.0f, mtx_[1][2] = 0.0f;
	mtx_[2][0] = 0.0f, mtx_[2][1] = 0.0f, mtx_[2][2] = 1.0f;
}

//_____________________________________________________________________________
//
//


