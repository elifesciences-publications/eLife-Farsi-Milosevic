//

#include "sciMath.h"
#include "sciMat33.h"
#include "sciVec3.h"

//_____________________________________________________________________________
//
//
sciVec3::sciVec3()
{};

//_____________________________________________________________________________
//
//
sciVec3::sciVec3(	float x,
					float y,
					float z ) :
						x_(x),
						y_(y),
						z_(z)
{}
//_____________________________________________________________________________
//
//
sciVec3::~sciVec3()
{};

//_____________________________________________________________________________
//
//
sciVec3 operator*(	float lhs,
					const sciVec3 & rhs )
{return sciVec3(lhs*rhs.x_, lhs*rhs.y_, lhs*rhs.z_);}

//_____________________________________________________________________________
//
//
sciVec3 operator-( const sciVec3 & v )
{return sciVec3( -v.x_, -v.y_, -v.z_ );}

//_____________________________________________________________________________
//
//
sciVec3 sciVec3::cross(	const sciVec3 & p,
						const sciVec3 & q )
{
	return sciVec3( p.y_*q.z_ - p.z_*q.y_,
					p.z_*q.x_ - p.x_*q.z_,
					p.x_*q.y_ - p.y_*q.x_ );
}

//_____________________________________________________________________________
//
//
// Calculates the distance between 2 points.
//
float sciVec3::distance(	const sciVec3 & pt1,
							const sciVec3 & pt2 )
{return sqrtf( distanceSq(pt1, pt2) );}

//_____________________________________________________________________________
//
//
// Calculates the squared distance between 2 points.
//
float sciVec3::distanceSq(	const sciVec3 & pt1,
							const sciVec3 & pt2 )
{

	return  ((pt1.x_ - pt2.x_)*(pt1.x_ - pt2.x_)) +
			((pt1.y_ - pt2.y_)*(pt1.y_ - pt2.y_)) +
			((pt1.z_ - pt2.z_)*(pt1.z_ - pt2.z_));
}

//_____________________________________________________________________________
//
//
float sciVec3::dot(	const sciVec3 & p,
					const sciVec3 & q )
{return p.x_*q.x_ + p.y_*q.y_ + p.z_*q.z_;}

//_____________________________________________________________________________
//
//
// Linearly interpolates from 'p' to 'q' as t varies from 0 to 1.
//
sciVec3 sciVec3::lerp(	const sciVec3 & p,
						const sciVec3 & q,
						float t )
{return p + t*(q - p);}

//_____________________________________________________________________________
//
//
// Performs Gram-Schmidt Orthogonalization on the 2 basis vectors to
// turn them into orthonormal basis vectors.
//
void sciVec3::orthogonalize(	sciVec3 & v1,
								sciVec3 & v2 )
{
	v2 = v2 - proj( v2, v1 );
	v2.normalize();
}

//_____________________________________________________________________________
//
//
// Performs Gram-Schmidt Orthogonalization on the 3 basis vectors to
// turn them into orthonormal basis vectors.
//
void sciVec3::orthogonalize(	sciVec3 & v1,
								sciVec3 & v2,
								sciVec3 & v3 )
{
	v2 = v2 - proj( v2, v1 );
	v2.normalize();

	v3 = v3 - proj( v3, v1 ) - proj( v3, v2 );
	v3.normalize();
}

//_____________________________________________________________________________
//
//
// Calculates the projection of 'p' onto 'q'.
//
sciVec3 sciVec3::proj(	const sciVec3 & p,
						const sciVec3 & q )
{
	float length =  q.magnitude();
	return (sciVec3::dot(p, q) / (length*length)) * q;
}

//_____________________________________________________________________________
//
//
// Calculates the component of 'p' perpendicular to 'q'.
//
sciVec3 sciVec3::perp(	const sciVec3 & p,
						const sciVec3 & q )
{
	float length = q.magnitude();
	return p - ((sciVec3::dot(p, q) / (length*length)) * q);
}

//_____________________________________________________________________________
//
//
// Calculates reflection vector from entering ray direction 'i'
// and surface normal 'n'.
//
sciVec3 sciVec3::reflect(	const sciVec3 & i,
							const sciVec3 & n )
{return i - 2.0f*sciVec3::proj(i, n);}


//_____________________________________________________________________________
//
//
sciVec3 & sciVec3::operator+=( const sciVec3 & rhs )
{
	x_ += rhs.x_, y_ += rhs.y_, z_ += rhs.z_;
	return *this;
}

//_____________________________________________________________________________
//
//
bool sciVec3::operator==( const sciVec3 & rhs ) const
{
	return	sciMath::closeEnough( x_, rhs.x_ ) &&
			sciMath::closeEnough( y_, rhs.y_ ) &&
			sciMath::closeEnough( z_, rhs.z_ );
}

//_____________________________________________________________________________
//
//
bool sciVec3::operator!=( const sciVec3 & rhs ) const
{return !(*this==rhs);}

//_____________________________________________________________________________
//
//
sciVec3 & sciVec3::operator-=( const sciVec3 & rhs )
{
	x_ -= rhs.x_, y_ -= rhs.y_, z_ -= rhs.z_;
	return *this;
}

sciVec3 & sciVec3::operator*=( float scalar )
{
	x_ *= scalar, y_ *= scalar, z_ *= scalar;
	return *this;
}

//_____________________________________________________________________________
//
//
sciVec3 & sciVec3::operator/=( float scalar )
{
	x_ /= scalar, y_ /= scalar, z_ /= scalar;
	return *this;
}

//_____________________________________________________________________________
//
//
sciVec3 sciVec3::operator+( const sciVec3 & rhs ) const
{
	sciVec3 tmp(*this);
	tmp += rhs;
	return tmp;
}

//_____________________________________________________________________________
//
//
sciVec3 sciVec3::operator-( const sciVec3 & rhs ) const
{
	sciVec3 tmp(*this);
	tmp -= rhs;
	return tmp;
}

//_____________________________________________________________________________
//
//
sciVec3 sciVec3::operator*( float scalar ) const
{return sciVec3(x_ * scalar, y_ * scalar, z_ * scalar);}

//_____________________________________________________________________________
//
//
sciVec3 sciVec3::operator/( float scalar ) const
{return sciVec3(x_ / scalar, y_ / scalar, z_ / scalar);}

//_____________________________________________________________________________
//
//
float sciVec3::magnitude() const
{return sqrtf( x_*x_ + y_*y_ + z_*z_ );}

//_____________________________________________________________________________
//
//
float sciVec3::magnitudeSq() const
{return x_*x_ + y_*y_ + z_*z_;}

//_____________________________________________________________________________
//
//
sciVec3 sciVec3::inverse() const
{return sciVec3(-x_, -y_, -z_);}

//_____________________________________________________________________________
//
//
void sciVec3::normalize()
{
	float invMag = 1.0f / magnitude();
	x_ *= invMag;
	y_ *= invMag;
	z_ *= invMag;
}

//_____________________________________________________________________________
//
//
void sciVec3::set(	float x,
					float y,
					float z )
{
	x_ = x;
	y_ = y;
	z_ = z;
}

//_____________________________________________________________________________
//
//
void sciVec3::makeUnit()
{
	x_ = 0.0;
	y_ = 1.0;
	z_ = 0.0;
}

//_____________________________________________________________________________
//
//
sciVec3 sciVec3::operator*( const sciMat33 & mat ) const
{
	sciVec3 v;

	v.x_ = x_*mat[0][0] + y_*mat[1][0] + z_*mat[2][0];
	v.y_ = x_*mat[0][1] + y_*mat[1][1] + z_*mat[2][1];
	v.z_ = x_*mat[0][2] + y_*mat[1][2] + z_*mat[2][2];

	return v;
}

//_____________________________________________________________________________
//
//
float sciVec3::operator*( const sciVec3 & rhs ) const
{
	double dot = x_ * rhs.x_;
	dot += y_ * rhs.y_;
	dot += z_ * rhs.z_;

	return dot;
}

//_____________________________________________________________________________
//
//
