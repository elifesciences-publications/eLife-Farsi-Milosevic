//

#ifndef SCI_VEC3_H
#define SCI_VEC3_H

class sciMat33;

//____________________________________________________________________________
//
// A 3-component vector class that represents a row vector.
//
class sciVec3
{
	friend sciVec3 operator*(	float lhs,
								const sciVec3 & rhs );
	friend sciVec3 operator-(	const sciVec3 & v );

public:
	float x_, y_, z_;

	sciVec3();

	sciVec3(					float x,
								float y,
								float z );
	~sciVec3();

	static sciVec3 cross(		const sciVec3	& p,
								const sciVec3	& q );

	static float distance(		const sciVec3	& pt1,
								const sciVec3	& pt2 );

	static float distanceSq(	const sciVec3	& pt1,
								const sciVec3	& pt2 );

	static float dot(			const sciVec3	& p,
								const sciVec3	& q );

	static sciVec3 lerp(		const sciVec3	& p,
								const sciVec3	& q,
								float			  t );

	static void orthogonalize(	sciVec3			& v1,
								sciVec3			& v2 );

	static void orthogonalize(	sciVec3			& v1,
								sciVec3			& v2,
								sciVec3			& v3 );

	static sciVec3 proj(		const sciVec3	& p,
								const sciVec3	& q );

	static sciVec3 perp(		const sciVec3	& p,
								const sciVec3	& q );

	static sciVec3 reflect(		const sciVec3	& i,
								const sciVec3	& n );


	bool operator==(			const sciVec3	& rhs ) const;
	bool operator!=(			const sciVec3	& rhs ) const;

	sciVec3& operator+=(		const sciVec3	& rhs );
	sciVec3& operator-=(		const sciVec3	& rhs );
	sciVec3& operator*=(		const float		  scalar );
	sciVec3& operator/=(		const float		  scalar );

	sciVec3 operator+(			const sciVec3	& rhs ) const;
	sciVec3 operator-(			const sciVec3	& rhs ) const;
	sciVec3 operator*(			const float		  scalar ) const;
	sciVec3 operator*(			const sciMat33	& mat ) const;
	float   operator*(			const sciVec3	& rhs ) const;
	sciVec3 operator/(			const float		  scalar ) const;

	float magnitude() const;
	float magnitudeSq() const;
	sciVec3 inverse() const;
	void normalize();
	void set(					float x,
								float y,
								float z );
	void makeUnit();
};

#endif