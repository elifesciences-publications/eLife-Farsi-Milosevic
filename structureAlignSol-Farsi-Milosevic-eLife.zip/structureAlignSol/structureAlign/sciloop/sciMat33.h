//

#ifndef SCI_MAT3_H
#define SCI_MAT3_H

class sciVec3;

//____________________________________________________________________________
//
class sciMat33
{

public:

	sciMat33();
	sciMat33(									float m11, float m12, float m13,
												float m21, float m22, float m23,
												float m31, float m32, float m33 );
	~sciMat33();

	float *operator[](							int row );
	const float *operator[](					int row ) const;

	bool operator==(							const sciMat33 & rhs ) const;
	bool operator!=(							const sciMat33 & rhs ) const;

	sciMat33 &operator+=(						const sciMat33 & rhs );
	sciMat33 &operator-=(						const sciMat33 & rhs );
	sciMat33 &operator*=(						const sciMat33 & rhs );
	sciMat33 &operator*=(						float scalar );
	sciMat33 &operator/=(						float scalar );

	sciMat33 operator+(							const sciMat33 & rhs ) const;
	sciMat33 operator-(							const sciMat33 & rhs ) const;
	sciMat33 operator*(							const sciMat33 & rhs ) const;
	sciMat33 operator*(							float scalar ) const;
	sciMat33 operator/(							float scalar ) const;

	float determinant() const;

	void identity();
	sciMat33 inverse() const;
	void orient(								const sciVec3 & from,
												const sciVec3 & to );

private:
	float mtx_[3][3];
};

#endif